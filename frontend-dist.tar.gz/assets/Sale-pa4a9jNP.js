import{j as e}from"./admin-D2I4SZO-.js";import{r as s,R as ve,u as $e}from"./vendor-cDl5Ih67.js";import{d as t}from"./ui-DXFJp4I_.js";import{e as ke,f as Se,T as Ce,g as Ee,L as Ne,u as de}from"./cash-Cdpp_gQO.js";import{u as ze}from"./stores-CmSlgjNa.js";import{u as ee}from"./categoryStore-BF1R9drw.js";import"./api-XIr9E-cT.js";import"./categoryService-KCFOthxd.js";const Fe=t.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1rem;
  margin: 1rem 0;
`,Me=t.button`
  padding: 1rem;
  border: 2px solid ${r=>r.$selected?"#2c5530":"#ddd"};
  background: ${r=>r.$selected?"#e8f5e8":"white"};
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.2s;
  text-align: left;

  &:hover {
    border-color: #2c5530;
    background: #f0f8f0;
  }

  &:focus {
    outline: 2px solid #2c5530;
    outline-offset: 2px;
  }

  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
`,Ie=t.div`
  font-weight: bold;
  margin-bottom: 0.5rem;
`,Ve=t.div`
  font-size: 0.9rem;
  color: #666;
`,Pe=({onSelect:r,selectedCategory:i})=>{const{activeCategories:w,loading:h,error:c,fetchCategories:l}=ee();if(s.useEffect(()=>{l()},[l]),h)return e.jsx("div",{role:"status","aria-live":"polite",children:"Chargement des catégories..."});if(c)return e.jsxs("div",{role:"alert","aria-live":"assertive",children:["Erreur lors du chargement des catégories: ",c]});const a=w.filter(n=>!n.parent_id);return e.jsx(Fe,{role:"group","aria-label":"Sélection de catégorie",children:a.map(n=>e.jsxs(Me,{$selected:i===n.id,onClick:()=>r(n.id),"data-testid":`category-${n.id}`,"data-selected":i===n.id?"true":"false","aria-pressed":i===n.id,"aria-label":`Sélectionner la catégorie ${n.name}`,children:[e.jsx(Ie,{children:n.name}),n.description&&e.jsx(Ve,{children:n.description})]},n.id))})},Te=({currentWeight:r,weightError:i,onClearWeight:w,onValidate:h})=>{const[c,l]=s.useState([]),a=c.reduce((u,f)=>u+f.weight,0),n=r&&!i&&parseFloat(r)>0,k=u=>(typeof u=="string"?parseFloat(u):u).toFixed(2),v=s.useCallback(()=>{if(n){const f={weight:parseFloat(r),timestamp:new Date};l(E=>[...E,f]),w()}},[n,r,w]),S=s.useCallback(u=>{l(f=>f.filter((E,g)=>g!==u))},[]),x=s.useCallback(()=>{let u=[...c];if(n){const E=parseFloat(r);u.push({weight:E,timestamp:new Date})}const f=u.reduce((E,g)=>E+g.weight,0);h(f)},[c,n,r,h]);return s.useEffect(()=>{const u=f=>{f.target instanceof HTMLInputElement||f.target instanceof HTMLTextAreaElement||(f.key==="+"&&(f.preventDefault(),v()),f.key==="Enter"&&(f.preventDefault(),(c.length>0||n)&&x()))};return document.addEventListener("keydown",u),()=>document.removeEventListener("keydown",u)},[v,x,c.length,n]),e.jsxs(qe,{"data-testid":"multiple-weight-container",children:[e.jsxs(We,{children:[e.jsxs(De,{children:["Pesées effectuées (",c.length,")"]}),c.length===0?e.jsx(Re,{children:"Aucune pesée enregistrée"}):e.jsx(Le,{children:c.map((u,f)=>e.jsxs(Ae,{"data-testid":`weight-item-${f}`,children:[e.jsxs(Qe,{children:[k(u.weight)," kg"]}),e.jsx(_e,{onClick:()=>S(f),"data-testid":`delete-weight-${f}`,children:"Supprimer"})]},f))})]}),e.jsxs(Be,{children:[e.jsxs(He,{children:[e.jsx(Ge,{children:"Poids total"}),e.jsxs(Ke,{"data-testid":"total-weight",children:[k(a)," kg"]}),e.jsx(Ue,{onClick:x,disabled:c.length===0&&!n,"data-testid":"validate-total-button",children:"Valider le poids total"})]}),e.jsxs(Oe,{children:[e.jsxs(Ye,{$isValid:!i,"data-testid":"weight-input",children:[r||"0"," kg"]}),e.jsx(Je,{children:i}),e.jsx(Xe,{onClick:v,disabled:!n,"data-testid":"add-weight-button",children:"+ Ajouter cette pesée"})]})]})]})},qe=t.div`
  height: 100%;
  display: flex;
  flex-direction: column;
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
`,We=t.div`
  flex: 1;
  overflow-y: auto;
  background: #f8f9fa;
  border: 2px solid #ddd;
  border-radius: 6px;
  padding: 1rem;
  margin: 0.5rem 1rem 0 1rem; /* Marge en bas à 0 pour tester alignement */
  min-height: 0; /* CRITIQUE pour permettre le scroll */
  max-height: 100%; /* Empêche de grandir au-delà du conteneur */
`,Be=t.div`
  flex-shrink: 0; /* CRITIQUE : Empêche la compression */
  padding: 1.5rem; /* Aligné avec TicketFooter */
  border-top: 2px solid #eee;
  background: #f8f9fa;
  border-radius: 0 0 8px 8px;
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
  box-shadow: 0 -2px 8px rgba(0,0,0,0.1);

  @media (max-width: 768px) {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
  }
`,De=t.h4`
  margin: 0 0 1rem 0;
  color: #2c5530;
  font-size: 1.1rem;
`,Le=t.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
`,Ae=t.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: white;
  border: 1px solid #ddd;
  border-radius: 4px;
  padding: 0.5rem;
`,Qe=t.span`
  font-weight: bold;
  color: #2c5530;
`,_e=t.button`
  background: #dc3545;
  color: white;
  border: none;
  border-radius: 4px;
  padding: 0.25rem 0.5rem;
  font-size: 0.8rem;
  cursor: pointer;
  
  &:hover {
    background: #c82333;
  }
`,Re=t.div`
  color: #666;
  font-style: italic;
  text-align: center;
  padding: 2rem;
`,He=t.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  background: #e8f5e8;
  border: 2px solid #2c5530;
  border-radius: 6px;
  padding: 0.75rem;
`,Ge=t.div`
  font-weight: bold;
  color: #2c5530;
  font-size: 0.9rem;
`,Ke=t.div`
  font-size: 1.5rem;
  font-weight: bold;
  color: #2c5530;
`,Ue=t.button`
  background: #2c5530;
  color: white;
  border: none;
  border-radius: 6px;
  padding: 0.75rem;
  font-weight: bold;
  cursor: pointer;
  transition: all 0.2s;

  &:hover:not(:disabled) {
    background: #1e3d21;
    transform: translateY(-1px);
  }

  &:disabled {
    background: #ccc;
    cursor: not-allowed;
  }
`,Oe=t.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  background: white;
  border: 2px solid #2c5530;
  border-radius: 6px;
  padding: 0.75rem;
`,Ye=t.div`
  font-size: 1.5rem;
  font-weight: bold;
  color: ${r=>r.$isValid?"#2c5530":"#dc3545"};
  text-align: center;
  padding: 0.5rem;
  background: #f8f9fa;
  border-radius: 4px;
`,Je=t.div`
  color: #dc3545;
  font-size: 0.8rem;
  text-align: center;
  min-height: 1rem;
`,Xe=t.button`
  background: #2c5530;
  color: white;
  border: none;
  border-radius: 6px;
  padding: 0.75rem;
  font-weight: bold;
  cursor: pointer;
  transition: all 0.2s;

  &:hover:not(:disabled) {
    background: #1e3d21;
    transform: translateY(-1px);
  }

  &:disabled {
    background: #ccc;
    cursor: not-allowed;
  }
`,Ze=t.div`
  background: #f8f9fa;
  border: 2px solid #2c5530;
  border-radius: 8px;
  padding: 1rem 1.5rem;
  margin-bottom: 1.5rem;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
`,et=t.div`
  font-size: 0.875rem;
  color: #6c757d;
  font-weight: 500;
  margin-bottom: 0.5rem;
  text-transform: uppercase;
  letter-spacing: 0.5px;
`,tt=t.div`
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 0.5rem;
  font-size: 1rem;
`,rt=t.span`
  color: #2c5530;
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 0.25rem;
`,it=t.span`
  color: #6c757d;
  display: flex;
  align-items: center;
`,nt=t.span`
  color: #adb5bd;
  font-style: italic;
`,ot=({data:r})=>{const{categoryName:i,subcategoryName:w,quantity:h,weight:c,price:l}=r,a=[];return i&&a.push(i),w&&a.push(w),h!==void 0&&h>0&&a.push(`Qté: ${h}`),c!==void 0&&c>0&&a.push(`Poids: ${c.toFixed(2)} kg`),l!==void 0&&l>0&&a.push(`Prix: ${l.toFixed(2)} €`),e.jsxs(Ze,{"data-testid":"staging-item",children:[e.jsx(et,{children:"Article en cours de saisie"}),e.jsx(tt,{children:a.length===0?e.jsx(nt,{"data-testid":"staging-item-empty",children:"Aucune information saisie"}):a.map((n,k)=>e.jsxs(ve.Fragment,{children:[k>0&&e.jsx(it,{children:e.jsx(ke,{size:16})}),e.jsx(rt,{"data-testid":`staging-item-part-${k}`,children:n})]},k))})]})};function at(r,i){const w=typeof r=="string"?parseFloat(r):r,h=typeof i=="string"?parseInt(i,10):i;if(isNaN(w)||isNaN(h)||w<0||h<0)return 0;const c=w*h;return Math.round(c*100)/100}function ce(r){return new Intl.NumberFormat("fr-FR",{style:"currency",currency:"EUR",minimumFractionDigits:2,maximumFractionDigits:2}).format(r)}const st=t.div`
  height: 100%;
  display: flex;
  flex-direction: column;
  overflow: hidden;
`,dt=t.div`
  display: flex;
  gap: 0.75rem;
  margin-bottom: 0.75rem;
`,ct=t.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 0.75rem;
  margin: 0.5rem 0;
`,lt=t.button`
  padding: 0.75rem;
  min-height: 44px;
  border: 2px solid ${r=>r.$selected?"#2c5530":"#ddd"};
  background: ${r=>r.$selected?"#e8f5e8":"white"};
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.2s;
  text-align: left;

  &:hover {
    border-color: #2c5530;
    background: #f0f8f0;
  }

  &:focus {
    outline: 2px solid #2c5530;
    outline-offset: 2px;
  }

  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
`,ut=t.div`
  font-weight: bold;
  margin-bottom: 0.25rem;
`,pt=t.div`
  font-size: 0.85rem;
  color: #666;
`,R=t.button`
  padding: 0.6rem 1.25rem;
  min-height: 44px;
  border: 2px solid ${r=>r.$active?"#2c5530":"#ddd"};
  background: ${r=>r.$active?"#2c5530":"white"};
  color: ${r=>r.$active?"white":"#333"};
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.2s;
  font-weight: 500;
  font-size: 0.9rem;

  &:hover {
    border-color: #2c5530;
    background: ${r=>r.$active?"#2c5530":"#f0f8f0"};
  }

  &:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
`,re=t.div`
  min-height: 0; /* IMPORTANT pour flexbox */
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden; /* EMPÊCHE le débordement */
`,mt=t.h3`
  margin: 0 0 0.5rem 0;
  color: #2c5530;
  font-size: 1.1rem;
`,le=t.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 1rem;
`,ue=t.h3`
  margin: 0 0 1rem 0;
  color: #2c5530;
  font-size: 1.2rem;
  text-align: center;
`,pe=t.div`
  background: #f8f9fa;
  border: 2px solid ${r=>r.$isValid===!1?"#dc3545":"#ddd"};
  border-radius: 8px;
  padding: 1rem;
  font-size: 2rem;
  font-weight: bold;
  text-align: center;
  margin: 0.5rem 0;
  transition: border-color 0.2s;
  min-height: 60px;
  display: flex;
  align-items: center;
  justify-content: center;
`,me=t.div`
  color: #dc3545;
  font-size: 0.875rem;
  margin-top: 0.5rem;
  text-align: center;
  min-height: 1.25rem;
`;t.div`
  color: #6c757d;
  font-size: 0.875rem;
  margin-top: 0.25rem;
  text-align: center;
  min-height: 1rem;
`;const ge=t.div`
  background: #f8f9fa;
  border: 2px solid #ddd;
  border-radius: 8px;
  padding: 1rem;
  margin: 1rem 0;
  flex: 1;
`,he=t.button`
  padding: 1rem 2rem;
  background: #2c5530;
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-weight: 500;
  font-size: 1.1rem;
  transition: background 0.2s;
  margin-top: auto;

  &:hover {
    background: #1e3d21;
  }

  &:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
`,gt=({onItemComplete:r,numpadCallbacks:i,currentMode:w})=>{const{getCategoryById:h,activeCategories:c}=ee(),[l,a]=s.useState("category"),[n,k]=s.useState(""),[v,S]=s.useState(""),[x,u]=s.useState(""),[f,E]=s.useState(""),g=i.quantityValue,$=i.quantityError,M=i.priceValue,B=i.priceError,y=s.useMemo(()=>{if(!g)return!1;const d=parseInt(g,10);return!isNaN(d)&&d>0&&d<=9999&&Number.isInteger(parseFloat(g))},[g]),A=s.useMemo(()=>{if(!x)return!1;const d=parseFloat(x);return!isNaN(d)&&d>0&&d<=9999.99},[x]),I=s.useMemo(()=>{if(!M)return!1;const d=parseFloat(M);if(isNaN(d)||d<.01||d>9999.99)return!1;const o=h(n),F=(o==null?void 0:o.max_price)!=null&&Number(o.max_price)>0,P=(o==null?void 0:o.price)!=null;if(F&&P){const W=Number(o.price),C=Number(o.max_price);return d>=W&&d<=C}return!0},[M,n,h]),T=d=>{k(d),c.some(F=>F.parent_id===d)?(a("subcategory"),i.setMode("idle")):(a("weight"),i.setWeightValue(""),i.setWeightError(""),i.setMode("weight"))},m=d=>{switch(d){case"category":a("category"),i.setMode("idle");break;case"subcategory":n&&c.some(o=>o.parent_id===n)&&(a("subcategory"),i.setMode("idle"));break;case"weight":n&&(a("weight"),i.setMode("weight"));break;case"quantity":x&&(a("quantity"),i.setMode("quantity"));break;case"price":g&&(a("price"),i.setMode("price"));break}setTimeout(()=>{const o=document.querySelector(`[data-step="${d}"] input, [data-step="${d}"] button, [data-step="${d}"] [tabindex="0"]`);o instanceof HTMLElement&&o.focus()},100)},z=d=>{m(d)},q=d=>{S(d),a("weight"),i.setWeightValue(""),i.setWeightError(""),i.setMode("weight")},V=()=>{if(!y)return;const o=h(v||n);if((o==null?void 0:o.max_price)!=null&&Number(o.max_price)>0){a("price"),i.setPriceValue(""),i.setPriceError(""),i.setMode("price");return}if((o==null?void 0:o.price)!=null){const P=parseInt(g,10),W=parseFloat(x),C=Number(o.price),b=C*P;r({category:n,subcategory:v||void 0,quantity:P,weight:W,price:C,total:b}),Q();return}a("price"),i.setPriceValue(""),i.setPriceError(""),i.setMode("price")},H=d=>{u(d.toString()),a("quantity"),i.setQuantityValue(""),i.setQuantityError(""),i.setMode("quantity")},D=()=>{if(!I||!A)return;const d=parseFloat(x),o=parseFloat(M),F=parseInt(g,10),P=o*F;r({category:n,subcategory:v||void 0,quantity:F,weight:d,price:o,total:P}),Q()},Q=()=>{k(""),S(""),u(""),E(""),i.setQuantityValue(""),i.setQuantityError(""),i.setPriceValue(""),i.setPriceError(""),i.setWeightValue(""),i.setWeightError(""),i.setMode("idle"),a("category")};s.useEffect(()=>{const d=o=>{o.key==="Enter"&&(o.target instanceof HTMLInputElement||o.target instanceof HTMLTextAreaElement)||o.key==="Enter"&&(o.preventDefault(),l==="quantity"&&y?V():l==="price"&&I&&D())};return document.addEventListener("keydown",d),()=>document.removeEventListener("keydown",d)},[l,y,I,V,D]);const G=()=>{switch(l){case"category":return e.jsx(re,{"data-step":"category",children:e.jsx(Pe,{onSelect:T,selectedCategory:n})});case"subcategory":{const C=c.filter(b=>b.parent_id===n);return e.jsxs(re,{"data-step":"subcategory",children:[e.jsx(mt,{children:"Sélectionner la sous-catégorie"}),e.jsx(ct,{role:"group","aria-label":"Sélection de sous-catégorie",children:C.map(b=>{const K=()=>{if(b.price&&b.max_price&&Number(b.max_price)>0){const L=Number(b.price).toFixed(2),_=Number(b.max_price).toFixed(2);return`${L}€ - ${_}€`}else if(b.price)return`${Number(b.price).toFixed(2)}€`;return"Prix non défini"};return e.jsxs(lt,{$selected:v===b.id,onClick:()=>q(b.id),"data-testid":`subcategory-${b.id}`,"data-selected":v===b.id?"true":"false","aria-pressed":v===b.id,"aria-label":`Sélectionner la sous-catégorie ${b.name}`,children:[e.jsx(ut,{children:b.name}),e.jsx(pt,{children:K()})]},b.id)})})]})}case"quantity":const o=h(v||n),F=o!=null&&o.price?Number(o.price):0,P=g?parseInt(g,10):0,W=at(F,P);return e.jsxs(le,{"data-step":"quantity",children:[e.jsx(ue,{children:"Quantité"}),e.jsx(pe,{$isValid:!$,"data-testid":"quantity-input",children:g||"0"}),e.jsx(me,{children:$}),(o==null?void 0:o.price)&&!(o!=null&&o.max_price)&&g&&y&&e.jsxs(ge,{children:[e.jsx("div",{style:{fontSize:"0.9rem",color:"#666",marginBottom:"0.5rem"},children:"Calcul automatique"}),e.jsxs("div",{style:{fontSize:"1.2rem",fontWeight:"bold",color:"#2c5530"},children:[ce(F)," × ",g," = ",ce(W)]})]}),e.jsx(he,{disabled:!y,onClick:V,"data-testid":"validate-quantity-button",children:"Valider la quantité"})]});case"weight":return e.jsx(re,{"data-step":"weight",children:e.jsx(Te,{onValidate:H,currentWeight:i.weightValue,weightError:i.weightError,onClearWeight:()=>{i.setWeightValue(""),i.setWeightError("")}})});case"price":return e.jsxs(le,{"data-step":"price",children:[e.jsx(ue,{children:"Prix unitaire"}),e.jsxs(pe,{$isValid:!B,"data-testid":"price-input",children:[M||"0"," €"]}),(()=>{const C=h(n),b=(C==null?void 0:C.max_price)!=null&&Number(C.max_price)>0;if((C==null?void 0:C.price)!=null&&b){const L=Number(C.price).toFixed(2),_=Number(C.max_price).toFixed(2);return e.jsxs(ge,{children:[e.jsx("div",{style:{fontSize:"0.9rem",color:"#666",marginBottom:"0.5rem"},children:"Fourchette de prix autorisée"}),e.jsxs("div",{style:{fontSize:"1.1rem",fontWeight:"bold",color:"#2c5530"},children:[L," € – ",_," €"]})]})}return null})(),e.jsx(me,{children:B}),e.jsx(he,{disabled:!I,onClick:D,"data-testid":"add-item-button",children:"Valider le prix"})]});default:return null}},te=s.useMemo(()=>{var C,b;const d=n?(C=h(n))==null?void 0:C.name:void 0,o=v?(b=h(v))==null?void 0:b.name:void 0,F=g?parseInt(g,10):void 0,P=x?parseFloat(x):void 0,W=M?parseFloat(M):void 0;return{categoryName:d,subcategoryName:o,quantity:F,weight:P,price:W}},[n,v,g,x,M,h]);return e.jsxs(st,{children:[e.jsx("div",{children:e.jsxs(dt,{children:[e.jsx(R,{$active:l==="category","data-active":l==="category",onClick:()=>z("category"),children:"Catégorie"}),c.some(d=>d.parent_id===n)&&e.jsx(R,{$active:l==="subcategory","data-active":l==="subcategory",disabled:!n,onClick:()=>z("subcategory"),children:"Sous-catégorie"}),e.jsx(R,{$active:l==="weight","data-active":l==="weight",disabled:!n,onClick:()=>z("weight"),children:"Poids"}),e.jsx(R,{$active:l==="quantity","data-active":l==="quantity",disabled:!x,onClick:()=>z("quantity"),children:"Quantité"}),e.jsx(R,{$active:l==="price","data-active":l==="price",disabled:!g,onClick:()=>z("price"),children:"Prix"})]})}),e.jsx(ot,{data:te}),G()]})},ht=t.div`
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  height: 100%;
  display: flex;
  flex-direction: column;
`,xt=t.div`
  padding: 1.5rem 1.5rem 0 1.5rem;
`,ft=t.div`
  flex: 1;
  overflow-y: auto;
  padding: 0 1.5rem;
`,bt=t.div`
  padding: 1.5rem;
  border-top: 2px solid #eee;
  background: #f8f9fa;
  border-radius: 0 0 8px 8px;
  margin-top: auto;
`,yt=t.h3`
  margin: 0 0 1rem 0;
  color: #2c5530;
  text-align: center;
  border-bottom: 2px solid #2c5530;
  padding-bottom: 0.5rem;
`,wt=t.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.75rem 0;
  border-bottom: 1px solid #eee;
  gap: 1rem;

  &:last-child {
    border-bottom: none;
  }
`,vt=t.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
`,jt=t.span`
  font-weight: 500;
  color: #333;
`,$t=t.span`
  font-size: 0.875rem;
  color: #666;
`,kt=t.span`
  font-weight: bold;
  color: #2c5530;
  min-width: 60px;
  text-align: right;
`,St=t.div`
  display: flex;
  gap: 0.5rem;
`,xe=t.button`
  padding: 4px 8px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 11px;
  transition: all 0.2s;
  display: flex;
  align-items: center;
  gap: 2px;

  &.edit {
    background: #ffc107;
    color: #212529;

    &:hover {
      background: #e0a800;
    }
  }

  &.delete {
    background: #dc3545;
    color: white;

    &:hover {
      background: #c82333;
    }
  }

  &:disabled {
    background: #ccc;
    cursor: not-allowed;
  }
`,Ct=t.div`
  margin-top: 1rem;
  padding-top: 1rem;
  border-top: 2px solid #ddd;
`,Et=t.div`
  display: flex;
  justify-content: space-between;
  font-weight: bold;
  font-size: 1.1rem;
  color: #2c5530;
`,Nt=t.button`
  width: 100%;
  padding: 1rem;
  background: #2c5530;
  color: white;
  border: none;
  border-radius: 8px;
  font-size: 1.1rem;
  font-weight: bold;
  cursor: pointer;
  margin-top: 1rem;
  transition: background 0.2s;

  &:hover {
    background: #234426;
  }

  &:disabled {
    background: #ccc;
    cursor: not-allowed;
  }
`,zt=t.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: ${r=>r.$isOpen?"flex":"none"};
  align-items: center;
  justify-content: center;
  z-index: 1000;
`,Ft=t.div`
  background: white;
  padding: 2rem;
  border-radius: 8px;
  min-width: 400px;
  max-width: 90vw;
`,Mt=t.form`
  display: flex;
  flex-direction: column;
  gap: 1rem;
`,U=t.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
`,O=t.label`
  font-weight: 500;
  color: #333;
`,Y=t.input`
  padding: 0.75rem;
  border: 2px solid #ddd;
  border-radius: 4px;
  font-size: 1rem;

  &:focus {
    outline: none;
    border-color: #2c5530;
  }
`,It=t.div`
  display: flex;
  gap: 1rem;
  justify-content: flex-end;
`,fe=t.button`
  padding: 0.75rem 1.5rem;
  border: 2px solid ${r=>r.$variant==="primary"?"#2c5530":"#ddd"};
  background: ${r=>r.$variant==="primary"?"#2c5530":"white"};
  color: ${r=>r.$variant==="primary"?"white":"#333"};
  border-radius: 4px;
  cursor: pointer;
  font-weight: 500;

  &:hover {
    background: ${r=>r.$variant==="primary"?"#234426":"#f0f8f0"};
  }
`,Vt=({items:r,onRemoveItem:i,onUpdateItem:w,onFinalizeSale:h,loading:c=!1})=>{var I,T;const{getCategoryById:l,fetchCategories:a}=ee(),[n,k]=s.useState(null),[v,S]=s.useState(""),[x,u]=s.useState(""),[f,E]=s.useState(""),g=s.useRef(null);s.useEffect(()=>{a()},[a]);const $=r.reduce((m,z)=>m+(z.total||0),0),M=r.length;s.useEffect(()=>{g.current&&r.length>0&&(g.current.scrollTop=g.current.scrollHeight)},[r.length]);const B=m=>{k(m),S((m.quantity||1).toString()),u((m.weight||0).toString()),E(m.price.toString())},y=m=>{if(m.preventDefault(),n){const z=parseInt(v,10),q=parseFloat(x),V=parseFloat(f);!isNaN(z)&&!isNaN(q)&&!isNaN(V)&&z>0&&q>0&&V>0&&(w(n.id,z,q,V),k(null),S(""),u(""),E(""))}},A=()=>{k(null),S(""),u(""),E("")};return e.jsxs(e.Fragment,{children:[e.jsxs(ht,{children:[e.jsx(xt,{children:e.jsx(yt,{children:"Ticket de Caisse"})}),e.jsx(ft,{ref:g,children:r.length===0?e.jsx("p",{style:{textAlign:"center",color:"#666",margin:"2rem 0"},children:"Aucun article ajouté"}):r.map(m=>{var q,V;const z=m.subcategoryName||m.categoryName||(m.subcategory?(q=l(m.subcategory))==null?void 0:q.name:null)||((V=l(m.category))==null?void 0:V.name)||m.category;return e.jsxs(wt,{children:[e.jsxs(vt,{children:[e.jsx(jt,{children:z}),e.jsx($t,{children:`Qté: ${m.quantity||1} • ${(m.weight||0).toFixed(2)} kg • ${(m.price||0).toFixed(2)} €/unité`})]}),e.jsx(kt,{children:`${(m.total||0).toFixed(2)} €`}),e.jsxs(St,{children:[e.jsx(xe,{className:"edit",onClick:()=>B(m),children:e.jsx(Se,{size:12})}),e.jsx(xe,{className:"delete",onClick:()=>i(m.id),children:e.jsx(Ce,{size:12})})]})]},m.id)})}),e.jsxs(bt,{children:[e.jsx(Ct,{children:e.jsxs(Et,{children:[e.jsxs("span",{children:[M," articles"]}),e.jsx("span",{"data-testid":"sale-total",children:`${$.toFixed(2)} €`})]})}),e.jsx(Nt,{onClick:h,disabled:c||r.length===0,children:c?"Finalisation...":"Finaliser la vente"})]})]}),e.jsx(zt,{$isOpen:!!n,role:"dialog","aria-modal":"true","aria-label":"Modifier l'article",children:e.jsxs(Ft,{children:[e.jsx("h3",{style:{display:n?void 0:"none"},children:"Modifier l'article"}),e.jsxs(Mt,{onSubmit:y,children:[e.jsxs(U,{children:[e.jsx(O,{children:"Catégorie"}),e.jsx(Y,{type:"text",value:n?n.subcategoryName||n.categoryName||(n.subcategory?(I=l(n.subcategory))==null?void 0:I.name:null)||((T=l(n.category))==null?void 0:T.name)||n.category:"",disabled:!0})]}),e.jsxs(U,{children:[e.jsx(O,{children:"Quantité"}),e.jsx(Y,{type:"number",step:"1",value:v,onChange:m=>S(m.target.value),min:"1",max:"9999",required:!0})]}),e.jsxs(U,{children:[e.jsx(O,{children:"Poids (kg)"}),e.jsx(Y,{type:"number",step:"0.01",value:x,onChange:m=>u(m.target.value),min:"0.01",max:"9999.99",required:!0})]}),e.jsxs(U,{children:[e.jsx(O,{children:"Prix unitaire"}),e.jsx(Y,{type:"number",step:"0.01",value:f,onChange:m=>E(m.target.value),min:"0.01",max:"9999.99",required:!0})]}),e.jsxs(It,{children:[e.jsx(fe,{type:"button",onClick:A,children:"Annuler"}),e.jsx(fe,{type:"submit",$variant:"primary",children:"Valider"})]})]})]})})]})},Pt=t.div`
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.5);
  display: ${r=>r.$open?"flex":"none"};
  align-items: center;
  justify-content: center;
  z-index: 2000;
`,Tt=t.div`
  background: #fff;
  border-radius: 8px;
  padding: 1.5rem;
  min-width: 420px;
  max-width: 95vw;
  box-shadow: 0 4px 12px rgba(0,0,0,0.15);
`,qt=t.h3`
  margin: 0 0 1rem 0;
  color: #2c5530;
`,Wt=t.form`
  display: flex;
  flex-direction: column;
  gap: 1rem;
`,be=t.div`
  display: flex;
  gap: 1rem;
`,J=t.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  flex: 1;
`,X=t.label`
  font-weight: 500;
  color: #333;
`,ie=t.input`
  padding: 0.75rem;
  border: 2px solid #ddd;
  border-radius: 6px;
  font-size: 1rem;
  &:focus { outline: none; border-color: #2c5530; }
`,Bt=t.select`
  padding: 0.75rem;
  border: 2px solid #ddd;
  border-radius: 6px;
  font-size: 1rem;
  &:focus { outline: none; border-color: #2c5530; }
`,Dt=t.div`
  background: #f8f9fa;
  border: 2px solid #eee;
  border-radius: 8px;
  padding: 0.75rem 1rem;
  display: flex;
  justify-content: space-between;
  font-weight: 600;
`,Lt=t.div`
  display: flex;
  justify-content: flex-end;
  gap: 0.75rem;
`,ye=t.button`
  padding: 0.75rem 1.25rem;
  border: 2px solid ${r=>r.$variant==="primary"?"#2c5530":"#ddd"};
  background: ${r=>r.$variant==="primary"?"#2c5530":"#fff"};
  color: ${r=>r.$variant==="primary"?"#fff":"#333"};
  border-radius: 8px;
  cursor: pointer;
  font-weight: 600;
  &:disabled { opacity: 0.6; cursor: not-allowed; }
`,At=({open:r,totalAmount:i,onCancel:w,onConfirm:h})=>{const[c,l]=s.useState("0"),[a,n]=s.useState("cash"),[k,v]=s.useState("");ve.useEffect(()=>{r&&(l("0"),n("cash"),v(""))},[r]);const S=s.useMemo(()=>{const $=parseFloat(c||"0");return isNaN($)||$<0?0:Math.min($,999999.99)},[c]),x=s.useMemo(()=>{const $=parseFloat(k||"");if(a==="cash"&&!(isNaN($)||$<=0))return Math.min($,999999.99)},[k,a]),u=s.useMemo(()=>i+S,[i,S]),f=s.useMemo(()=>{if(!(a!=="cash"||x==null))return Number((x-u).toFixed(2))},[a,x,u]),E=s.useMemo(()=>a==="cash"?x!=null&&x>=u:!0,[a,x,u]),g=$=>{$.preventDefault(),E&&h({donation:Number(S.toFixed(2)),paymentMethod:a,cashGiven:a==="cash"?x:void 0,change:a==="cash"?f:void 0})};return e.jsx(Pt,{$open:r,role:"dialog","aria-modal":"true","aria-label":"Finaliser la vente","data-testid":"finalization-screen",children:e.jsxs(Tt,{children:[e.jsx(qt,{children:"Finaliser la vente"}),e.jsxs(Wt,{onSubmit:g,children:[e.jsxs(Dt,{children:[e.jsx("span",{children:"Total à payer"}),e.jsxs("span",{"data-testid":"amount-due",children:[u.toFixed(2)," €"]})]}),e.jsxs(be,{children:[e.jsxs(J,{children:[e.jsx(X,{htmlFor:"donation",children:"Don (€)"}),e.jsx(ie,{id:"donation",type:"number",step:"0.01",min:"0",value:c,onChange:$=>l($.target.value),"data-testid":"donation-input"})]}),e.jsxs(J,{children:[e.jsx(X,{htmlFor:"payment",children:"Moyen de paiement"}),e.jsxs(Bt,{id:"payment",value:a,onChange:$=>n($.target.value),"data-testid":"payment-select",children:[e.jsx("option",{value:"cash",children:"Espèces"}),e.jsx("option",{value:"card",children:"Carte"}),e.jsx("option",{value:"check",children:"Chèque"})]})]})]}),a==="cash"&&e.jsxs(be,{children:[e.jsxs(J,{children:[e.jsx(X,{htmlFor:"cashGiven",children:"Montant donné (€)"}),e.jsx(ie,{id:"cashGiven",type:"number",step:"0.01",min:"0",value:k,onChange:$=>v($.target.value),"data-testid":"cash-given-input"})]}),e.jsxs(J,{children:[e.jsx(X,{children:"Monnaie à rendre"}),e.jsx(ie,{value:a==="cash"&&x!=null?Math.max(0,f||0).toFixed(2):"0.00",readOnly:!0,"data-testid":"change-output"})]})]}),e.jsxs(Lt,{children:[e.jsx(ye,{type:"button",onClick:w,"data-testid":"cancel-finalization",children:"Annuler"}),e.jsx(ye,{type:"submit",$variant:"primary",disabled:!E,"data-testid":"confirm-finalization",children:"Valider"})]})]})]})})},Qt=t.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.75rem 1.5rem;
  background: #2e7d32;
  color: white;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  min-height: 50px;

  @media (max-width: 768px) {
    padding: 0.5rem 1rem;
    min-height: 45px;
  }
`,_t=t.div`
  display: flex;
  align-items: center;
  gap: 0.75rem;
`,Rt=t.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 0.95rem;
  font-weight: 500;

  @media (max-width: 768px) {
    font-size: 0.85rem;
  }
`,Ht=t.span`
  color: rgba(255, 255, 255, 0.9);
  font-size: 0.85rem;

  @media (max-width: 768px) {
    display: none;
  }
`,Gt=t.button`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem 1rem;
  background: #d32f2f;
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-size: 0.9rem;
  font-weight: 500;
  transition: background-color 0.2s;

  &:hover {
    background: #b71c1c;
  }

  &:disabled {
    background: #ccc;
    cursor: not-allowed;
  }

  @media (max-width: 768px) {
    padding: 0.4rem 0.75rem;
    font-size: 0.8rem;
    gap: 0.35rem;

    svg {
      width: 16px;
      height: 16px;
    }
  }
`,Kt=({cashierName:r,sessionId:i,onCloseSession:w,isLoading:h=!1})=>{const c=i?i.slice(-8):"";return e.jsxs(Qt,{"data-testid":"cash-session-header",children:[e.jsxs(_t,{children:[e.jsxs(Rt,{children:[e.jsx(Ee,{size:18}),e.jsx("span",{children:r})]}),c&&e.jsxs(Ht,{children:["Session #",c]})]}),e.jsxs(Gt,{onClick:w,disabled:h,"data-testid":"close-session-button",children:[e.jsx(Ne,{size:18}),"Fermer la Caisse"]})]})},Ut=t.div`
  display: flex;
  flex-direction: column;
  height: 100%;
  width: 100%;
  gap: 1rem;
  padding: 0.5rem;
`,Ot=t.div`
  background: #f8f9fa;
  border: 3px solid #2c5530;
  border-radius: 12px;
  padding: 1.5rem;
  text-align: center;
  box-shadow: 0 4px 8px rgba(0,0,0,0.1);
  flex-shrink: 0; /* Empêche le display de se rétrécir */
  position: relative;
`,Yt=t.div`
  font-size: 3rem;
  font-weight: bold;
  color: ${r=>r.$hasError?"#dc3545":"#2c5530"};
  min-height: 4rem;
  display: flex;
  align-items: center;
  justify-content: center;
  line-height: 1;
  word-break: break-all; /* Gère les longues valeurs */

  @media (max-width: 768px) {
    font-size: 2.5rem;
    min-height: 3rem;
  }
`,Jt=t.div`
  color: #dc3545;
  font-size: 0.875rem;
  margin-top: 0.5rem;
  min-height: 1.25rem;
`,Xt=t.div`
  position: absolute;
  top: 8px;
  right: 8px;
  display: flex;
  gap: 8px;
`,we=t.button`
  width: 34px;
  height: 34px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border: 2px solid #2c5530;
  background: white;
  color: #2c5530;
  border-radius: 8px;
  cursor: pointer;
  font-size: 1.1rem;
  line-height: 1;
  transition: all 0.2s;

  &:hover {
    background: #f0f8f0;
    border-color: #1e3d21;
  }
`,Zt=t.div`
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 0.75rem;
  flex: 1;
  min-height: 0; /* Permet au grid de se rétrécir */
  align-content: start; /* Empêche l'étirement vertical */

  @media (max-width: 768px) {
    gap: 0.5rem;
  }
`,Z=t.button`
  min-height: 64px;
  aspect-ratio: 1; /* Carré pour éviter les débordements */
  border: 3px solid ${r=>r.$variant==="primary"?"#1e3d21":r.$variant==="danger"?"#b71c1c":"#2c5530"};
  background: ${r=>r.$variant==="primary"?"#2c5530":r.$variant==="danger"?"#dc3545":"white"};
  color: ${r=>r.$variant==="primary"||r.$variant==="danger"?"white":"#2c5530"};
  border-radius: 12px;
  cursor: pointer;
  font-size: 1.8rem;
  font-weight: bold;
  transition: all 0.2s;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);

  &:hover {
    border-color: ${r=>r.$variant==="primary"?"#1e3d21":r.$variant==="danger"?"#b71c1c":"#1e3d21"};
    background: ${r=>r.$variant==="primary"?"#1e3d21":r.$variant==="danger"?"#b71c1c":"#f0f8f0"};
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.15);
  }

  &:active {
    transform: scale(0.95) translateY(0);
  }

  &:disabled {
    opacity: 0.3;
    cursor: not-allowed;
    transform: none;
  }

  @media (max-width: 768px) {
    min-height: 56px;
    aspect-ratio: 1;
    font-size: 1.4rem;
  }
`;t(Z)`
  font-size: 1.25rem;
  
  @media (max-width: 768px) {
    font-size: 1rem;
  }
`;const er=({value:r,error:i,onDigit:w,onClear:h,onBackspace:c,onDecimal:l,unit:a="",showDecimal:n=!0,placeholder:k="0"})=>{const v=r||k;return e.jsxs(Ut,{"data-testid":"numpad",children:[e.jsxs(Ot,{children:[e.jsxs(Xt,{children:[e.jsx(we,{onClick:c,"aria-label":"Effacer un caractère","data-testid":"numpad-backspace-top",children:"⌫"}),e.jsx(we,{onClick:h,"aria-label":"Effacer tout","data-testid":"numpad-clear-top",children:"C"})]}),e.jsxs(Yt,{$hasError:!!i,"data-testid":"numpad-display",children:[v,a?` ${a}`:""]}),i&&e.jsx(Jt,{"data-testid":"numpad-error",children:i})]}),e.jsxs(Zt,{children:[[1,2,3,4,5,6,7,8,9].map(S=>e.jsx(Z,{onClick:()=>w(S.toString()),"data-testid":`numpad-${S}`,children:S},S)),e.jsx("div",{}),e.jsx(Z,{onClick:()=>w("0"),"data-testid":"numpad-0",children:"0"}),e.jsx(Z,{onClick:l,disabled:!l,"data-testid":"numpad-decimal",children:"."})]})]})},tr=t.div`
  width: 100%;
  height: 100vh;
  display: flex;
  flex-direction: column;
  background: #f5f5f5;
  overflow: hidden;
`,rr=t.div`
  display: grid;
  grid-template-columns: 1fr 2fr 1fr;
  grid-template-rows: 1fr auto; /* Ligne contenu + ligne footer */
  flex: 1;
  overflow: hidden;
  max-height: calc(100vh - 50px);
  gap: 0;

  @media (max-width: 1200px) {
    grid-template-columns: 1fr 2fr;
  }

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
    grid-template-rows: auto; /* Pas de footer fixe sur mobile */
    overflow-y: auto;
    overflow-x: hidden;
  }
`,ir=t.div`
  background: white;
  border-right: 1px solid #e0e0e0;
  padding: 1rem;
  display: flex;
  flex-direction: column;
  overflow-y: auto;

  /* Hide numpad column when in category/subcategory mode */
  &:has(+ [data-wizard-step="idle"]) {
    display: none;
  }

  @media (max-width: 768px) {
    border-right: none;
    border-bottom: 1px solid #e0e0e0;
    min-height: 200px;
    padding: 0.75rem;
  }
`,nr=t.div`
  background: white;
  border-right: 1px solid #e0e0e0;
  padding: 1.5rem;
  overflow: hidden;
  display: grid;
  grid-template-rows: 1fr auto; /* Contenu + Footer */
  gap: 1rem;

  /* Span 2 columns when in category/subcategory mode (numpad hidden) */
  &[data-wizard-step="idle"] {
    grid-column: span 2;
  }

  @media (max-width: 1200px) {
    border-right: none;
  }

  @media (max-width: 768px) {
    padding: 1rem;
    overflow: visible;
    grid-column: span 1;
    grid-template-rows: auto; /* Pas de footer fixe sur mobile */
  }
`,or=t.div`
  background: white;
  padding: 1rem;
  overflow: hidden;
  display: grid;
  grid-template-rows: 1fr auto; /* Contenu + Footer */

  @media (max-width: 1200px) {
    display: none;
  }

  @media (max-width: 768px) {
    display: grid;
    border-top: 1px solid #e0e0e0;
    grid-template-rows: auto; /* Pas de footer fixe sur mobile */
  }
`,gr=()=>{const r=$e(),[i,w]=s.useState(!1),[h,c]=s.useState(null),[l,a]=s.useState(!1),[n,k]=s.useState(""),[v,S]=s.useState(""),[x,u]=s.useState(""),[f,E]=s.useState(""),[g,$]=s.useState(""),[M,B]=s.useState(""),[y,A]=s.useState("idle"),{currentSession:I,currentSaleItems:T,addSaleItem:m,removeSaleItem:z,updateSaleItem:q,submitSale:V,loading:H}=de(),{currentUser:D}=ze(),{getCategoryById:Q,fetchCategories:G}=ee();s.useEffect(()=>{G()},[G]),s.useEffect(()=>{I||r("/cash-register")},[I,r]);const te=p=>{const j=Q(p.category),N=p.subcategory?Q(p.subcategory):null;console.log("handleItemComplete debug:",{itemData:p,category:j,subcategory:N,categoryName:j==null?void 0:j.name,subcategoryName:N==null?void 0:N.name}),m({category:p.category,subcategory:p.subcategory,categoryName:j==null?void 0:j.name,subcategoryName:N==null?void 0:N.name,quantity:p.quantity,weight:p.weight,price:p.price,total:p.total})},d=async()=>{T.length!==0&&w(!0)},o=()=>{r("/cash-register/session/close")};if(!I)return null;const F=s.useMemo(()=>T.reduce((p,j)=>p+(j.total||0),0),[T]),P=D&&(`${D.first_name||""} ${D.last_name||""}`.trim()||D.username)||"Caissier",W=()=>{w(!1),c(null)},C=async p=>{if(c(p),w(!1),await V(T,p))a(!0),setTimeout(()=>{a(!1)},3e3);else{const N=de.getState().error;alert(`❌ Erreur lors de l'enregistrement de la vente: ${N||"Erreur inconnue"}`)}},b=()=>{switch(y){case"quantity":return n;case"price":return x;case"weight":return g;default:return""}},K=()=>{switch(y){case"quantity":return v;case"price":return f;case"weight":return M;default:return""}},L=p=>{switch(y){case"quantity":k(p);break;case"price":u(p);break;case"weight":$(p);break}},_=p=>{switch(y){case"quantity":S(p);break;case"price":E(p);break;case"weight":B(p);break}},ne=p=>{const N=b()+p;y==="quantity"?/^\d*$/.test(N)&&parseInt(N||"0",10)<=9999&&(k(N),S("")):y==="price"?/^\d*\.?\d{0,2}$/.test(N)&&parseFloat(N||"0")<=9999.99&&(u(N),E("")):y==="weight"&&/^\d*\.?\d{0,2}$/.test(N)&&parseFloat(N||"0")<=9999.99&&($(N),B(""))},oe=()=>{L(""),_("")},ae=()=>{L(b().slice(0,-1))},se=()=>{const p=b();(y==="price"||y==="weight")&&!p.includes(".")&&L(p+".")},je={quantityValue:n,quantityError:v,priceValue:x,priceError:f,weightValue:g,weightError:M,setQuantityValue:k,setQuantityError:S,setPriceValue:u,setPriceError:E,setWeightValue:$,setWeightError:B,setMode:A};return s.useEffect(()=>{const p=j=>{j.target instanceof HTMLInputElement||j.target instanceof HTMLTextAreaElement||(j.key>="0"&&j.key<="9"&&(j.preventDefault(),ne(j.key)),(j.key==="."||j.key===",")&&(j.preventDefault(),se()),j.key==="Backspace"&&(j.preventDefault(),ae()),j.key==="Escape"&&(j.preventDefault(),oe()))};return document.addEventListener("keydown",p),()=>document.removeEventListener("keydown",p)},[y,n,x,g]),e.jsxs(tr,{children:[e.jsx(Kt,{cashierName:P,sessionId:I.id,onCloseSession:o,isLoading:H}),e.jsxs(rr,{children:[e.jsx(ir,{children:e.jsx(er,{value:b(),error:K(),onDigit:ne,onClear:oe,onBackspace:ae,onDecimal:y==="price"||y==="weight"?se:void 0,unit:y==="price"?"€":y==="weight"?"kg":"",showDecimal:y==="price"||y==="weight",placeholder:"0"})}),e.jsxs(nr,{"data-wizard-step":y,children:[e.jsx(gt,{onItemComplete:te,numpadCallbacks:je,currentMode:y}),l&&e.jsx("div",{style:{position:"fixed",top:"50%",left:"50%",transform:"translate(-50%, -50%)",background:"#4caf50",color:"white",padding:"1rem 2rem",borderRadius:"8px",fontSize:"1.1rem",fontWeight:"bold",zIndex:3e3,boxShadow:"0 4px 12px rgba(0,0,0,0.3)",textAlign:"center"},children:"✅ Vente enregistrée avec succès !"})]}),e.jsx(or,{children:e.jsx(Vt,{items:T.map(p=>({...p,total:p.total})),onRemoveItem:z,onUpdateItem:q,onFinalizeSale:d,loading:H})})]}),e.jsx(At,{open:i,totalAmount:F,onCancel:W,onConfirm:C})]})};export{gr as default};
//# sourceMappingURL=Sale-pa4a9jNP.js.map
