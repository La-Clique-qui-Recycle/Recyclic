import{j as n}from"./admin-D2I4SZO-.js";import{r as a}from"./vendor-cDl5Ih67.js";import{d as o}from"./ui-DXFJp4I_.js";import{e as v}from"./api-XIr9E-cT.js";import{j as S,k as C}from"./cash-Cdpp_gQO.js";import"./stores-CmSlgjNa.js";function w(){const e=localStorage.getItem("token");return e?{Authorization:`Bearer ${e}`}:{}}const y={async listCashSessionReports(){return(await v.client.get("/v1/admin/reports/cash-sessions",{headers:w()})).data},async downloadCashSessionReport(e){return(await v.client.get(`/v1/admin/reports/cash-sessions/${e}`,{headers:w(),responseType:"blob"})).data}},$=o.div`
  padding: 24px;
  background: #ffffff;
  border-radius: 12px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
`,E=o.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 24px;
`,z=o.h1`
  margin: 0;
  font-size: 1.8rem;
  color: #1b5e20;
`,L=o.div`
  display: flex;
  gap: 12px;
`,k=o.button`
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 10px 16px;
  border-radius: 6px;
  border: none;
  cursor: pointer;
  font-weight: 500;
  font-size: 0.95rem;
  transition: background-color 0.2s ease;
  background: ${e=>e.$variant==="ghost"?"transparent":"#2e7d32"};
  color: ${e=>e.$variant==="ghost"?"#2e7d32":"#ffffff"};
  border: ${e=>e.$variant==="ghost"?"1px solid #2e7d32":"none"};

  &:hover {
    background: ${e=>e.$variant==="ghost"?"rgba(46, 125, 50, 0.1)":"#1b5e20"};
  }
`,T=o.div`
  display: grid;
  grid-template-columns: 3fr 1fr 2fr 120px;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  overflow: hidden;
`,A=o.div`
  display: contents;
  background: #f5f5f5;
  font-weight: 600;
  text-transform: uppercase;
  font-size: 0.8rem;
`,d=o.div`
  padding: 14px 16px;
  border-bottom: 1px solid #e0e0e0;
`,D=o.div`
  display: contents;

  &:nth-child(even) div {
    background: #fafafa;
  }
`,c=o.div`
  padding: 16px;
  border-bottom: 1px solid #f0f0f0;
  font-size: 0.95rem;
`,H=o.div`
  padding: 48px;
  text-align: center;
  color: #666;
  background: #fafafa;
  border-radius: 8px;
  border: 1px dashed #d0d0d0;
`,U=o.div`
  padding: 16px;
  border: 1px solid #e53935;
  background: #ffebee;
  color: #b71c1c;
  border-radius: 8px;
  margin-bottom: 16px;
`,B=o.div`
  padding: 48px;
  text-align: center;
  color: #777;
`,F=o(k)`
  font-size: 0.9rem;
  padding: 8px 12px;
  justify-content: center;
`;function _(e){if(e<1024)return`${e} o`;const s=e/1024;return s<1024?`${s.toFixed(1)} ko`:`${(s/1024).toFixed(2)} Mo`}function I(e){return new Date(e).toLocaleString("fr-FR")}const K=()=>{const[e,s]=a.useState([]),[l,x]=a.useState(!0),[u,p]=a.useState(null),[g,h]=a.useState(null),m=async()=>{x(!0),p(null);try{const t=await y.listCashSessionReports();s(t.reports)}catch(t){p(t instanceof Error?t.message:"Impossible de charger les rapports.")}finally{x(!1)}};a.useEffect(()=>{m()},[]);const R=async t=>{var b;try{h(t.filename);const i=await y.downloadCashSessionReport(t.download_url),j=window.URL.createObjectURL(i),r=document.createElement("a");r.href=j,r.download=t.filename,document.body.appendChild(r);try{typeof r.click=="function"?r.click():r.dispatchEvent(new MouseEvent("click",{bubbles:!0}))}catch(f){if(!(f instanceof Error)||!((b=f.message)!=null&&b.includes("navigation")))throw f}finally{document.body.removeChild(r),window.URL.revokeObjectURL(j)}}catch(i){p(i instanceof Error?i.message:"Le téléchargement du rapport a échoué.")}finally{h(null)}};return n.jsxs($,{children:[n.jsxs(E,{children:[n.jsx(z,{children:"Rapports de sessions de caisse"}),n.jsx(L,{children:n.jsxs(k,{$variant:"ghost",onClick:m,disabled:l,children:[n.jsx(S,{size:16})," Rafraîchir"]})})]}),u&&n.jsx(U,{children:u}),l?n.jsx(B,{children:"Chargement des rapports..."}):e.length===0?n.jsx(H,{children:"Aucun rapport n'a encore été généré."}):n.jsxs(T,{children:[n.jsxs(A,{children:[n.jsx(d,{children:"Rapport"}),n.jsx(d,{children:"Taille"}),n.jsx(d,{children:"Généré le"}),n.jsx(d,{children:"Actions"})]}),e.map(t=>n.jsxs(D,{children:[n.jsx(c,{children:t.filename}),n.jsx(c,{children:_(t.size_bytes)}),n.jsx(c,{children:I(t.modified_at)}),n.jsx(c,{children:n.jsxs(F,{onClick:()=>R(t),disabled:g===t.filename,"data-testid":"download-report-button",children:[n.jsx(C,{size:16})," ",g===t.filename?"Téléchargement...":"Télécharger"]})})]},t.filename))]})]})};export{K as default};
//# sourceMappingURL=Reports-LkXh9947.js.map
