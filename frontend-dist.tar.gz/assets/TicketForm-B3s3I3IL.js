import{j as s}from"./admin-D2I4SZO-.js";import{r as u,a as vn,u as zn,j as wn,R as nt}from"./vendor-cDl5Ih67.js";import{d as h}from"./ui-DXFJp4I_.js";import{u as Sn,r as ce}from"./index-uXXVmU2V.js";import{A as kn,o as Cn,S as it,f as rt,T as ot}from"./cash-Cdpp_gQO.js";import{u as jn}from"./categoryStore-BF1R9drw.js";import"./api-XIr9E-cT.js";import"./stores-CmSlgjNa.js";import"./categoryService-KCFOthxd.js";const He=u.createContext(null);He.displayName="PanelGroupContext";const G={group:"data-panel-group",groupDirection:"data-panel-group-direction",groupId:"data-panel-group-id",panel:"data-panel",panelCollapsible:"data-panel-collapsible",panelId:"data-panel-id",panelSize:"data-panel-size",resizeHandle:"data-resize-handle",resizeHandleActive:"data-resize-handle-active",resizeHandleEnabled:"data-panel-resize-handle-enabled",resizeHandleId:"data-panel-resize-handle-id",resizeHandleState:"data-resize-handle-state"},Qe=10,he=u.useLayoutEffect,st=vn.useId,En=typeof st=="function"?st:()=>null;let Pn=0;function et(e=null){const t=En(),n=u.useRef(e||t||null);return n.current===null&&(n.current=""+Pn++),e??n.current}function Zt({children:e,className:t="",collapsedSize:n,collapsible:r,defaultSize:a,forwardedRef:o,id:l,maxSize:c,minSize:d,onCollapse:z,onExpand:I,onResize:g,order:f,style:j,tagName:w="div",...A}){const b=u.useContext(He);if(b===null)throw Error("Panel components must be rendered within a PanelGroup container");const{collapsePanel:S,expandPanel:R,getPanelSize:L,getPanelStyle:T,groupId:q,isPanelCollapsed:$,reevaluatePanelConstraints:E,registerPanel:V,resizePanel:ne,unregisterPanel:O}=b,K=et(l),M=u.useRef({callbacks:{onCollapse:z,onExpand:I,onResize:g},constraints:{collapsedSize:n,collapsible:r,defaultSize:a,maxSize:c,minSize:d},id:K,idIsFromProps:l!==void 0,order:f});u.useRef({didLogMissingDefaultSizeWarning:!1}),he(()=>{const{callbacks:W,constraints:_}=M.current,Y={..._};M.current.id=K,M.current.idIsFromProps=l!==void 0,M.current.order=f,W.onCollapse=z,W.onExpand=I,W.onResize=g,_.collapsedSize=n,_.collapsible=r,_.defaultSize=a,_.maxSize=c,_.minSize=d,(Y.collapsedSize!==_.collapsedSize||Y.collapsible!==_.collapsible||Y.maxSize!==_.maxSize||Y.minSize!==_.minSize)&&E(M.current,Y)}),he(()=>{const W=M.current;return V(W),()=>{O(W)}},[f,K,V,O]),u.useImperativeHandle(o,()=>({collapse:()=>{S(M.current)},expand:W=>{R(M.current,W)},getId(){return K},getSize(){return L(M.current)},isCollapsed(){return $(M.current)},isExpanded(){return!$(M.current)},resize:W=>{ne(M.current,W)}}),[S,R,L,$,K,ne]);const ie=T(M.current,a);return u.createElement(w,{...A,children:e,className:t,id:K,style:{...ie,...j},[G.groupId]:q,[G.panel]:"",[G.panelCollapsible]:r||void 0,[G.panelId]:K,[G.panelSize]:parseFloat(""+ie.flexGrow).toFixed(1)})}const Ne=u.forwardRef((e,t)=>u.createElement(Zt,{...e,forwardedRef:t}));Zt.displayName="Panel";Ne.displayName="forwardRef(Panel)";let qe=null,Me=-1,de=null;function In(e,t,n){const r=(t&rn)!==0,a=(t&on)!==0,o=(t&sn)!==0,l=(t&an)!==0;if(t){if(r)return o?"se-resize":l?"ne-resize":"e-resize";if(a)return o?"sw-resize":l?"nw-resize":"w-resize";if(o)return"s-resize";if(l)return"n-resize"}switch(e){case"horizontal":return"ew-resize";case"intersection":return"move";case"vertical":return"ns-resize"}}function Rn(){de!==null&&(document.head.removeChild(de),qe=null,de=null,Me=-1)}function We(e,t,n){var r,a;const o=In(e,t);if(qe!==o){if(qe=o,de===null&&(de=document.createElement("style"),document.head.appendChild(de)),Me>=0){var l;(l=de.sheet)===null||l===void 0||l.removeRule(Me)}Me=(r=(a=de.sheet)===null||a===void 0?void 0:a.insertRule(`*{cursor: ${o} !important;}`))!==null&&r!==void 0?r:-1}}function Qt(e){return e.type==="keydown"}function en(e){return e.type.startsWith("pointer")}function tn(e){return e.type.startsWith("mouse")}function Be(e){if(en(e)){if(e.isPrimary)return{x:e.clientX,y:e.clientY}}else if(tn(e))return{x:e.clientX,y:e.clientY};return{x:1/0,y:1/0}}function An(){if(typeof matchMedia=="function")return matchMedia("(pointer:coarse)").matches?"coarse":"fine"}function Ln(e,t,n){return e.x<t.x+t.width&&e.x+e.width>t.x&&e.y<t.y+t.height&&e.y+e.height>t.y}function $n(e,t){if(e===t)throw new Error("Cannot compare node with itself");const n={a:ct(e),b:ct(t)};let r;for(;n.a.at(-1)===n.b.at(-1);)e=n.a.pop(),t=n.b.pop(),r=e;P(r,"Stacking order can only be calculated for elements with a common ancestor");const a={a:lt(at(n.a)),b:lt(at(n.b))};if(a.a===a.b){const o=r.childNodes,l={a:n.a.at(-1),b:n.b.at(-1)};let c=o.length;for(;c--;){const d=o[c];if(d===l.a)return 1;if(d===l.b)return-1}}return Math.sign(a.a-a.b)}const Dn=/\b(?:position|zIndex|opacity|transform|webkitTransform|mixBlendMode|filter|webkitFilter|isolation)\b/;function Nn(e){var t;const n=getComputedStyle((t=nn(e))!==null&&t!==void 0?t:e).display;return n==="flex"||n==="inline-flex"}function Mn(e){const t=getComputedStyle(e);return!!(t.position==="fixed"||t.zIndex!=="auto"&&(t.position!=="static"||Nn(e))||+t.opacity<1||"transform"in t&&t.transform!=="none"||"webkitTransform"in t&&t.webkitTransform!=="none"||"mixBlendMode"in t&&t.mixBlendMode!=="normal"||"filter"in t&&t.filter!=="none"||"webkitFilter"in t&&t.webkitFilter!=="none"||"isolation"in t&&t.isolation==="isolate"||Dn.test(t.willChange)||t.webkitOverflowScrolling==="touch")}function at(e){let t=e.length;for(;t--;){const n=e[t];if(P(n,"Missing node"),Mn(n))return n}return null}function lt(e){return e&&Number(getComputedStyle(e).zIndex)||0}function ct(e){const t=[];for(;e;)t.push(e),e=nn(e);return t}function nn(e){const{parentNode:t}=e;return t&&t instanceof ShadowRoot?t.host:t}const rn=1,on=2,sn=4,an=8,Tn=An()==="coarse";let re=[],Se=!1,ue=new Map,Fe=new Map;const Ee=new Set;function _n(e,t,n,r,a){var o;const{ownerDocument:l}=t,c={direction:n,element:t,hitAreaMargins:r,setResizeHandlerState:a},d=(o=ue.get(l))!==null&&o!==void 0?o:0;return ue.set(l,d+1),Ee.add(c),Te(),function(){var I;Fe.delete(e),Ee.delete(c);const g=(I=ue.get(l))!==null&&I!==void 0?I:1;if(ue.set(l,g-1),Te(),g===1&&ue.delete(l),re.includes(c)){const f=re.indexOf(c);f>=0&&re.splice(f,1),Ge(),a("up",!0,null)}}}function Hn(e){const{target:t}=e,{x:n,y:r}=Be(e);Se=!0,tt({target:t,x:n,y:r}),Te(),re.length>0&&(_e("down",e),Ge(),e.preventDefault(),ln(t)||e.stopImmediatePropagation())}function Oe(e){const{x:t,y:n}=Be(e);if(Se&&e.type!=="pointerleave"&&e.buttons===0&&(Se=!1,_e("up",e)),!Se){const{target:r}=e;tt({target:r,x:t,y:n})}_e("move",e),Ge(),re.length>0&&e.preventDefault()}function Ue(e){const{target:t}=e,{x:n,y:r}=Be(e);Fe.clear(),Se=!1,re.length>0&&(e.preventDefault(),ln(t)||e.stopImmediatePropagation()),_e("up",e),tt({target:t,x:n,y:r}),Ge(),Te()}function ln(e){let t=e;for(;t;){if(t.hasAttribute(G.resizeHandle))return!0;t=t.parentElement}return!1}function tt({target:e,x:t,y:n}){re.splice(0);let r=null;(e instanceof HTMLElement||e instanceof SVGElement)&&(r=e),Ee.forEach(a=>{const{element:o,hitAreaMargins:l}=a,c=o.getBoundingClientRect(),{bottom:d,left:z,right:I,top:g}=c,f=Tn?l.coarse:l.fine;if(t>=z-f&&t<=I+f&&n>=g-f&&n<=d+f){if(r!==null&&document.contains(r)&&o!==r&&!o.contains(r)&&!r.contains(o)&&$n(r,o)>0){let w=r,A=!1;for(;w&&!w.contains(o);){if(Ln(w.getBoundingClientRect(),c)){A=!0;break}w=w.parentElement}if(A)return}re.push(a)}})}function Ve(e,t){Fe.set(e,t)}function Ge(){let e=!1,t=!1;re.forEach(r=>{const{direction:a}=r;a==="horizontal"?e=!0:t=!0});let n=0;Fe.forEach(r=>{n|=r}),e&&t?We("intersection",n):e?We("horizontal",n):t?We("vertical",n):Rn()}let Ye;function Te(){var e;(e=Ye)===null||e===void 0||e.abort(),Ye=new AbortController;const t={capture:!0,signal:Ye.signal};Ee.size&&(Se?(re.length>0&&ue.forEach((n,r)=>{const{body:a}=r;n>0&&(a.addEventListener("contextmenu",Ue,t),a.addEventListener("pointerleave",Oe,t),a.addEventListener("pointermove",Oe,t))}),ue.forEach((n,r)=>{const{body:a}=r;a.addEventListener("pointerup",Ue,t),a.addEventListener("pointercancel",Ue,t)})):ue.forEach((n,r)=>{const{body:a}=r;n>0&&(a.addEventListener("pointerdown",Hn,t),a.addEventListener("pointermove",Oe,t))}))}function _e(e,t){Ee.forEach(n=>{const{setResizeHandlerState:r}=n,a=re.includes(n);r(e,a,t)})}function Bn(){const[e,t]=u.useState(0);return u.useCallback(()=>t(n=>n+1),[])}function P(e,t){if(!e)throw console.error(t),Error(t)}function ge(e,t,n=Qe){return e.toFixed(n)===t.toFixed(n)?0:e>t?1:-1}function le(e,t,n=Qe){return ge(e,t,n)===0}function te(e,t,n){return ge(e,t,n)===0}function Fn(e,t,n){if(e.length!==t.length)return!1;for(let r=0;r<e.length;r++){const a=e[r],o=t[r];if(!te(a,o,n))return!1}return!0}function we({panelConstraints:e,panelIndex:t,size:n}){const r=e[t];P(r!=null,`Panel constraints not found for index ${t}`);let{collapsedSize:a=0,collapsible:o,maxSize:l=100,minSize:c=0}=r;if(ge(n,c)<0)if(o){const d=(a+c)/2;ge(n,d)<0?n=a:n=c}else n=c;return n=Math.min(l,n),n=parseFloat(n.toFixed(Qe)),n}function ke({delta:e,initialLayout:t,panelConstraints:n,pivotIndices:r,prevLayout:a,trigger:o}){if(te(e,0))return t;const l=[...t],[c,d]=r;P(c!=null,"Invalid first pivot index"),P(d!=null,"Invalid second pivot index");let z=0;if(o==="keyboard"){{const g=e<0?d:c,f=n[g];P(f,`Panel constraints not found for index ${g}`);const{collapsedSize:j=0,collapsible:w,minSize:A=0}=f;if(w){const b=t[g];if(P(b!=null,`Previous layout not found for panel index ${g}`),te(b,j)){const S=A-b;ge(S,Math.abs(e))>0&&(e=e<0?0-S:S)}}}{const g=e<0?c:d,f=n[g];P(f,`No panel constraints found for index ${g}`);const{collapsedSize:j=0,collapsible:w,minSize:A=0}=f;if(w){const b=t[g];if(P(b!=null,`Previous layout not found for panel index ${g}`),te(b,A)){const S=b-j;ge(S,Math.abs(e))>0&&(e=e<0?0-S:S)}}}}{const g=e<0?1:-1;let f=e<0?d:c,j=0;for(;;){const A=t[f];P(A!=null,`Previous layout not found for panel index ${f}`);const S=we({panelConstraints:n,panelIndex:f,size:100})-A;if(j+=S,f+=g,f<0||f>=n.length)break}const w=Math.min(Math.abs(e),Math.abs(j));e=e<0?0-w:w}{let f=e<0?c:d;for(;f>=0&&f<n.length;){const j=Math.abs(e)-Math.abs(z),w=t[f];P(w!=null,`Previous layout not found for panel index ${f}`);const A=w-j,b=we({panelConstraints:n,panelIndex:f,size:A});if(!te(w,b)&&(z+=w-b,l[f]=b,z.toFixed(3).localeCompare(Math.abs(e).toFixed(3),void 0,{numeric:!0})>=0))break;e<0?f--:f++}}if(Fn(a,l))return a;{const g=e<0?d:c,f=t[g];P(f!=null,`Previous layout not found for panel index ${g}`);const j=f+z,w=we({panelConstraints:n,panelIndex:g,size:j});if(l[g]=w,!te(w,j)){let A=j-w,S=e<0?d:c;for(;S>=0&&S<n.length;){const R=l[S];P(R!=null,`Previous layout not found for panel index ${S}`);const L=R+A,T=we({panelConstraints:n,panelIndex:S,size:L});if(te(R,T)||(A-=T-R,l[S]=T),te(A,0))break;e>0?S--:S++}}}const I=l.reduce((g,f)=>f+g,0);return te(I,100)?l:a}function Gn({layout:e,panelsArray:t,pivotIndices:n}){let r=0,a=100,o=0,l=0;const c=n[0];P(c!=null,"No pivot index found"),t.forEach((g,f)=>{const{constraints:j}=g,{maxSize:w=100,minSize:A=0}=j;f===c?(r=A,a=w):(o+=A,l+=w)});const d=Math.min(a,100-o),z=Math.max(r,100-l),I=e[c];return{valueMax:d,valueMin:z,valueNow:I}}function Pe(e,t=document){return Array.from(t.querySelectorAll(`[${G.resizeHandleId}][data-panel-group-id="${e}"]`))}function cn(e,t,n=document){const a=Pe(e,n).findIndex(o=>o.getAttribute(G.resizeHandleId)===t);return a??null}function dn(e,t,n){const r=cn(e,t,n);return r!=null?[r,r+1]:[-1,-1]}function Kn(e){return e instanceof HTMLElement?!0:typeof e=="object"&&e!==null&&"tagName"in e&&"getAttribute"in e}function un(e,t=document){if(Kn(t)&&t.dataset.panelGroupId==e)return t;const n=t.querySelector(`[data-panel-group][data-panel-group-id="${e}"]`);return n||null}function Ke(e,t=document){const n=t.querySelector(`[${G.resizeHandleId}="${e}"]`);return n||null}function Wn(e,t,n,r=document){var a,o,l,c;const d=Ke(t,r),z=Pe(e,r),I=d?z.indexOf(d):-1,g=(a=(o=n[I])===null||o===void 0?void 0:o.id)!==null&&a!==void 0?a:null,f=(l=(c=n[I+1])===null||c===void 0?void 0:c.id)!==null&&l!==void 0?l:null;return[g,f]}function On({committedValuesRef:e,eagerValuesRef:t,groupId:n,layout:r,panelDataArray:a,panelGroupElement:o,setLayout:l}){u.useRef({didWarnAboutMissingResizeHandle:!1}),he(()=>{if(!o)return;const c=Pe(n,o);for(let d=0;d<a.length-1;d++){const{valueMax:z,valueMin:I,valueNow:g}=Gn({layout:r,panelsArray:a,pivotIndices:[d,d+1]}),f=c[d];if(f!=null){const j=a[d];P(j,`No panel data found for index "${d}"`),f.setAttribute("aria-controls",j.id),f.setAttribute("aria-valuemax",""+Math.round(z)),f.setAttribute("aria-valuemin",""+Math.round(I)),f.setAttribute("aria-valuenow",g!=null?""+Math.round(g):"")}}return()=>{c.forEach((d,z)=>{d.removeAttribute("aria-controls"),d.removeAttribute("aria-valuemax"),d.removeAttribute("aria-valuemin"),d.removeAttribute("aria-valuenow")})}},[n,r,a,o]),u.useEffect(()=>{if(!o)return;const c=t.current;P(c,"Eager values not found");const{panelDataArray:d}=c,z=un(n,o);P(z!=null,`No group found for id "${n}"`);const I=Pe(n,o);P(I,`No resize handles found for group id "${n}"`);const g=I.map(f=>{const j=f.getAttribute(G.resizeHandleId);P(j,"Resize handle element has no handle id attribute");const[w,A]=Wn(n,j,d,o);if(w==null||A==null)return()=>{};const b=S=>{if(!S.defaultPrevented)switch(S.key){case"Enter":{S.preventDefault();const R=d.findIndex(L=>L.id===w);if(R>=0){const L=d[R];P(L,`No panel data found for index ${R}`);const T=r[R],{collapsedSize:q=0,collapsible:$,minSize:E=0}=L.constraints;if(T!=null&&$){const V=ke({delta:te(T,q)?E-q:q-T,initialLayout:r,panelConstraints:d.map(ne=>ne.constraints),pivotIndices:dn(n,j,o),prevLayout:r,trigger:"keyboard"});r!==V&&l(V)}}break}}};return f.addEventListener("keydown",b),()=>{f.removeEventListener("keydown",b)}});return()=>{g.forEach(f=>f())}},[o,e,t,n,r,a,l])}function dt(e,t){if(e.length!==t.length)return!1;for(let n=0;n<e.length;n++)if(e[n]!==t[n])return!1;return!0}function fn(e,t){const n=e==="horizontal",{x:r,y:a}=Be(t);return n?r:a}function Un(e,t,n,r,a){const o=n==="horizontal",l=Ke(t,a);P(l,`No resize handle element found for id "${t}"`);const c=l.getAttribute(G.groupId);P(c,"Resize handle element has no group id attribute");let{initialCursorPosition:d}=r;const z=fn(n,e),I=un(c,a);P(I,`No group element found for id "${c}"`);const g=I.getBoundingClientRect(),f=o?g.width:g.height;return(z-d)/f*100}function Vn(e,t,n,r,a,o){if(Qt(e)){const l=n==="horizontal";let c=0;e.shiftKey?c=100:a!=null?c=a:c=10;let d=0;switch(e.key){case"ArrowDown":d=l?0:c;break;case"ArrowLeft":d=l?-c:0;break;case"ArrowRight":d=l?c:0;break;case"ArrowUp":d=l?0:-c;break;case"End":d=100;break;case"Home":d=-100;break}return d}else return r==null?0:Un(e,t,n,r,o)}function Yn({panelDataArray:e}){const t=Array(e.length),n=e.map(o=>o.constraints);let r=0,a=100;for(let o=0;o<e.length;o++){const l=n[o];P(l,`Panel constraints not found for index ${o}`);const{defaultSize:c}=l;c!=null&&(r++,t[o]=c,a-=c)}for(let o=0;o<e.length;o++){const l=n[o];P(l,`Panel constraints not found for index ${o}`);const{defaultSize:c}=l;if(c!=null)continue;const d=e.length-r,z=a/d;r++,t[o]=z,a-=z}return t}function be(e,t,n){t.forEach((r,a)=>{const o=e[a];P(o,`Panel data not found for index ${a}`);const{callbacks:l,constraints:c,id:d}=o,{collapsedSize:z=0,collapsible:I}=c,g=n[d];if(g==null||r!==g){n[d]=r;const{onCollapse:f,onExpand:j,onResize:w}=l;w&&w(r,g),I&&(f||j)&&(j&&(g==null||le(g,z))&&!le(r,z)&&j(),f&&(g==null||!le(g,z))&&le(r,z)&&f())}})}function Ae(e,t){if(e.length!==t.length)return!1;for(let n=0;n<e.length;n++)if(e[n]!=t[n])return!1;return!0}function qn({defaultSize:e,dragState:t,layout:n,panelData:r,panelIndex:a,precision:o=3}){const l=n[a];let c;return l==null?c=e!=null?e.toFixed(o):"1":r.length===1?c="1":c=l.toFixed(o),{flexBasis:0,flexGrow:c,flexShrink:1,overflow:"hidden",pointerEvents:t!==null?"none":void 0}}function Xn(e,t=10){let n=null;return(...a)=>{n!==null&&clearTimeout(n),n=setTimeout(()=>{e(...a)},t)}}function ut(e){try{if(typeof localStorage<"u")e.getItem=t=>localStorage.getItem(t),e.setItem=(t,n)=>{localStorage.setItem(t,n)};else throw new Error("localStorage not supported in this environment")}catch(t){console.error(t),e.getItem=()=>null,e.setItem=()=>{}}}function pn(e){return`react-resizable-panels:${e}`}function xn(e){return e.map(t=>{const{constraints:n,id:r,idIsFromProps:a,order:o}=t;return a?r:o?`${o}:${JSON.stringify(n)}`:JSON.stringify(n)}).sort((t,n)=>t.localeCompare(n)).join(",")}function hn(e,t){try{const n=pn(e),r=t.getItem(n);if(r){const a=JSON.parse(r);if(typeof a=="object"&&a!=null)return a}}catch{}return null}function Jn(e,t,n){var r,a;const o=(r=hn(e,n))!==null&&r!==void 0?r:{},l=xn(t);return(a=o[l])!==null&&a!==void 0?a:null}function Zn(e,t,n,r,a){var o;const l=pn(e),c=xn(t),d=(o=hn(e,a))!==null&&o!==void 0?o:{};d[c]={expandToSizes:Object.fromEntries(n.entries()),layout:r};try{a.setItem(l,JSON.stringify(d))}catch(z){console.error(z)}}function ft({layout:e,panelConstraints:t}){const n=[...e],r=n.reduce((o,l)=>o+l,0);if(n.length!==t.length)throw Error(`Invalid ${t.length} panel layout: ${n.map(o=>`${o}%`).join(", ")}`);if(!te(r,100)&&n.length>0)for(let o=0;o<t.length;o++){const l=n[o];P(l!=null,`No layout data found for index ${o}`);const c=100/r*l;n[o]=c}let a=0;for(let o=0;o<t.length;o++){const l=n[o];P(l!=null,`No layout data found for index ${o}`);const c=we({panelConstraints:t,panelIndex:o,size:l});l!=c&&(a+=l-c,n[o]=c)}if(!te(a,0))for(let o=0;o<t.length;o++){const l=n[o];P(l!=null,`No layout data found for index ${o}`);const c=l+a,d=we({panelConstraints:t,panelIndex:o,size:c});if(l!==d&&(a-=d-l,n[o]=d,te(a,0)))break}return n}const Qn=100,Ce={getItem:e=>(ut(Ce),Ce.getItem(e)),setItem:(e,t)=>{ut(Ce),Ce.setItem(e,t)}},pt={};function gn({autoSaveId:e=null,children:t,className:n="",direction:r,forwardedRef:a,id:o=null,onLayout:l=null,keyboardResizeBy:c=null,storage:d=Ce,style:z,tagName:I="div",...g}){const f=et(o),j=u.useRef(null),[w,A]=u.useState(null),[b,S]=u.useState([]),R=Bn(),L=u.useRef({}),T=u.useRef(new Map),q=u.useRef(0),$=u.useRef({autoSaveId:e,direction:r,dragState:w,id:f,keyboardResizeBy:c,onLayout:l,storage:d}),E=u.useRef({layout:b,panelDataArray:[],panelDataArrayChanged:!1});u.useRef({didLogIdAndOrderWarning:!1,didLogPanelConstraintsWarning:!1,prevPanelIds:[]}),u.useImperativeHandle(a,()=>({getId:()=>$.current.id,getLayout:()=>{const{layout:x}=E.current;return x},setLayout:x=>{const{onLayout:v}=$.current,{layout:k,panelDataArray:y}=E.current,m=ft({layout:x,panelConstraints:y.map(C=>C.constraints)});dt(k,m)||(S(m),E.current.layout=m,v&&v(m),be(y,m,L.current))}}),[]),he(()=>{$.current.autoSaveId=e,$.current.direction=r,$.current.dragState=w,$.current.id=f,$.current.onLayout=l,$.current.storage=d}),On({committedValuesRef:$,eagerValuesRef:E,groupId:f,layout:b,panelDataArray:E.current.panelDataArray,setLayout:S,panelGroupElement:j.current}),u.useEffect(()=>{const{panelDataArray:x}=E.current;if(e){if(b.length===0||b.length!==x.length)return;let v=pt[e];v==null&&(v=Xn(Zn,Qn),pt[e]=v);const k=[...x],y=new Map(T.current);v(e,k,y,b,d)}},[e,b,d]),u.useEffect(()=>{});const V=u.useCallback(x=>{const{onLayout:v}=$.current,{layout:k,panelDataArray:y}=E.current;if(x.constraints.collapsible){const m=y.map(Q=>Q.constraints),{collapsedSize:C=0,panelSize:D,pivotIndices:N}=xe(y,x,k);if(P(D!=null,`Panel size not found for panel "${x.id}"`),!le(D,C)){T.current.set(x.id,D);const Z=ze(y,x)===y.length-1?D-C:C-D,H=ke({delta:Z,initialLayout:k,panelConstraints:m,pivotIndices:N,prevLayout:k,trigger:"imperative-api"});Ae(k,H)||(S(H),E.current.layout=H,v&&v(H),be(y,H,L.current))}}},[]),ne=u.useCallback((x,v)=>{const{onLayout:k}=$.current,{layout:y,panelDataArray:m}=E.current;if(x.constraints.collapsible){const C=m.map(ee=>ee.constraints),{collapsedSize:D=0,panelSize:N=0,minSize:Q=0,pivotIndices:Z}=xe(m,x,y),H=v??Q;if(le(N,D)){const ee=T.current.get(x.id),fe=ee!=null&&ee>=H?ee:H,me=ze(m,x)===m.length-1?N-fe:fe-N,i=ke({delta:me,initialLayout:y,panelConstraints:C,pivotIndices:Z,prevLayout:y,trigger:"imperative-api"});Ae(y,i)||(S(i),E.current.layout=i,k&&k(i),be(m,i,L.current))}}},[]),O=u.useCallback(x=>{const{layout:v,panelDataArray:k}=E.current,{panelSize:y}=xe(k,x,v);return P(y!=null,`Panel size not found for panel "${x.id}"`),y},[]),K=u.useCallback((x,v)=>{const{panelDataArray:k}=E.current,y=ze(k,x);return qn({defaultSize:v,dragState:w,layout:b,panelData:k,panelIndex:y})},[w,b]),M=u.useCallback(x=>{const{layout:v,panelDataArray:k}=E.current,{collapsedSize:y=0,collapsible:m,panelSize:C}=xe(k,x,v);return P(C!=null,`Panel size not found for panel "${x.id}"`),m===!0&&le(C,y)},[]),ie=u.useCallback(x=>{const{layout:v,panelDataArray:k}=E.current,{collapsedSize:y=0,collapsible:m,panelSize:C}=xe(k,x,v);return P(C!=null,`Panel size not found for panel "${x.id}"`),!m||ge(C,y)>0},[]),W=u.useCallback(x=>{const{panelDataArray:v}=E.current;v.push(x),v.sort((k,y)=>{const m=k.order,C=y.order;return m==null&&C==null?0:m==null?-1:C==null?1:m-C}),E.current.panelDataArrayChanged=!0,R()},[R]);he(()=>{if(E.current.panelDataArrayChanged){E.current.panelDataArrayChanged=!1;const{autoSaveId:x,onLayout:v,storage:k}=$.current,{layout:y,panelDataArray:m}=E.current;let C=null;if(x){const N=Jn(x,m,k);N&&(T.current=new Map(Object.entries(N.expandToSizes)),C=N.layout)}C==null&&(C=Yn({panelDataArray:m}));const D=ft({layout:C,panelConstraints:m.map(N=>N.constraints)});dt(y,D)||(S(D),E.current.layout=D,v&&v(D),be(m,D,L.current))}}),he(()=>{const x=E.current;return()=>{x.layout=[]}},[]);const _=u.useCallback(x=>{let v=!1;const k=j.current;return k&&window.getComputedStyle(k,null).getPropertyValue("direction")==="rtl"&&(v=!0),function(m){m.preventDefault();const C=j.current;if(!C)return()=>null;const{direction:D,dragState:N,id:Q,keyboardResizeBy:Z,onLayout:H}=$.current,{layout:ee,panelDataArray:fe}=E.current,{initialLayout:pe}=N??{},me=dn(Q,x,C);let i=Vn(m,x,D,N,Z,C);const p=D==="horizontal";p&&v&&(i=-i);const B=fe.map(yn=>yn.constraints),F=ke({delta:i,initialLayout:pe??ee,panelConstraints:B,pivotIndices:me,prevLayout:ee,trigger:Qt(m)?"keyboard":"mouse-or-touch"}),Re=!Ae(ee,F);(en(m)||tn(m))&&q.current!=i&&(q.current=i,!Re&&i!==0?p?Ve(x,i<0?rn:on):Ve(x,i<0?sn:an):Ve(x,0)),Re&&(S(F),E.current.layout=F,H&&H(F),be(fe,F,L.current))}},[]),Y=u.useCallback((x,v)=>{const{onLayout:k}=$.current,{layout:y,panelDataArray:m}=E.current,C=m.map(ee=>ee.constraints),{panelSize:D,pivotIndices:N}=xe(m,x,y);P(D!=null,`Panel size not found for panel "${x.id}"`);const Z=ze(m,x)===m.length-1?D-v:v-D,H=ke({delta:Z,initialLayout:y,panelConstraints:C,pivotIndices:N,prevLayout:y,trigger:"imperative-api"});Ae(y,H)||(S(H),E.current.layout=H,k&&k(H),be(m,H,L.current))},[]),oe=u.useCallback((x,v)=>{const{layout:k,panelDataArray:y}=E.current,{collapsedSize:m=0,collapsible:C}=v,{collapsedSize:D=0,collapsible:N,maxSize:Q=100,minSize:Z=0}=x.constraints,{panelSize:H}=xe(y,x,k);H!=null&&(C&&N&&le(H,m)?le(m,D)||Y(x,D):H<Z?Y(x,Z):H>Q&&Y(x,Q))},[Y]),U=u.useCallback((x,v)=>{const{direction:k}=$.current,{layout:y}=E.current;if(!j.current)return;const m=Ke(x,j.current);P(m,`Drag handle element not found for id "${x}"`);const C=fn(k,v);A({dragHandleId:x,dragHandleRect:m.getBoundingClientRect(),initialCursorPosition:C,initialLayout:y})},[]),J=u.useCallback(()=>{A(null)},[]),X=u.useCallback(x=>{const{panelDataArray:v}=E.current,k=ze(v,x);k>=0&&(v.splice(k,1),delete L.current[x.id],E.current.panelDataArrayChanged=!0,R())},[R]),se=u.useMemo(()=>({collapsePanel:V,direction:r,dragState:w,expandPanel:ne,getPanelSize:O,getPanelStyle:K,groupId:f,isPanelCollapsed:M,isPanelExpanded:ie,reevaluatePanelConstraints:oe,registerPanel:W,registerResizeHandle:_,resizePanel:Y,startDragging:U,stopDragging:J,unregisterPanel:X,panelGroupElement:j.current}),[V,w,r,ne,O,K,f,M,ie,oe,W,_,Y,U,J,X]),ae={display:"flex",flexDirection:r==="horizontal"?"row":"column",height:"100%",overflow:"hidden",width:"100%"};return u.createElement(He.Provider,{value:se},u.createElement(I,{...g,children:t,className:n,id:o,ref:j,style:{...ae,...z},[G.group]:"",[G.groupDirection]:r,[G.groupId]:f}))}const mn=u.forwardRef((e,t)=>u.createElement(gn,{...e,forwardedRef:t}));gn.displayName="PanelGroup";mn.displayName="forwardRef(PanelGroup)";function ze(e,t){return e.findIndex(n=>n===t||n.id===t.id)}function xe(e,t,n){const r=ze(e,t),o=r===e.length-1?[r-1,r]:[r,r+1],l=n[r];return{...t.constraints,panelSize:l,pivotIndices:o}}function ei({disabled:e,handleId:t,resizeHandler:n,panelGroupElement:r}){u.useEffect(()=>{if(e||n==null||r==null)return;const a=Ke(t,r);if(a==null)return;const o=l=>{if(!l.defaultPrevented)switch(l.key){case"ArrowDown":case"ArrowLeft":case"ArrowRight":case"ArrowUp":case"End":case"Home":{l.preventDefault(),n(l);break}case"F6":{l.preventDefault();const c=a.getAttribute(G.groupId);P(c,`No group element found for id "${c}"`);const d=Pe(c,r),z=cn(c,t,r);P(z!==null,`No resize element found for id "${t}"`);const I=l.shiftKey?z>0?z-1:d.length-1:z+1<d.length?z+1:0;d[I].focus();break}}};return a.addEventListener("keydown",o),()=>{a.removeEventListener("keydown",o)}},[r,e,t,n])}function Xe({children:e=null,className:t="",disabled:n=!1,hitAreaMargins:r,id:a,onBlur:o,onClick:l,onDragging:c,onFocus:d,onPointerDown:z,onPointerUp:I,style:g={},tabIndex:f=0,tagName:j="div",...w}){var A,b;const S=u.useRef(null),R=u.useRef({onClick:l,onDragging:c,onPointerDown:z,onPointerUp:I});u.useEffect(()=>{R.current.onClick=l,R.current.onDragging=c,R.current.onPointerDown=z,R.current.onPointerUp=I});const L=u.useContext(He);if(L===null)throw Error("PanelResizeHandle components must be rendered within a PanelGroup container");const{direction:T,groupId:q,registerResizeHandle:$,startDragging:E,stopDragging:V,panelGroupElement:ne}=L,O=et(a),[K,M]=u.useState("inactive"),[ie,W]=u.useState(!1),[_,Y]=u.useState(null),oe=u.useRef({state:K});he(()=>{oe.current.state=K}),u.useEffect(()=>{if(n)Y(null);else{const se=$(O);Y(()=>se)}},[n,O,$]);const U=(A=r==null?void 0:r.coarse)!==null&&A!==void 0?A:15,J=(b=r==null?void 0:r.fine)!==null&&b!==void 0?b:5;u.useEffect(()=>{if(n||_==null)return;const se=S.current;P(se,"Element ref not attached");let ae=!1;return _n(O,se,T,{coarse:U,fine:J},(v,k,y)=>{if(!k){M("inactive");return}switch(v){case"down":{M("drag"),ae=!1,P(y,'Expected event to be defined for "down" action'),E(O,y);const{onDragging:m,onPointerDown:C}=R.current;m==null||m(!0),C==null||C();break}case"move":{const{state:m}=oe.current;ae=!0,m!=="drag"&&M("hover"),P(y,'Expected event to be defined for "move" action'),_(y);break}case"up":{M("hover"),V();const{onClick:m,onDragging:C,onPointerUp:D}=R.current;C==null||C(!1),D==null||D(),ae||m==null||m();break}}})},[U,T,n,J,$,O,_,E,V]),ei({disabled:n,handleId:O,resizeHandler:_,panelGroupElement:ne});const X={touchAction:"none",userSelect:"none"};return u.createElement(j,{...w,children:e,className:t,id:a,onBlur:()=>{W(!1),o==null||o()},onFocus:()=>{W(!0),d==null||d()},ref:S,role:"separator",style:{...X,...g},tabIndex:f,[G.groupDirection]:T,[G.groupId]:q,[G.resizeHandle]:"",[G.resizeHandleActive]:K==="drag"?"pointer":ie?"keyboard":void 0,[G.resizeHandleEnabled]:!n,[G.resizeHandleId]:O,[G.resizeHandleState]:K})}Xe.displayName="PanelResizeHandle";const ti=h.div`
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 10px;
  width: 100%;
  max-width: min(400px, 100%);
  margin: 0 auto;

  @media (max-width: 480px) {
    max-width: 100%;
    gap: 8px;
  }
`,xt=h.button`
  padding: 14px;
  font-size: 22px;
  font-weight: bold;
  border: 2px solid #e0e0e0;
  border-radius: 6px;
  background: white;
  cursor: pointer;
  transition: all 0.2s;
  min-height: 55px;
  width: 100%;

  @media (max-width: 480px) {
    padding: 10px;
    font-size: 20px;
    min-height: 50px;
  }

  @media (max-width: 380px) {
    padding: 8px;
    font-size: 18px;
    min-height: 45px;
  }

  &:hover {
    background: #f5f5f5;
    border-color: #2e7d32;
  }

  &:active {
    background: #e8f5e8;
    transform: scale(0.95);
  }

  &.zero {
    grid-column: span 2;
  }

  &.action {
    background: #2e7d32;
    color: white;
    border-color: #2e7d32;

    &:hover {
      background: #1b5e20;
    }
  }
`,ht=({onKeyPress:e,onClear:t,onBackspace:n})=>{const r=["1","2","3","4","5","6","7","8","9","0",".","C"],a=o=>{o==="C"?t():e(o)};return s.jsxs(ti,{role:"group","aria-label":"Pavé numérique de saisie du poids",children:[r.map(o=>s.jsx(xt,{className:o==="0"?"zero":o==="C"?"action":"",onClick:()=>a(o),"aria-label":o==="C"?"Effacer la saisie":o==="."?"Point décimal":`Entrer le chiffre ${o}`,children:o},o)),s.jsx(xt,{className:"action",onClick:n,"aria-label":"Effacer le dernier chiffre",children:"⌫"})]})},ni=h.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 24px;
  background: #2e7d32;
  color: white;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  position: sticky;
  top: 0;
  z-index: 100;

  @media (max-width: 480px) {
    padding: 8px 12px;
  }
`,ii=h.div`
  display: flex;
  align-items: center;
  gap: 16px;

  @media (max-width: 480px) {
    gap: 8px;
  }
`,ri=h.button`
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 16px;
  background: rgba(255, 255, 255, 0.2);
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-size: 14px;
  font-weight: 500;
  transition: background-color 0.2s;

  &:hover {
    background: rgba(255, 255, 255, 0.3);
  }

  @media (max-width: 480px) {
    padding: 6px 10px;
    font-size: 11px;
    gap: 4px;

    svg {
      width: 16px;
      height: 16px;
    }
  }
`,oi=h.h1`
  margin: 0;
  font-size: 1.4rem;
  font-weight: 600;

  @media (max-width: 480px) {
    font-size: 0.9rem;
  }
`,si=h.button`
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 20px;
  background: #ffc107;
  color: #212529;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-size: 16px;
  font-weight: 600;
  transition: all 0.2s;
  box-shadow: 0 2px 4px rgba(0,0,0,0.2);

  &:hover {
    background: #ffca28;
    transform: translateY(-1px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.3);
  }

  &:disabled {
    background: #ccc;
    cursor: not-allowed;
    transform: none;
    box-shadow: none;
  }

  @media (max-width: 480px) {
    padding: 6px 10px;
    font-size: 10px;
    gap: 4px;
    white-space: nowrap;

    svg {
      width: 14px;
      height: 14px;
    }
  }
`,ai=({ticketId:e,onBack:t,onCloseTicket:n,isLoading:r=!1})=>{const a=e.slice(-8);return s.jsxs(ni,{children:[s.jsxs(ii,{children:[s.jsxs(ri,{onClick:t,children:[s.jsx(kn,{size:20}),"Retour"]}),s.jsxs(oi,{children:["Ticket #",a]})]}),s.jsxs(si,{onClick:n,disabled:r,children:[s.jsx(Cn,{size:20}),"Clôturer le ticket"]})]})};function Ie(e){if(!e)return"";const t=e.replace(/[^\d.]/g,""),n=t.split(".");return n.length>2?n[0]+"."+n.slice(1).join(""):t}function je(e,t){return/^[0-9]$/.test(t)?Ie(e)+t:Ie(e)}function Je(e){const t=Ie(e);return t.includes(".")?t:t+"."}function Ze(e){const t=Ie(e);return t.length===0?"":t.slice(0,-1)}function gt(){return""}function li(e){const t=Ie(e);if(!t)return"";if(t.endsWith("."))return t;if(t.includes(".")){const[n,r]=t.split(".");return`${n}.${r}`}return t}function Le(e){const t=Number((e||"0").replace(",","."));return Number.isFinite(t)?t:0}const mt={"&":"1",é:"2",'"':"3","'":"4","(":"5","-":"6",è:"7",_:"8",ç:"9",à:"0"},bt={1:"1",2:"2",3:"3",4:"4",5:"5",6:"6",7:"7",8:"8",9:"9",0:"0"};function ci(e,t,n){return t==="Shift"||t==="Control"||t==="Alt"||t==="Meta"?e:/^[0-9]$/.test(t)?je(e,t):mt[t]?je(e,mt[t]):n&&n.shiftKey&&bt[t]?je(e,bt[t]):t==="Backspace"||t==="Delete"?Ze(e):t==="."||t===","?Je(e):e}const bn="recyclic_ticket_layout",yt={categoriesSize:25,centerSize:50,summarySize:25},di=()=>{try{const e=localStorage.getItem(bn);return e?JSON.parse(e):yt}catch{return yt}},ui=e=>{try{localStorage.setItem(bn,JSON.stringify(e))}catch(t){console.error("Failed to save layout preferences:",t)}},fi=h.div`
  width: 100%;
  height: 100vh;
  display: flex;
  flex-direction: column;
  background: #f5f5f5;
  overflow: hidden;
`,pi=h.div`
  display: flex;
  flex: 1;
  overflow: hidden;
  max-height: calc(100vh - 60px);

  @media (max-width: 768px) {
    flex-direction: column;
    overflow-y: auto;  /* Page scrollable sur mobile */
    overflow-x: hidden;
  }
`,vt=h.div`
  background: white;
  border-right: 1px solid #e0e0e0;
  overflow-y: auto;
  display: flex;
  flex-direction: column;

  @media (max-width: 900px) and (min-width: 769px) {
    overflow-y: auto;  /* Scroll si nécessaire */
  }

  @media (max-width: 768px) {
    border-right: none;
    border-bottom: 1px solid #e0e0e0;
    flex-shrink: 0;
    overflow: visible;
  }
`,zt=h.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 6px;
  padding: 8px;

  @media (max-width: 1024px) and (min-width: 769px) {
    grid-template-columns: 1fr;
    gap: 5px;
    padding: 6px;
  }

  @media (max-width: 768px) {
    display: grid;
    grid-template-rows: repeat(2, minmax(44px, 44px));
    grid-auto-flow: column;
    grid-auto-columns: 140px;
    gap: 5px;
    padding: 6px;
    overflow-x: auto;
    overflow-y: hidden;
  }
`,wt=h.button`
  padding: 12px 10px;
  min-height: 60px;
  border: 2px solid ${e=>e.$selected?"#2e7d32":"#e0e0e0"};
  border-radius: 8px;
  background: ${e=>e.$selected?"#e8f5e8":"white"};
  color: ${e=>e.$selected?"#2e7d32":"#333"};
  cursor: pointer;
  font-size: 14px;
  font-weight: 500;
  transition: all 0.2s;
  text-align: center;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;

  &:hover {
    border-color: #2e7d32;
    background: #e8f5e8;
  }

  @media (max-width: 1024px) and (min-width: 769px) {
    font-size: 13px;
    padding: 10px 8px;
    min-height: 55px;
  }

  @media (max-width: 768px) {
    font-size: 13px;
    padding: 10px 8px;
    min-height: 55px;
    width: 100%;
    height: 100%;
  }
`,St=h.div`
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 6px 10px;
  background: #f8f9fa;
  border-bottom: 1px solid #e0e0e0;
  font-size: 11px;
  font-weight: 500;
`,kt=h.button`
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 4px 8px;
  border: 1px solid #ddd;
  border-radius: 4px;
  background: white;
  color: #666;
  cursor: pointer;
  font-size: 11px;
  transition: all 0.2s;

  &:hover {
    background: #f0f0f0;
    border-color: #999;
  }
`,Ct=h.div`
  display: flex;
  align-items: center;
  gap: 6px;
  color: #666;
  font-size: 12px;
  flex: 1;
  overflow: hidden;
  min-height: 20px;
`,jt=h.span`
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  max-width: 120px;
  color: #2e7d32;
  font-weight: 500;
`,Et=h.div`
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 12px;
  background: #f8f9fa;
  border-bottom: 1px solid #e0e0e0;
  font-size: 12px;
  color: #666;
  margin-bottom: 12px;
`,Pt=h.span`
  color: #2e7d32;
  font-weight: 500;
`;h.span`
  color: #999;
  margin: 0 4px;
`;const It=h.div`
  background: white;
  padding: 12px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  flex: 1;

  @media (max-width: 1024px) and (min-width: 769px) {
    padding: 8px;
  }

  @media (max-width: 768px) {
    padding: 8px;
    overflow: visible;
    flex: none;
  }
`,Rt=h.div`
  display: flex;
  flex-direction: column;
  gap: 6px;
  flex: 1;
  min-height: 0; /* Permet au contenu de se compresser */
  padding: 0 4px; /* Réduire l'espacement latéral */
`,At=h.div`
  display: flex;
  flex-direction: column;
  gap: 6px;
  flex-shrink: 0; /* Ne pas compresser cette section */
`,Lt=h.div`
  display: flex;
  justify-content: center;
  margin: 2px 0;
  flex-shrink: 0; /* Ne pas compresser cette section */
  padding: 4px;
`,$t=h.div`
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-top: auto;
  flex-shrink: 0; /* Ne pas compresser cette section */
`,Dt=h.div`
  background: #f9f9f9;
  border-left: 1px solid #e0e0e0;
  overflow-y: auto;
  display: flex;
  flex-direction: column;

  @media (max-width: 768px) {
    border-left: none;
    border-top: 1px solid #e0e0e0;
    flex-shrink: 0;
    overflow: visible;
  }
`,Nt=h.div`
  padding: 12px 16px;
  background: #f0f0f0;
  border-bottom: 1px solid #e0e0e0;
  font-weight: 600;
  color: #333;
  font-size: 14px;
`,Mt=h.div`
  flex: 1;
  padding: 16px;
  overflow-y: auto;
`,Tt=h.div`
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  padding: 12px;
  border: 1px solid #e0e0e0;
  border-radius: 6px;
  margin-bottom: 8px;
  background: white;
`,_t=h.div`
  flex: 1;
`,Ht=h.div`
  font-weight: 600;
  color: #2e7d32;
  margin-bottom: 4px;
  font-size: 13px;
`,Bt=h.div`
  font-size: 12px;
  color: #666;
  line-height: 1.4;
`,Ft=h.div`
  display: flex;
  gap: 4px;
`,$e=h.button`
  padding: 4px 8px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 11px;
  transition: all 0.2s;
  display: flex;
  align-items: center;
  gap: 2px;

  &.edit {
    background: #ffc107;
    color: #212529;

    &:hover {
      background: #e0a800;
    }
  }

  &.delete {
    background: #dc3545;
    color: white;

    &:hover {
      background: #c82333;
    }
  }

  &:disabled {
    background: #ccc;
    cursor: not-allowed;
  }
`,Gt=h.div`
  text-align: center;
  color: #999;
  font-style: italic;
  padding: 20px;
  font-size: 13px;
`,Kt=h.div`
  padding: 12px;
  background: #f0f0f0;
  border-top: 1px solid #e0e0e0;
  font-size: 12px;
  color: #666;
  text-align: center;
`,ye=h.div`
  display: flex;
  flex-direction: column;
  gap: 6px;
`,ve=h.label`
  font-weight: 500;
  color: #333;
  font-size: 13px;

  @media (max-width: 768px) {
    font-size: 11px;
  }
`,Wt=h.input`
  width: 100%;
  padding: 8px;
  border: 2px solid #e0e0e0;
  border-radius: 6px;
  font-size: 20px;
  text-align: center;
  font-weight: bold;
  background: #f9f9f9;
  color: #333;
  height: 48px;
  min-height: 48px;

  &:focus {
    outline: none;
    border-color: #2e7d32;
  }

  @media (max-width: 1024px) and (min-width: 769px) {
    font-size: 18px;
    height: 44px;
    min-height: 44px;
  }

  @media (max-width: 768px) {
    font-size: 16px;
    height: 40px;
    min-height: 40px;
  }
`,Ot=h.select`
  width: 100%;
  padding: 8px;
  border: 1px solid #e0e0e0;
  border-radius: 6px;
  font-size: 13px;
  background: white;
  cursor: pointer;
  min-height: 40px;

  &:focus {
    outline: none;
    border-color: #2e7d32;
  }

  @media (max-width: 768px) {
    font-size: 12px;
    padding: 6px;
    min-height: 36px;
  }
`,Ut=h.textarea`
  width: 100%;
  padding: 6px;
  border: 1px solid #e0e0e0;
  border-radius: 6px;
  font-size: 12px;
  resize: vertical;
  min-height: 40px;
  max-height: 60px;
  font-family: inherit;

  &:focus {
    outline: none;
    border-color: #2e7d32;
  }

  @media (max-width: 768px) {
    font-size: 11px;
    min-height: 36px;
    max-height: 50px;
  }
`,Vt=h.button`
  width: 100%;
  padding: 8px;
  min-height: 40px;
  background: #2e7d32;
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-size: 13px;
  font-weight: 600;
  transition: all 0.2s;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 4px;

  &:hover {
    background: #1b5e20;
    transform: translateY(-1px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
  }

  &:disabled {
    background: #ccc;
    cursor: not-allowed;
    transform: none;
    box-shadow: none;
  }

  @media (max-width: 768px) {
    font-size: 12px;
    padding: 6px;
    min-height: 36px;
  }
`,Yt=h.div`
  position: relative;
  width: 6px;
  background: #d0d0d0;  /* Gris visible */
  cursor: col-resize;
  transition: all 0.2s;
  display: flex;
  align-items: center;
  justify-content: center;

  /* Indicateur visuel (3 points) */
  &::after {
    content: '⋮';
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: #999;
    font-size: 18px;
    line-height: 6px;
    opacity: 0.7;
  }

  &:hover {
    background: #2e7d32;
    width: 8px;

    &::after {
      color: white;
      opacity: 1;
    }
  }

  &:active {
    background: #1b5e20;
  }

  @media (max-width: 768px) {
    display: none;
  }
`;h.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  z-index: 999;
  opacity: ${e=>e.$isOpen?1:0};
  visibility: ${e=>e.$isOpen?"visible":"hidden"};
  transition: opacity 0.3s, visibility 0.3s;
`;h.div`
  position: fixed;
  top: 0;
  right: ${e=>e.$isOpen?"0":"-400px"};
  width: 400px;
  height: 100vh;
  background: white;
  box-shadow: -4px 0 12px rgba(0,0,0,0.2);
  z-index: 1000;
  display: flex;
  flex-direction: column;
  transition: right 0.3s;

  @media (max-width: 600px) {
    width: 100%;
    right: ${e=>e.$isOpen?"0":"-100%"};
  }
`;h.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 20px;
  border-bottom: 1px solid #e0e0e0;
  background: #f9f9f9;
`;h.h3`
  margin: 0;
  font-size: 1.2rem;
  color: #333;
  display: flex;
  align-items: center;
  gap: 8px;
`;h.button`
  background: transparent;
  border: none;
  cursor: pointer;
  padding: 4px;
  color: #666;
  transition: color 0.2s;

  &:hover {
    color: #333;
  }
`;h.div`
  flex: 1;
  overflow-y: auto;
  padding: 20px;
`;h.button`
  position: fixed;
  right: ${e=>e.$isOpen?"400px":"0"};
  top: 50%;
  transform: translateY(-50%);
  background: #2e7d32;
  color: white;
  border: none;
  border-radius: 8px 0 0 8px;
  padding: 20px 12px;
  cursor: pointer;
  writing-mode: vertical-rl;
  text-orientation: mixed;
  font-size: 14px;
  font-weight: 600;
  z-index: 998;
  box-shadow: -2px 2px 8px rgba(0,0,0,0.2);
  transition: right 0.3s, background-color 0.2s;

  &:hover {
    background: #1b5e20;
  }

  @media (max-width: 600px) {
    right: ${e=>e.$isOpen?"100%":"0"};
  }
`;h.div`
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  padding: 15px;
  border: 1px solid #e0e0e0;
  border-radius: 6px;
  margin-bottom: 10px;
  background: #f9f9f9;
`;h.div`
  flex: 1;
`;h.div`
  font-weight: 600;
  color: #2e7d32;
  margin-bottom: 5px;
  font-size: 15px;
`;h.div`
  font-size: 13px;
  color: #666;
  line-height: 1.5;
`;h.div`
  display: flex;
  gap: 6px;
`;h.button`
  padding: 6px 10px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 12px;
  transition: all 0.2s;
  display: flex;
  align-items: center;
  gap: 4px;

  &.edit {
    background: #ffc107;
    color: #212529;

    &:hover {
      background: #e0a800;
    }
  }

  &.delete {
    background: #dc3545;
    color: white;

    &:hover {
      background: #c82333;
    }
  }

  &:disabled {
    background: #ccc;
    cursor: not-allowed;
  }
`;h.div`
  text-align: center;
  color: #999;
  font-style: italic;
  padding: 40px 20px;
`;h.div`
  text-align: center;
  color: #666;
  font-size: 13px;
  margin-bottom: 16px;
  padding-bottom: 16px;
  border-bottom: 1px solid #e0e0e0;
`;const qt=h.div`
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  font-size: 18px;
  color: #666;
`,Xt=h.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 100vh;
  padding: 20px;
`,Jt=h.div`
  color: #c62828;
  font-size: 18px;
  text-align: center;
  max-width: 600px;
`,De=[{value:"MAGASIN",label:"Magasin"},{value:"RECYCLAGE",label:"Recyclage"},{value:"DECHETERIE",label:"Déchetterie"}],Si=()=>{var pe,me;const e=zn(),{ticketId:t}=wn(),{currentTicket:n,isLoading:r,addLineToTicket:a,updateTicketLine:o,deleteTicketLine:l,closeTicket:c}=Sn(),{activeCategories:d,fetchCategories:z}=jn(),[I,g]=u.useState(null),[f,j]=u.useState(!1),[w,A]=u.useState(null),[b,S]=u.useState(""),[R,L]=u.useState(""),[T,q]=u.useState("MAGASIN"),[$,E]=u.useState(""),[V,ne]=u.useState(null),O=u.useRef(null),[K,M]=u.useState(null),[ie,W]=u.useState([]),_=li(R),Y=i=>{const p=typeof i=="number"?i:parseFloat(String(i).replace(",","."));return Number.isFinite(p)?p.toString():""},oe=d.filter(i=>K===null?i.parent_id===null:i.parent_id===K).map(i=>({id:i.id,label:i.name,slug:i.name.toLowerCase().replace(/\s+/g,"-"),hasChildren:d.some(p=>p.parent_id===i.id)}));u.useEffect(()=>{z()},[z]),u.useEffect(()=>{(async()=>{if(t){j(!0),A(null);try{const p=await ce.getTicket(t);g(p),p.status==="closed"&&A("Ce ticket est fermé et ne peut pas être modifié")}catch(p){console.error("Erreur lors du chargement du ticket:",p),A("Impossible de charger les détails du ticket")}finally{j(!1)}}})()},[t]);const U=t?I:n,J=(U==null?void 0:U.status)==="closed",X=(U==null?void 0:U.lignes)||(U==null?void 0:U.lines)||[],se=async()=>{if(J){alert("Ce ticket est fermé et ne peut pas être modifié");return}if(!b||!R){alert("Veuillez sélectionner une catégorie et saisir un poids");return}try{if(t){await ce.addLineToTicket(t,{category_id:b,weight:Le(_),destination:T,notes:$||void 0});const i=await ce.getTicket(t);g(i)}else await a(n.id,{category:b,weight:Le(_),destination:T,notes:$||void 0});S(""),L(""),q("MAGASIN"),E("")}catch(i){console.error("Erreur lors de l'ajout de la ligne:",i)}},ae=async i=>{if(J){alert("Ce ticket est fermé et ne peut pas être modifié");return}if(!b||!R){alert("Veuillez sélectionner une catégorie et saisir un poids");return}try{if(t){await ce.updateTicketLine(t,i,{category_id:b,weight:Le(_),destination:T,notes:$||void 0});const p=await ce.getTicket(t);g(p)}else await o(n.id,i,{category:b,weight:Le(_),destination:T,notes:$||void 0});ne(null),S(""),L(""),q("MAGASIN"),E("")}catch(p){console.error("Erreur lors de la mise à jour de la ligne:",p)}},x=async i=>{if(J){alert("Ce ticket est fermé et ne peut pas être modifié");return}if(window.confirm("Êtes-vous sûr de vouloir supprimer cette ligne ?"))try{if(t){await ce.deleteTicketLine(t,i);const p=await ce.getTicket(t);g(p)}else await l(n.id,i)}catch(p){console.error("Erreur lors de la suppression de la ligne:",p)}},v=i=>{ne(i.id),S(i.category_id||i.category||"");const p=i.poids_kg||i.weight||0;L(Y(p)),q(i.destination),E(i.notes||"")},k=i=>{const p=d.find(F=>F.id===i);if(!p)return;d.some(F=>F.parent_id===i)?(M(i),W(F=>[...F,p.name]),S("")):(S(i),M(null),W([]),setTimeout(()=>{O.current&&O.current.focus()},100))},y=()=>{if(ie.length>0){const i=ie.slice(0,-1);if(W(i),i.length===0)M(null);else{const p=d.find(B=>B.name===i[i.length-1]);M((p==null?void 0:p.id)||null)}S("")}},m=(i,p)=>{(i.key==="Enter"||i.key===" ")&&(i.preventDefault(),k(p))},C=i=>{(i.key==="Enter"||i.key===" ")&&(i.preventDefault(),y())},D=async()=>{if(J){alert("Ce ticket est déjà fermé");return}if(window.confirm("Êtes-vous sûr de vouloir clôturer ce ticket ?"))try{t?(await ce.closeTicket(t),e("/reception")):(await c(n.id),e("/reception"))}catch(i){console.error("Erreur lors de la clôture du ticket:",i)}},N=V!==null,Q=u.useCallback(i=>{const p=i.key,B=ci(R,p,i.nativeEvent);B!==R?(i.preventDefault(),L(B)):p==="Enter"&&(i.preventDefault(),b&&R&&(N?ae(V):se()))},[b,R,N,V]),[Z]=u.useState(di()),[H,ee]=u.useState(window.innerWidth<=768);u.useEffect(()=>{const i=()=>{ee(window.innerWidth<=768)};return window.addEventListener("resize",i),()=>window.removeEventListener("resize",i)},[]);const fe=i=>{const[p,B,F]=i;if(p&&B&&F){const Re={categoriesSize:Math.round(p),centerSize:Math.round(B),summarySize:Math.round(F)};ui(Re)}};return f?s.jsx(qt,{children:"Chargement du ticket..."}):w&&!U?s.jsx(Xt,{children:s.jsx(Jt,{children:w})}):U?s.jsxs(fi,{children:[s.jsx(ai,{ticketId:U.id,onBack:()=>e("/reception"),onCloseTicket:D,isLoading:r}),s.jsx(pi,{children:H?s.jsxs(s.Fragment,{children:[s.jsxs(vt,{children:[K&&s.jsxs(St,{children:[s.jsx(kt,{onClick:y,onKeyDown:C,tabIndex:0,role:"button","aria-label":"Retour au niveau précédent",children:"← Retour"}),s.jsx(Ct,{children:ie.map((i,p)=>s.jsxs(nt.Fragment,{children:[p>0&&s.jsx("span",{style:{color:"#999",margin:"0 4px"},children:"›"}),s.jsx(jt,{title:i,children:i})]},p))})]}),s.jsx(zt,{children:oe.map(i=>s.jsx(wt,{$selected:b===i.id,onClick:()=>k(i.id),onKeyDown:p=>m(p,i.id),tabIndex:0,role:"button","aria-label":i.hasChildren?`Naviguer vers ${i.label}`:`Sélectionner ${i.label}`,"aria-pressed":b===i.id,children:i.label},i.id))})]}),s.jsxs(It,{children:[b&&s.jsxs(Et,{children:[s.jsx("span",{children:"Catégorie sélectionnée:"}),s.jsx(Pt,{children:((pe=d.find(i=>i.id===b))==null?void 0:pe.name)||"Inconnue"})]}),!J&&s.jsxs(Rt,{children:[s.jsx(At,{children:s.jsxs(ye,{children:[s.jsx(ve,{children:"Poids (kg) *"}),s.jsx(Wt,{ref:O,type:"text",value:_,onChange:()=>{},onKeyDown:Q,placeholder:"0.00",readOnly:!0})]})}),s.jsx(Lt,{children:s.jsx(ht,{onKeyPress:i=>{i!=="C"&&(i==="."?L(p=>Je(p)):/^[0-9]$/.test(i)&&L(p=>je(p,i)))},onClear:()=>L(gt()),onBackspace:()=>L(i=>Ze(i))})}),s.jsxs($t,{children:[s.jsxs(ye,{children:[s.jsx(ve,{children:"Destination"}),s.jsx(Ot,{value:T,onChange:i=>q(i.target.value),children:De.map(i=>s.jsx("option",{value:i.value,children:i.label},i.value))})]}),s.jsxs(ye,{children:[s.jsx(ve,{children:"Notes (optionnel)"}),s.jsx(Ut,{value:$,onChange:i=>E(i.target.value),placeholder:"Notes sur l'objet..."})]}),s.jsxs(Vt,{onClick:N?()=>ae(V):se,disabled:r||!b||!R,children:[s.jsx(it,{size:18}),N?"Mettre à jour":"Ajouter l'objet"]})]})]})]}),s.jsxs(Dt,{children:[s.jsx(Nt,{children:"Résumé du Ticket"}),s.jsx(Mt,{children:X.length===0?s.jsx(Gt,{children:"Aucune ligne ajoutée"}):X.map(i=>{var p,B;return s.jsxs(Tt,{children:[s.jsxs(_t,{children:[s.jsx(Ht,{children:i.category_label||((p=oe.find(F=>F.id===i.category_id))==null?void 0:p.label)||i.category_id||i.category||"N/A"}),s.jsxs(Bt,{children:[i.poids_kg||i.weight,"kg - ",(B=De.find(F=>F.value===i.destination))==null?void 0:B.label,i.notes&&s.jsxs(s.Fragment,{children:[s.jsx("br",{}),i.notes]})]})]}),!J&&s.jsxs(Ft,{children:[s.jsx($e,{className:"edit",onClick:()=>v(i),disabled:r,children:s.jsx(rt,{size:12})}),s.jsx($e,{className:"delete",onClick:()=>x(i.id),disabled:r,children:s.jsx(ot,{size:12})})]})]},i.id)})}),s.jsxs(Kt,{children:[X.length," ligne",X.length>1?"s":""," • Total: ",X.reduce((i,p)=>{const B=p.poids_kg||p.weight||0;return i+(typeof B=="number"?B:0)},0).toFixed(2),"kg"]})]})]}):s.jsxs(mn,{direction:"horizontal",onLayout:fe,children:[s.jsx(Ne,{defaultSize:Z.categoriesSize,minSize:15,maxSize:70,children:s.jsxs(vt,{children:[K&&s.jsxs(St,{children:[s.jsx(kt,{onClick:y,onKeyDown:C,tabIndex:0,role:"button","aria-label":"Retour au niveau précédent",children:"← Retour"}),s.jsx(Ct,{children:ie.map((i,p)=>s.jsxs(nt.Fragment,{children:[p>0&&s.jsx("span",{style:{color:"#999",margin:"0 4px"},children:"›"}),s.jsx(jt,{title:i,children:i})]},p))})]}),s.jsx(zt,{children:oe.map(i=>s.jsx(wt,{$selected:b===i.id,onClick:()=>k(i.id),onKeyDown:p=>m(p,i.id),tabIndex:0,role:"button","aria-label":i.hasChildren?`Naviguer vers ${i.label}`:`Sélectionner ${i.label}`,"aria-pressed":b===i.id,children:i.label},i.id))})]})}),s.jsx(Xe,{children:s.jsx(Yt,{})}),s.jsx(Ne,{defaultSize:Z.centerSize,minSize:30,maxSize:70,children:s.jsxs(It,{children:[b&&s.jsxs(Et,{children:[s.jsx("span",{children:"Catégorie sélectionnée:"}),s.jsx(Pt,{children:((me=d.find(i=>i.id===b))==null?void 0:me.name)||"Inconnue"})]}),!J&&s.jsxs(Rt,{children:[s.jsx(At,{children:s.jsxs(ye,{children:[s.jsx(ve,{children:"Poids (kg) *"}),s.jsx(Wt,{ref:O,type:"text",value:_,onChange:()=>{},onKeyDown:Q,placeholder:"0.00",readOnly:!0})]})}),s.jsx(Lt,{children:s.jsx(ht,{onKeyPress:i=>{i!=="C"&&(i==="."?L(p=>Je(p)):/^[0-9]$/.test(i)&&L(p=>je(p,i)))},onClear:()=>L(gt()),onBackspace:()=>L(i=>Ze(i))})}),s.jsxs($t,{children:[s.jsxs(ye,{children:[s.jsx(ve,{children:"Destination"}),s.jsx(Ot,{value:T,onChange:i=>q(i.target.value),children:De.map(i=>s.jsx("option",{value:i.value,children:i.label},i.value))})]}),s.jsxs(ye,{children:[s.jsx(ve,{children:"Notes (optionnel)"}),s.jsx(Ut,{value:$,onChange:i=>E(i.target.value),placeholder:"Notes sur l'objet..."})]}),s.jsxs(Vt,{onClick:N?()=>ae(V):se,disabled:r||!b||!R,children:[s.jsx(it,{size:18}),N?"Mettre à jour":"Ajouter l'objet"]})]})]})]})}),s.jsx(Xe,{children:s.jsx(Yt,{})}),s.jsx(Ne,{defaultSize:Z.summarySize,minSize:15,maxSize:70,children:s.jsxs(Dt,{children:[s.jsx(Nt,{children:"Résumé du Ticket"}),s.jsx(Mt,{children:X.length===0?s.jsx(Gt,{children:"Aucune ligne ajoutée"}):X.map(i=>{var p,B;return s.jsxs(Tt,{children:[s.jsxs(_t,{children:[s.jsx(Ht,{children:i.category_label||((p=oe.find(F=>F.id===i.category_id))==null?void 0:p.label)||i.category_id||i.category||"N/A"}),s.jsxs(Bt,{children:[i.poids_kg||i.weight,"kg - ",(B=De.find(F=>F.value===i.destination))==null?void 0:B.label,i.notes&&s.jsxs(s.Fragment,{children:[s.jsx("br",{}),i.notes]})]})]}),!J&&s.jsxs(Ft,{children:[s.jsx($e,{className:"edit",onClick:()=>v(i),disabled:r,children:s.jsx(rt,{size:12})}),s.jsx($e,{className:"delete",onClick:()=>x(i.id),disabled:r,children:s.jsx(ot,{size:12})})]})]},i.id)})}),s.jsxs(Kt,{children:[X.length," ligne",X.length>1?"s":""," • Total: ",X.reduce((i,p)=>{const B=p.poids_kg||p.weight||0;return i+(typeof B=="number"?B:0)},0).toFixed(2),"kg"]})]})})]})})]}):t?s.jsx(qt,{children:"Chargement du ticket..."}):s.jsx(Xt,{children:s.jsx(Jt,{children:"Erreur: Aucun ticket en cours"})})};export{Si as default};
//# sourceMappingURL=TicketForm-B3s3I3IL.js.map
