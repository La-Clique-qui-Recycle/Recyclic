import{j as e}from"./admin-D2I4SZO-.js";import{r as l}from"./vendor-cDl5Ih67.js";import{d as r}from"./ui-DXFJp4I_.js";import{k as O,l as H,m as G}from"./api-7vu9KqRw.js";import"./api-XIr9E-cT.js";import"./stores-CmSlgjNa.js";const R=r.div`
  padding: 24px;
  max-width: 1400px;
  margin: 0 auto;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
`,W=r.div`
  display: flex;
  flex-direction: column;
  gap: 16px;
  margin-bottom: 24px;

  @media (min-width: 768px) {
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
  }
`,q=r.h1`
  margin: 0;
  font-size: 1.8rem;
  color: #1f2937;
`,J=r.div`
  background: white;
  border: 1px solid #e5e7eb;
  border-radius: 10px;
  padding: 24px;
  margin-bottom: 24px;
  box-shadow: 0 2px 4px rgba(15, 23, 42, 0.06);
`,K=r.div`
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
  margin-bottom: 16px;
  align-items: end;
`,u=r.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
  min-width: 150px;
`,h=r.label`
  font-size: 0.9rem;
  font-weight: 500;
  color: #374151;
`,F=r.input`
  padding: 8px 12px;
  border: 1px solid #d1d5db;
  border-radius: 6px;
  background: #ffffff;
  font-size: 0.9rem;
  transition: border-color 0.2s ease;

  &:focus {
    outline: none;
    border-color: #1976d2;
    box-shadow: 0 0 0 3px rgba(25, 118, 210, 0.1);
  }
`,P=r.select`
  padding: 8px 12px;
  border: 1px solid #d1d5db;
  border-radius: 6px;
  background: #ffffff;
  font-size: 0.9rem;
  transition: border-color 0.2s ease;

  &:focus {
    outline: none;
    border-color: #1976d2;
    box-shadow: 0 0 0 3px rgba(25, 118, 210, 0.1);
  }
`,Q=r.button`
  padding: 8px 16px;
  border: 1px solid ${a=>a.variant==="primary"?"#1976d2":"#d1d5db"};
  background: ${a=>a.variant==="primary"?"#1976d2":"#ffffff"};
  color: ${a=>a.variant==="primary"?"#ffffff":"#374151"};
  border-radius: 6px;
  cursor: pointer;
  font-weight: 500;
  font-size: 0.9rem;
  transition: all 0.2s ease;
  display: flex;
  align-items: center;
  gap: 8px;

  &:hover {
    background: ${a=>a.variant==="primary"?"#1565c0":"#f3f4f6"};
  }

  &:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
`,X=r.div`
  background: white;
  border: 1px solid #e5e7eb;
  border-radius: 10px;
  overflow: hidden;
  box-shadow: 0 2px 4px rgba(15, 23, 42, 0.06);
`,Y=r.table`
  width: 100%;
  border-collapse: collapse;
`,Z=r.thead`
  background: #f9fafb;
`,p=r.th`
  padding: 12px 16px;
  text-align: left;
  font-weight: 600;
  color: #374151;
  border-bottom: 1px solid #e5e7eb;
  font-size: 0.9rem;
`,ee=r.tbody``,te=r.tr`
  &:hover {
    background: #f9fafb;
  }
`,g=r.td`
  padding: 12px 16px;
  border-bottom: 1px solid #f3f4f6;
  font-size: 0.9rem;
  color: #374151;
`,re=r.div`
  display: flex;
  justify-content: between;
  align-items: center;
  padding: 16px 24px;
  background: #f9fafb;
  border-top: 1px solid #e5e7eb;
`,oe=r.div`
  color: #6b7280;
  font-size: 0.9rem;
`,ae=r.div`
  display: flex;
  gap: 8px;
  margin-left: auto;
`,v=r.button`
  padding: 6px 12px;
  border: 1px solid ${a=>a.active?"#1976d2":"#d1d5db"};
  background: ${a=>a.active?"#1976d2":"#ffffff"};
  color: ${a=>a.active?"#ffffff":"#374151"};
  border-radius: 4px;
  cursor: pointer;
  font-size: 0.9rem;
  transition: all 0.2s ease;

  &:hover:not(:disabled) {
    background: ${a=>a.active?"#1565c0":"#f3f4f6"};
  }

  &:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
`,ne=r.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  color: #6b7280;
  font-size: 1.1rem;
`,ie=r.div`
  background: #fee;
  border: 1px solid #fcc;
  border-radius: 8px;
  padding: 16px;
  color: #c00;
  margin: 20px 0;
`,se=r.div`
  text-align: center;
  padding: 40px;
  color: #6b7280;
`,fe=()=>{var D,k;const T=typeof import.meta<"u"&&((k=(D=import.meta)==null?void 0:D.env)==null?void 0:k.MODE)==="test"?0:300,c=l.useRef(null),[d,_]=l.useState({startDate:"",endDate:"",categoryId:""}),[i,m]=l.useState({page:1,perPage:50}),[s,L]=l.useState(null),[z,I]=l.useState([]),[$,y]=l.useState(!1),[w,C]=l.useState(!1),[S,f]=l.useState(null);l.useEffect(()=>{(async()=>{try{const n=await H();I(n)}catch(n){console.error("Error loading categories:",n)}})()},[]),l.useEffect(()=>(c.current&&(window.clearTimeout(c.current),c.current=null),c.current=window.setTimeout(()=>{B()},T),()=>{c.current&&(window.clearTimeout(c.current),c.current=null)}),[d,i]);const B=async()=>{var t,n;try{y(!0),f(null);const o=await O(i.page,i.perPage,d.startDate||void 0,d.endDate||void 0,d.categoryId||void 0);L(o)}catch(o){console.error("Error loading reception lines:",o),f(((n=(t=o.response)==null?void 0:t.data)==null?void 0:n.detail)||"Erreur lors du chargement des données")}finally{y(!1)}},b=(t,n)=>{_(o=>({...o,[t]:n})),m(o=>({...o,page:1}))},j=t=>{m(n=>({...n,page:t}))},M=t=>{m(n=>({page:1,perPage:t}))},U=async()=>{var t,n;try{C(!0),f(null);const{blob:o,filename:N}=await G(d.startDate||void 0,d.endDate||void 0,d.categoryId||void 0),E=window.URL.createObjectURL(o),x=document.createElement("a");x.href=E,x.download=N||"rapport_reception.csv",document.body.appendChild(x),x.click(),document.body.removeChild(x),window.URL.revokeObjectURL(E)}catch(o){console.error("Error exporting CSV:",o),f(((n=(t=o.response)==null?void 0:t.data)==null?void 0:n.detail)||"Erreur lors de l'export CSV")}finally{C(!1)}},V=t=>new Date(t).toLocaleDateString("fr-FR",{year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit"}),A=t=>t.toLocaleString("fr-FR",{minimumFractionDigits:1,maximumFractionDigits:3});return $&&!s?e.jsx(R,{children:e.jsx(ne,{children:"Chargement des données..."})}):e.jsxs(R,{children:[e.jsxs(W,{children:[e.jsx(q,{children:"Rapports de Réception"}),e.jsx(Q,{variant:"primary",onClick:U,disabled:w,"aria-label":"Exporter les rapports de réception au format CSV",children:w?"Export en cours...":"📊 Exporter CSV"})]}),S&&e.jsx(ie,{children:S}),e.jsx(J,{children:e.jsxs(K,{children:[e.jsxs(u,{children:[e.jsx(h,{htmlFor:"start-date",children:"Date de début"}),e.jsx(F,{id:"start-date",type:"date",value:d.startDate,onChange:t=>b("startDate",t.target.value)})]}),e.jsxs(u,{children:[e.jsx(h,{htmlFor:"end-date",children:"Date de fin"}),e.jsx(F,{id:"end-date",type:"date",value:d.endDate,onChange:t=>b("endDate",t.target.value)})]}),e.jsxs(u,{children:[e.jsx(h,{htmlFor:"category",children:"Catégorie"}),e.jsxs(P,{id:"category",value:d.categoryId,onChange:t=>b("categoryId",t.target.value),children:[e.jsx("option",{value:"",children:"Toutes les catégories"}),z.map(t=>e.jsx("option",{value:t.id,children:t.label},t.id))]})]}),e.jsxs(u,{children:[e.jsx(h,{htmlFor:"per-page",children:"Éléments par page"}),e.jsxs(P,{id:"per-page",value:i.perPage,onChange:t=>M(Number(t.target.value)),children:[e.jsx("option",{value:25,children:"25"}),e.jsx("option",{value:50,children:"50"}),e.jsx("option",{value:100,children:"100"})]})]})]})}),e.jsxs(X,{children:[e.jsxs(Y,{children:[e.jsx(Z,{children:e.jsxs("tr",{children:[e.jsx(p,{children:"Date"}),e.jsx(p,{children:"Bénévole"}),e.jsx(p,{children:"Catégorie"}),e.jsx(p,{children:"Poids (kg)"}),e.jsx(p,{children:"Destination"}),e.jsx(p,{children:"Notes"})]})}),e.jsx(ee,{children:s==null?void 0:s.lignes.map(t=>e.jsxs(te,{children:[e.jsx(g,{children:V(t.created_at)}),e.jsx(g,{children:t.benevole_username}),e.jsx(g,{children:t.dom_category_label}),e.jsx(g,{children:A(t.poids_kg)}),e.jsx(g,{children:t.destination}),e.jsx(g,{children:t.notes||"-"})]},t.id))})]}),s&&s.lignes.length===0&&e.jsx(se,{children:"Aucune donnée trouvée pour les filtres sélectionnés"}),s&&s.total_pages>1&&e.jsxs(re,{children:[e.jsxs(oe,{"aria-live":"polite",children:["Affichage de ",(i.page-1)*i.perPage+1," à"," ",Math.min(i.page*i.perPage,s.total)," sur ",s.total," éléments"]}),e.jsxs(ae,{children:[e.jsx(v,{onClick:()=>j(i.page-1),disabled:i.page===1,"aria-label":"Page précédente",children:"Précédent"}),Array.from({length:Math.min(5,s.total_pages)},(t,n)=>{const o=Math.max(1,Math.min(s.total_pages-4,i.page-2))+n;return o>s.total_pages?null:e.jsx(v,{active:o===i.page,onClick:()=>j(o),"aria-label":`Aller à la page ${o}`,children:o},o)}),e.jsx(v,{onClick:()=>j(i.page+1),disabled:i.page===s.total_pages,"aria-label":"Page suivante",children:"Suivant"})]})]})]})]})};export{fe as default};
//# sourceMappingURL=ReceptionReports-Bw6HgrTy.js.map
