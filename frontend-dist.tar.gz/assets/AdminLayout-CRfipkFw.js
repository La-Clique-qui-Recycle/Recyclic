import{j as o}from"./admin-D2I4SZO-.js";import{e as f,u as k,r as u,O as y,L as v}from"./vendor-cDl5Ih67.js";import{d as t}from"./ui-DXFJp4I_.js";import{u as i}from"./stores-CmSlgjNa.js";import{R as j,H as w,C,a as L,b as A,U as R}from"./cash-Cdpp_gQO.js";import"./api-XIr9E-cT.js";const z=t.div`
  display: flex;
  flex-direction: column;
  min-height: calc(100vh - 120px);
  gap: 1rem;
`,E=t.header`
  background-color: #2e7d32;
  color: white;
  padding: 1rem 0;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  margin: -20px -20px 1rem -20px;
`,M=t.nav`
  max-width: 1200px;
  margin: 0 auto;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 20px;
`,S=t.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 1.5rem;
  font-weight: bold;
`,O=t.div`
  display: flex;
  gap: 2rem;
`,N=t(v)`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  color: white;
  text-decoration: none;
  padding: 0.5rem 1rem;
  border-radius: 4px;
  transition: background-color 0.2s;
  
  &:hover {
    background-color: rgba(255, 255, 255, 0.1);
  }
  
  ${l=>l.$active&&`
    background-color: rgba(255, 255, 255, 0.2);
  `}
`,H=t.main`
  flex: 1;
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  padding: 2rem;
  min-height: 500px;
`,W=()=>{const l=f(),d=k(),p=i(e=>e.isAuthenticated),m=i(e=>e.hasCashAccess()),x=i(e=>e.isAdmin()),n=i(e=>e.currentUser),g=i(e=>e.logout),[a,c]=u.useState(!1),h=()=>{g(),d("/login")};u.useEffect(()=>{const e=r=>{a&&!r.target.closest('[role="menu"]')&&!r.target.closest('button[aria-haspopup="menu"]')&&c(!1)};if(a)return document.addEventListener("click",e),()=>document.removeEventListener("click",e)},[a]);const s=[{path:"/",label:"Tableau de bord",icon:w}];return p&&s.push({path:"/reception",label:"Réception",icon:L}),m&&s.splice(1,0,{path:"/caisse",label:"Caisse",icon:A}),x&&s.push({path:"/admin",label:"Administration",icon:R}),o.jsxs(z,{children:[o.jsx(E,{children:o.jsxs(M,{children:[o.jsxs(S,{children:[o.jsx(j,{size:24}),"Recyclic"]}),o.jsxs(O,{children:[s.map(({path:e,label:r,icon:b})=>o.jsxs(N,{to:e,$active:l.pathname===e,children:[o.jsx(b,{size:18}),r]},e)),p&&o.jsxs("div",{style:{position:"relative"},children:[o.jsxs("button",{onClick:()=>c(e=>!e),style:{display:"flex",alignItems:"center",gap:"0.5rem",background:"transparent",border:"1px solid rgba(255,255,255,0.3)",color:"white",padding:"0.5rem 0.75rem",borderRadius:"4px",cursor:"pointer"},"aria-haspopup":"menu","aria-expanded":a,children:[o.jsx("span",{style:{opacity:.95},children:(n==null?void 0:n.username)||[n==null?void 0:n.first_name,n==null?void 0:n.last_name].filter(Boolean).join(" ")||"Utilisateur"}),o.jsx(C,{size:16})]}),a&&o.jsxs("div",{role:"menu",style:{position:"absolute",right:0,marginTop:"8px",minWidth:"180px",background:"white",color:"#333",borderRadius:"6px",boxShadow:"0 4px 12px rgba(0,0,0,0.15)",overflow:"hidden",zIndex:1e3},children:[o.jsx("button",{role:"menuitem",onClick:()=>{c(!1),d("/profil")},style:{display:"block",width:"100%",textAlign:"left",padding:"10px 12px",background:"transparent",border:"none",cursor:"pointer",fontSize:"0.9rem",color:"#333"},onMouseEnter:e=>e.target.style.background="#f5f5f5",onMouseLeave:e=>e.target.style.background="transparent",children:"Mon profil"}),o.jsx("button",{role:"menuitem",onClick:h,style:{display:"block",width:"100%",textAlign:"left",padding:"10px 12px",background:"transparent",border:"none",cursor:"pointer",fontSize:"0.9rem",color:"#dc2626"},onMouseEnter:e=>e.target.style.background="#fef2f2",onMouseLeave:e=>e.target.style.background="transparent",children:"Se déconnecter"})]})]})]})]})}),o.jsx(H,{role:"main","aria-label":"Contenu principal de l'administration",children:o.jsx(y,{})})]})};export{W as default};
//# sourceMappingURL=AdminLayout-CRfipkFw.js.map
