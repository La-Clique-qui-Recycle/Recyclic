import{j as e}from"./admin-D2I4SZO-.js";import{r as c}from"./vendor-cDl5Ih67.js";import{d as t}from"./ui-DXFJp4I_.js";import{a as l}from"./api-XIr9E-cT.js";import"./stores-CmSlgjNa.js";class N{async getSystemHealth(){try{return(await l.get("/admin/health")).data}catch(i){throw console.error("Erreur lors de la récupération des métriques de santé:",i),new Error("Impossible de récupérer les métriques de santé")}}async getAnomalies(){try{return(await l.get("/admin/health/anomalies")).data}catch(i){throw console.error("Erreur lors de la récupération des anomalies:",i),new Error("Impossible de récupérer les anomalies")}}async getSchedulerStatus(){try{return(await l.get("/admin/health/scheduler")).data.scheduler}catch(i){throw console.error("Erreur lors de la récupération du statut du scheduler:",i),new Error("Impossible de récupérer le statut du scheduler")}}async sendTestNotification(){try{return(await l.post("/admin/health/test-notifications")).data}catch(i){throw console.error("Erreur lors de l'envoi de la notification de test:",i),new Error("Impossible d'envoyer la notification de test")}}}const $=new N,x=t.div`
  padding: 24px;
  max-width: 1200px;
  margin: 0 auto;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
`,B=t.div`
  display: flex;
  flex-direction: column;
  gap: 16px;
  margin-bottom: 32px;

  @media (min-width: 768px) {
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
  }
`,L=t.h1`
  margin: 0;
  font-size: 2rem;
  color: #1f2937;
  font-weight: 600;
`,M=t.div`
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
`,b=t.button`
  background: ${r=>{switch(r.variant){case"danger":return"#dc2626";case"secondary":return"#ffffff";default:return"#1976d2"}}};
  color: ${r=>r.variant==="secondary"?"#1976d2":"#ffffff"};
  border: 1px solid ${r=>r.variant==="danger"?"#dc2626":"#1976d2"};
  padding: 8px 16px;
  border-radius: 6px;
  cursor: pointer;
  font-size: 0.875rem;
  transition: all 0.2s;

  &:hover {
    background: ${r=>{switch(r.variant){case"danger":return"#b91c1c";case"secondary":return"#f3f4f6";default:return"#1565c0"}}};
  }

  &:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
`,q=t.div`
  background: ${r=>{switch(r.status){case"healthy":return"#d1fae5";case"degraded":return"#fef3c7";case"critical":return"#fecaca";default:return"#f3f4f6"}}};
  border: 1px solid ${r=>{switch(r.status){case"healthy":return"#10b981";case"degraded":return"#f59e0b";case"critical":return"#ef4444";default:return"#d1d5db"}}};
  border-radius: 8px;
  padding: 24px;
  margin-bottom: 24px;
`,G=t.div`
  display: inline-flex;
  align-items: center;
  gap: 8px;
  font-weight: 600;
  color: ${r=>{switch(r.status){case"healthy":return"#059669";case"degraded":return"#d97706";case"critical":return"#dc2626";default:return"#6b7280"}}};

  &::before {
    content: '';
    width: 12px;
    height: 12px;
    border-radius: 50%;
    background: ${r=>{switch(r.status){case"healthy":return"#10b981";case"degraded":return"#f59e0b";case"critical":return"#ef4444";default:return"#d1d5db"}}};
  }
`,F=t.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 16px;
  margin-bottom: 32px;
`,u=t.div`
  background: white;
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  padding: 20px;
  text-align: center;
`,f=t.div`
  font-size: 2rem;
  font-weight: 600;
  color: #1f2937;
  margin-bottom: 4px;
`,h=t.div`
  font-size: 0.875rem;
  color: #6b7280;
  font-weight: 500;
`,m=t.section`
  margin-bottom: 32px;
`,g=t.h2`
  font-size: 1.5rem;
  font-weight: 600;
  color: #1f2937;
  margin-bottom: 16px;
`,O=t.div`
  display: flex;
  flex-direction: column;
  gap: 12px;
`,J=t.div`
  background: ${r=>{switch(r.severity){case"critical":return"#fef2f2";case"high":return"#fef3c7";case"medium":return"#f0f9ff";case"low":return"#f9fafb";default:return"#f9fafb"}}};
  border: 1px solid ${r=>{switch(r.severity){case"critical":return"#fecaca";case"high":return"#fcd34d";case"medium":return"#60a5fa";case"low":return"#d1d5db";default:return"#d1d5db"}}};
  border-radius: 6px;
  padding: 16px;
`,P=t.span`
  background: ${r=>{switch(r.severity){case"critical":return"#dc2626";case"high":return"#f59e0b";case"medium":return"#3b82f6";case"low":return"#6b7280";default:return"#6b7280"}}};
  color: white;
  padding: 2px 8px;
  border-radius: 4px;
  font-size: 0.75rem;
  font-weight: 500;
  text-transform: uppercase;
`,U=t.div`
  display: flex;
  flex-direction: column;
  gap: 16px;
`,V=t.div`
  background: ${r=>{switch(r.priority){case"high":return"#fef2f2";case"medium":return"#fffbeb";case"low":return"#f9fafb";default:return"#f9fafb"}}};
  border: 1px solid ${r=>{switch(r.priority){case"high":return"#fecaca";case"medium":return"#fcd34d";case"low":return"#d1d5db";default:return"#d1d5db"}}};
  border-radius: 8px;
  padding: 20px;
`,K=t.div`
  background: ${r=>{switch(r.priority){case"high":return"#dc2626";case"medium":return"#f59e0b";case"low":return"#6b7280";default:return"#6b7280"}}};
  color: white;
  padding: 4px 12px;
  border-radius: 16px;
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
  display: inline-block;
  margin-bottom: 12px;
`,Q=t.ul`
  list-style: none;
  padding: 0;
  margin: 12px 0 0 0;
`,W=t.li`
  background: #f3f4f6;
  border-radius: 4px;
  padding: 8px 12px;
  margin-bottom: 8px;
  font-size: 0.875rem;
`,X=t.div`
  text-align: center;
  padding: 40px;
  color: #6b7280;
`,Y=t.div`
  background: #fef2f2;
  border: 1px solid #fecaca;
  border-radius: 8px;
  padding: 16px;
  margin-bottom: 24px;
  color: #dc2626;
`,Z=t.div`
  background: white;
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  padding: 20px;
  margin-bottom: 24px;
`,ee=t.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px;
  background: ${r=>r.enabled?"#f9fafb":"#f3f4f6"};
  border-radius: 6px;
  margin-bottom: 8px;
  opacity: ${r=>r.enabled?1:.5};
`,re=t.span`
  font-weight: 500;
  color: #1f2937;
`,te=t.span`
  font-size: 0.75rem;
  color: ${r=>r.running?"#059669":"#6b7280"};
  font-weight: ${r=>r.running?600:400};
`,ne=t(b)`
  display: inline-flex;
  align-items: center;
  gap: 8px;
`,de=()=>{const[r,i]=c.useState(null),[y,j]=c.useState(!0),[v,w]=c.useState(null),[S,A]=c.useState(null),[k,E]=c.useState(!1),d=c.useCallback(async()=>{try{j(!0),w(null);const n=await $.getSystemHealth();i(n),A(new Date)}catch(n){w(n instanceof Error?n.message:"Erreur inconnue")}finally{j(!1)}},[]),T=async()=>{try{E(!0),await $.sendTestNotification(),alert("Notification de test envoyée avec succès !")}catch(n){alert(`Erreur lors de l'envoi de la notification de test: ${n instanceof Error?n.message:"Erreur inconnue"}`)}finally{E(!1)}};c.useEffect(()=>{d();const n=setInterval(d,3e4);return()=>clearInterval(n)},[d]);const _=n=>{const s=Object.values(n).flat();return s.length===0?e.jsx("p",{style:{color:"#059669",fontStyle:"italic"},children:"Aucune anomalie détectée"}):e.jsx(O,{children:s.map((o,p)=>e.jsxs(J,{severity:o.severity,children:[e.jsxs("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:"8px"},children:[e.jsx("strong",{children:o.description}),e.jsx(P,{severity:o.severity,children:o.severity})]}),e.jsxs("details",{children:[e.jsx("summary",{style:{cursor:"pointer",color:"#6b7280",fontSize:"0.875rem"},children:"Détails"}),e.jsx("pre",{style:{marginTop:"8px",fontSize:"0.75rem",background:"#f9fafb",padding:"8px",borderRadius:"4px"},children:JSON.stringify(o.details,null,2)})]})]},p))})},z=n=>n.length===0?e.jsx("p",{style:{color:"#059669",fontStyle:"italic"},children:"Aucune recommandation"}):e.jsx(U,{children:n.map((s,o)=>e.jsxs(V,{priority:s.priority,children:[e.jsx(K,{priority:s.priority,children:s.priority}),e.jsx("h4",{style:{margin:"0 0 12px 0",color:"#1f2937"},children:s.title}),e.jsx("p",{style:{margin:"0 0 12px 0",color:"#4b5563",lineHeight:"1.5"},children:s.description}),e.jsx(Q,{children:s.actions.map((p,H)=>e.jsxs(W,{children:["• ",p]},H))})]},o))}),I=n=>e.jsxs(Z,{children:[e.jsx("h3",{style:{margin:"0 0 16px 0",color:"#1f2937"},children:"Statut du Scheduler"}),e.jsxs("div",{style:{marginBottom:"16px"},children:[e.jsx("strong",{children:"État:"})," ",e.jsx("span",{style:{color:n.running?"#059669":"#dc2626"},children:n.running?"En cours d'exécution":"Arrêté"})]}),e.jsxs("div",{children:[e.jsxs("strong",{children:["Tâches (",n.total_tasks,"):"]}),e.jsx("div",{style:{marginTop:"8px"},children:n.tasks.map((s,o)=>e.jsxs(ee,{enabled:s.enabled,running:s.running,children:[e.jsx(re,{children:s.name}),e.jsx(te,{running:s.running,children:s.running?"En cours":"Inactif"})]},o))})]})]});if(y)return e.jsx(x,{children:e.jsx(X,{children:e.jsx("div",{children:"Chargement des métriques de santé..."})})});if(v||!r)return e.jsxs(x,{children:[e.jsxs(Y,{children:[e.jsx("strong",{children:"Erreur:"})," ",v]}),e.jsx(b,{onClick:d,children:"Réessayer"})]});const{system_health:a,anomalies:C,recommendations:R,scheduler_status:D}=r;return e.jsxs(x,{children:[e.jsxs(B,{children:[e.jsx(L,{children:"Tableau de Bord - Santé du Système"}),e.jsxs(M,{children:[e.jsx(ne,{variant:"secondary",onClick:d,disabled:y,children:"🔄 Actualiser"}),e.jsxs(b,{variant:"secondary",onClick:T,disabled:k,children:[k?"⏳":"🔔"," Test Notifications"]})]})]}),S&&e.jsxs("div",{style:{marginBottom:"16px",color:"#6b7280",fontSize:"0.875rem"},children:["Dernière mise à jour: ",S.toLocaleString("fr-FR")]}),e.jsxs(q,{status:a.overall_status,children:[e.jsx("h2",{style:{margin:"0 0 16px 0",color:"#1f2937"},children:"État Global du Système"}),e.jsxs("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center"},children:[e.jsxs(G,{status:a.overall_status,children:[a.overall_status==="healthy"&&"✅ Système sain",a.overall_status==="degraded"&&"⚠️ Système dégradé",a.overall_status==="critical"&&"🚨 Système critique"]}),e.jsxs("div",{style:{textAlign:"right"},children:[e.jsxs("div",{style:{fontSize:"0.875rem",color:"#6b7280"},children:["Anomalies: ",a.anomalies_detected]}),e.jsxs("div",{style:{fontSize:"0.875rem",color:"#6b7280"},children:["Critiques: ",a.critical_anomalies]})]})]})]}),e.jsxs(F,{children:[e.jsxs(u,{children:[e.jsx(f,{children:a.anomalies_detected}),e.jsx(h,{children:"Anomalies Totales"})]}),e.jsxs(u,{children:[e.jsx(f,{children:a.critical_anomalies}),e.jsx(h,{children:"Anomalies Critiques"})]}),e.jsxs(u,{children:[e.jsx(f,{children:a.active_tasks}),e.jsx(h,{children:"Tâches Actives"})]}),e.jsxs(u,{children:[e.jsx(f,{style:{color:a.scheduler_running?"#059669":"#dc2626"},children:a.scheduler_running?"✅":"❌"}),e.jsx(h,{children:"Scheduler"})]})]}),e.jsxs(m,{children:[e.jsx(g,{children:"📊 Anomalies Détectées"}),_(C)]}),e.jsxs(m,{children:[e.jsx(g,{children:"🔧 Recommandations"}),z(R)]}),e.jsxs(m,{children:[e.jsx(g,{children:"⚙️ Statut du Scheduler"}),I(D)]})]})};export{de as default};
//# sourceMappingURL=HealthDashboard-tOmfm8zq.js.map
