import{r as S}from"./vendor-cDl5Ih67.js";import"./admin-D2I4SZO-.js";import{c as f,d as v,p as x}from"./stores-CmSlgjNa.js";import{e as h,a as M}from"./api-XIr9E-cT.js";/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var E={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const C=s=>s.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase().trim(),n=(s,l)=>{const r=S.forwardRef(({color:e="currentColor",size:t=24,strokeWidth:a=2,absoluteStrokeWidth:o,className:c="",children:d,...y},g)=>S.createElement("svg",{ref:g,...E,width:t,height:t,stroke:e,strokeWidth:o?Number(a)*24/Number(t):a,className:["lucide",`lucide-${C(s)}`,c].join(" "),...y},[...l.map(([m,i])=>S.createElement(m,i)),...Array.isArray(d)?d:[d]]));return r.displayName=`${s}`,r};/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const R=n("AlertTriangle",[["path",{d:"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z",key:"c3ski4"}],["path",{d:"M12 9v4",key:"juzpu7"}],["path",{d:"M12 17h.01",key:"p32p05"}]]);/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const q=n("ArrowLeft",[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]]);/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const L=n("BarChart3",[["path",{d:"M3 3v18h18",key:"1s2lah"}],["path",{d:"M18 17V9",key:"2bz60n"}],["path",{d:"M13 17V5",key:"1frdt8"}],["path",{d:"M8 17v-3",key:"17ska0"}]]);/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const j=n("Calculator",[["rect",{width:"16",height:"20",x:"4",y:"2",rx:"2",key:"1nb95v"}],["line",{x1:"8",x2:"16",y1:"6",y2:"6",key:"x4nwl0"}],["line",{x1:"16",x2:"16",y1:"14",y2:"18",key:"wjye3r"}],["path",{d:"M16 10h.01",key:"1m94wz"}],["path",{d:"M12 10h.01",key:"1nrarc"}],["path",{d:"M8 10h.01",key:"19clt8"}],["path",{d:"M12 14h.01",key:"1etili"}],["path",{d:"M8 14h.01",key:"6423bh"}],["path",{d:"M12 18h.01",key:"mhygvu"}],["path",{d:"M8 18h.01",key:"lrp35t"}]]);/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const H=n("Calendar",[["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2",ry:"2",key:"eu3xkr"}],["line",{x1:"16",x2:"16",y1:"2",y2:"6",key:"m3sa8f"}],["line",{x1:"8",x2:"8",y1:"2",y2:"6",key:"18kwsl"}],["line",{x1:"3",x2:"21",y1:"10",y2:"10",key:"xt86sb"}]]);/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const P=n("CheckCircle",[["path",{d:"M22 11.08V12a10 10 0 1 1-5.93-9.14",key:"g774vq"}],["path",{d:"m9 11 3 3L22 4",key:"1pflzl"}]]);/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const V=n("Check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]);/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const $=n("ChevronDown",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]);/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const N=n("ChevronRight",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]);/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const O=n("Clock",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polyline",{points:"12 6 12 12 16 14",key:"68esgv"}]]);/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const T=n("DollarSign",[["line",{x1:"12",x2:"12",y1:"2",y2:"22",key:"7eqyqh"}],["path",{d:"M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6",key:"1b0p4s"}]]);/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const J=n("Download",[["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["polyline",{points:"7 10 12 15 17 10",key:"2ggqvy"}],["line",{x1:"12",x2:"12",y1:"15",y2:"3",key:"1vk2je"}]]);/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Z=n("Eye",[["path",{d:"M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z",key:"rwhkz3"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]]);/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const D=n("FileText",[["path",{d:"M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z",key:"1nnpy2"}],["polyline",{points:"14 2 14 8 20 8",key:"1ew0cm"}],["line",{x1:"16",x2:"8",y1:"13",y2:"13",key:"14keom"}],["line",{x1:"16",x2:"8",y1:"17",y2:"17",key:"17nazh"}],["line",{x1:"10",x2:"8",y1:"9",y2:"9",key:"1a5vjj"}]]);/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const U=n("Home",[["path",{d:"m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",key:"y5dka4"}],["polyline",{points:"9 22 9 12 15 12 15 22",key:"e2us08"}]]);/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const B=n("LogOut",[["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}],["polyline",{points:"16 17 21 12 16 7",key:"1gabdz"}],["line",{x1:"21",x2:"9",y1:"12",y2:"12",key:"1uyos4"}]]);/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */n("MapPin",[["path",{d:"M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z",key:"2oe9fu"}],["circle",{cx:"12",cy:"10",r:"3",key:"ilqhr7"}]]);/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */n("Monitor",[["rect",{width:"20",height:"14",x:"2",y:"3",rx:"2",key:"48i651"}],["line",{x1:"8",x2:"16",y1:"21",y2:"21",key:"1svkeh"}],["line",{x1:"12",x2:"12",y1:"17",y2:"21",key:"vw1qmm"}]]);/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const W=n("Package",[["path",{d:"m7.5 4.27 9 5.15",key:"1c824w"}],["path",{d:"M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z",key:"hh9hay"}],["path",{d:"m3.3 7 8.7 5 8.7-5",key:"g66t2b"}],["path",{d:"M12 22V12",key:"d0xqtd"}]]);/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const F=n("PenSquare",[["path",{d:"M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7",key:"1qinfi"}],["path",{d:"M18.5 2.5a2.12 2.12 0 0 1 3 3L12 15l-4 1 1-4Z",key:"w2jsv5"}]]);/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const X=n("Plus",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]]);/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const G=n("Receipt",[["path",{d:"M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1-2-1Z",key:"wqdwcb"}],["path",{d:"M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8",key:"1h4pet"}],["path",{d:"M12 17V7",key:"pyj7ub"}]]);/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const K=n("Recycle",[["path",{d:"M7 19H4.815a1.83 1.83 0 0 1-1.57-.881 1.785 1.785 0 0 1-.004-1.784L7.196 9.5",key:"x6z5xu"}],["path",{d:"M11 19h8.203a1.83 1.83 0 0 0 1.556-.89 1.784 1.784 0 0 0 0-1.775l-1.226-2.12",key:"1x4zh5"}],["path",{d:"m14 16-3 3 3 3",key:"f6jyew"}],["path",{d:"M8.293 13.596 7.196 9.5 3.1 10.598",key:"wf1obh"}],["path",{d:"m9.344 5.811 1.093-1.892A1.83 1.83 0 0 1 11.985 3a1.784 1.784 0 0 1 1.546.888l3.943 6.843",key:"9tzpgr"}],["path",{d:"m13.378 9.633 4.096 1.098 1.097-4.096",key:"1oe83g"}]]);/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Y=n("RefreshCcw",[["path",{d:"M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",key:"14sxne"}],["path",{d:"M3 3v5h5",key:"1xhq8a"}],["path",{d:"M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16",key:"1hlbsb"}],["path",{d:"M16 16h5v5",key:"ccwih5"}]]);/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Q=n("Save",[["path",{d:"M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z",key:"1owoqh"}],["polyline",{points:"17 21 17 13 7 13 7 21",key:"1md35c"}],["polyline",{points:"7 3 7 8 15 8",key:"8nz8an"}]]);/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const z=n("Tag",[["path",{d:"M12 2H2v10l9.29 9.29c.94.94 2.48.94 3.42 0l6.58-6.58c.94-.94.94-2.48 0-3.42L12 2Z",key:"14b2ls"}],["path",{d:"M7 7h.01",key:"7u93v4"}]]);/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */n("Tags",[["path",{d:"M9 5H2v7l6.29 6.29c.94.94 2.48.94 3.42 0l3.58-3.58c.94-.94.94-2.48 0-3.42L9 5Z",key:"gt587u"}],["path",{d:"M6 9.01V9",key:"1flxpt"}],["path",{d:"m15 5 6.3 6.3a2.4 2.4 0 0 1 0 3.4L17 19",key:"1cbfv1"}]]);/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ee=n("Trash2",[["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6",key:"4alrt4"}],["path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2",key:"v07s0e"}],["line",{x1:"10",x2:"10",y1:"11",y2:"17",key:"1uufr5"}],["line",{x1:"14",x2:"14",y1:"11",y2:"17",key:"xtxkd"}]]);/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */n("TrendingUp",[["polyline",{points:"22 7 13.5 15.5 8.5 10.5 2 17",key:"126l90"}],["polyline",{points:"16 7 22 7 22 13",key:"kwv8wd"}]]);/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const se=n("User",[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]]);/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const re=n("Users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["path",{d:"M16 3.13a4 4 0 0 1 0 7.75",key:"1da9ce"}]]);/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ae=n("Weight",[["circle",{cx:"12",cy:"5",r:"3",key:"rqqgnr"}],["path",{d:"M6.5 8a2 2 0 0 0-1.905 1.46L2.1 18.5A2 2 0 0 0 4 21h16a2 2 0 0 0 1.925-2.54L19.4 9.5A2 2 0 0 0 17.48 8Z",key:"56o5sh"}]]);/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const te=n("X",[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]]),u={async createSession(s){var l,r,e,t,a,o,c,d,y,g,m;try{console.log("Données envoyées à l'API:",s);const i=await h.client.post("/v1/cash-sessions/",s);if(i.data&&i.data.id)return i.data;throw console.error("Réponse invalide de l'API:",i.data),new Error("Réponse invalide de l'API")}catch(i){if(console.error("Erreur lors de la création de la session:",i),console.error("Response data:",(l=i.response)==null?void 0:l.data),console.error("Response status:",(r=i.response)==null?void 0:r.status),console.error("Request URL:",(e=i.config)==null?void 0:e.url),console.error("Request data:",(t=i.config)==null?void 0:t.data),((a=i.response)==null?void 0:a.status)===401)throw new Error("Vous devez être connecté pour créer une session de caisse");if(((o=i.response)==null?void 0:o.status)===400){const p=(c=i.response.data)==null?void 0:c.detail;if(Array.isArray(p)){const w=p.map(k=>k.msg||k.message||JSON.stringify(k)).join(", ");throw new Error(`Erreur de validation: ${w}`)}else throw typeof p=="string"?new Error(`Erreur de validation: ${p}`):p?new Error(`Erreur de validation: ${JSON.stringify(p)}`):new Error("Une session est peut-être déjà ouverte pour cet opérateur ou cette caisse. Vérifiez la session courante.")}else throw(y=(d=i.response)==null?void 0:d.data)!=null&&y.detail?new Error(i.response.data.detail):(m=(g=i.response)==null?void 0:g.data)!=null&&m.message?new Error(i.response.data.message):i.message?new Error(i.message):new Error("Erreur lors de la création de la session")}},async getSession(s){var l,r;try{const e=await h.client.get(`/v1/cash-sessions/${s}`);return e.data&&e.data.id?e.data:(l=e.data)!=null&&l.success&&((r=e.data)!=null&&r.data)?e.data.data:null}catch(e){return console.error("Erreur lors de la récupération de la session:",e),null}},async getSessions(){try{const s=await h.client.get("/v1/cash-sessions/");return s.data.success&&s.data.data?s.data.data:[]}catch(s){return console.error("Erreur lors de la récupération des sessions:",s),[]}},async updateSession(s,l){var r,e,t,a;try{const o=await h.client.put(`/v1/cash-sessions/${s}`,l);if(o.data.success&&o.data.data)return o.data.data;throw new Error(o.data.message||"Erreur lors de la mise à jour de la session")}catch(o){throw console.error("Erreur lors de la mise à jour de la session:",o),(e=(r=o.response)==null?void 0:r.data)!=null&&e.detail?new Error(o.response.data.detail):(a=(t=o.response)==null?void 0:t.data)!=null&&a.message?new Error(o.response.data.message):o.message?new Error(o.message):new Error("Erreur lors de la mise à jour de la session")}},async closeSession(s){var l,r,e,t;try{return(await h.client.put(`/v1/cash-sessions/${s}`,{status:"closed"})).data.success||!1}catch(a){throw console.error("Erreur lors de la fermeture de la session:",a),(r=(l=a.response)==null?void 0:l.data)!=null&&r.detail?new Error(a.response.data.detail):(t=(e=a.response)==null?void 0:e.data)!=null&&t.message?new Error(a.response.data.message):a.message?new Error(a.message):new Error("Erreur lors de la fermeture de la session")}},async closeSessionWithAmounts(s,l,r){var e,t,a,o;try{const c=await h.client.post(`/v1/cash-sessions/${s}/close`,{actual_amount:l,variance_comment:r});if(c.data&&c.data.id)return c.data;throw new Error("Réponse invalide de l'API lors de la fermeture")}catch(c){throw console.error("Erreur lors de la fermeture de la session:",c),(t=(e=c.response)==null?void 0:e.data)!=null&&t.detail?new Error(c.response.data.detail):(o=(a=c.response)==null?void 0:a.data)!=null&&o.message?new Error(c.response.data.message):c.message?new Error(c.message):new Error("Erreur lors de la fermeture de la session")}},async getCurrentSession(){try{const s=await h.client.get("/v1/cash-sessions/current");return s.data&&s.data.id?s.data:null}catch(s){return console.error("Erreur lors de la récupération de la session courante:",s),null}},async getRegisterSessionStatus(s){try{const r=(await h.client.get(`/v1/cash-sessions/status/${s}`)).data;return{is_active:!!(r!=null&&r.is_active),session_id:(r==null?void 0:r.session_id)??null}}catch(l){return console.error("Erreur lors de la récupération du statut de session pour la caisse:",l),{is_active:!1,session_id:null}}}},oe={async getRegistersStatus(){try{const l=(await h.client.get("/v1/cash-registers/status")).data;return Array.isArray(l==null?void 0:l.data)?l.data:[]}catch(s){return console.error("Erreur lors de la récupération du statut des caisses:",s),[]}}},ne=f()(v(x((s,l)=>({currentSession:null,sessions:[],currentSaleItems:[],loading:!1,error:null,setCurrentSession:r=>s({currentSession:r}),setSessions:r=>s({sessions:r}),setLoading:r=>s({loading:r}),setError:r=>s({error:r}),clearError:()=>s({error:null}),addSaleItem:r=>{const e={...r,id:`item-${Date.now()}-${Math.random().toString(36).substr(2,9)}`};s(t=>({currentSaleItems:[...t.currentSaleItems,e]}))},removeSaleItem:r=>{s(e=>({currentSaleItems:e.currentSaleItems.filter(t=>t.id!==r)}))},updateSaleItem:(r,e,t,a)=>{s(o=>({currentSaleItems:o.currentSaleItems.map(c=>c.id===r?{...c,quantity:e,weight:t,price:a,total:e*a}:c)}))},clearCurrentSale:()=>{s({currentSaleItems:[]})},submitSale:async(r,e)=>{const{currentSession:t}=l();if(!t){const a="Aucune session de caisse active";return console.error("[submitSale]",a),s({error:a}),!1}s({loading:!0,error:null});try{const a={cash_session_id:t.id,items:r.map(d=>({category:d.category,quantity:d.quantity,weight:d.weight,unit_price:d.price,total_price:d.total})),total_amount:r.reduce((d,y)=>d+y.total,0)},o={...a,donation:(e==null?void 0:e.donation)??0,payment_method:(e==null?void 0:e.paymentMethod)??"cash",cash_given:(e==null?void 0:e.paymentMethod)==="cash"?(e==null?void 0:e.cashGiven)??null:null,change:(e==null?void 0:e.paymentMethod)==="cash"?(e==null?void 0:e.change)??null:null};console.log("[submitSale] Preparing sale:",a),console.log("[submitSale] Sending POST to /sales/");const c=await M.post("/sales/",o);return console.log("[submitSale] Sale created successfully:",c.data),s({currentSaleItems:[],loading:!1}),!0}catch(a){const o=a instanceof Error?a.message:"Erreur lors de l'enregistrement de la vente";return console.error("[submitSale] Error:",o,a),s({error:o,loading:!1}),!1}},openSession:async r=>{s({loading:!0,error:null});try{if(r.register_id){const a=await u.getRegisterSessionStatus(r.register_id);if(a.is_active&&a.session_id){const o=await u.getSession(a.session_id);if(o)return s({currentSession:o,loading:!1}),localStorage.setItem("currentCashSession",JSON.stringify(o)),o}}const e=await u.getCurrentSession();if(e)return s({currentSession:e,loading:!1}),localStorage.setItem("currentCashSession",JSON.stringify(e)),e;const t=await u.createSession(r);return s({currentSession:t,loading:!1}),localStorage.setItem("currentCashSession",JSON.stringify(t)),t}catch(e){const t=e instanceof Error?e.message:"Erreur lors de l'ouverture de session";if(r.register_id&&/déjà ouverte|already open/i.test(t))try{const a=await u.getRegisterSessionStatus(r.register_id);if(a.is_active&&a.session_id){const o=await u.getSession(a.session_id);if(o)return s({currentSession:o,loading:!1}),localStorage.setItem("currentCashSession",JSON.stringify(o)),o}}catch{}return s({error:t,loading:!1}),null}},closeSession:async(r,e)=>{s({loading:!0,error:null});try{let t;return e?t=!!await u.closeSessionWithAmounts(r,e.actual_amount,e.variance_comment):t=await u.closeSession(r),t&&(s({currentSession:null,loading:!1}),localStorage.removeItem("currentCashSession")),t}catch(t){const a=t instanceof Error?t.message:"Erreur lors de la fermeture de session";return s({error:a,loading:!1}),!1}},updateSession:async(r,e)=>{s({loading:!0,error:null});try{const t=await u.updateSession(r,e);if(t){const{currentSession:a}=l();a&&a.id===r&&(s({currentSession:t,loading:!1}),localStorage.setItem("currentCashSession",JSON.stringify(t)))}return!!t}catch(t){const a=t instanceof Error?t.message:"Erreur lors de la mise à jour de session";return s({error:a,loading:!1}),!1}},fetchSessions:async()=>{s({loading:!0,error:null});try{const r=await u.getSessions();s({sessions:r,loading:!1})}catch(r){const e=r instanceof Error?r.message:"Erreur lors du chargement des sessions";s({error:e,loading:!1})}},fetchCurrentSession:async()=>{s({loading:!0,error:null});try{const r=localStorage.getItem("currentCashSession");if(r){const t=JSON.parse(r),a=await u.getSession(t.id);if(a&&a.status==="open"){s({currentSession:a,loading:!1});return}else localStorage.removeItem("currentCashSession")}const e=await u.getCurrentSession();if(e&&e.status==="open"){s({currentSession:e,loading:!1}),localStorage.setItem("currentCashSession",JSON.stringify(e));return}s({currentSession:null,loading:!1})}catch(r){const e=r instanceof Error?r.message:"Erreur lors de la récupération de la session";s({error:e,loading:!1})}},refreshSession:async()=>{const{currentSession:r}=l();r&&await l().fetchCurrentSession()},resumeSession:async r=>{s({loading:!0,error:null});try{const e=await u.getSession(r);return e&&e.status==="open"?(s({currentSession:e,loading:!1}),localStorage.setItem("currentCashSession",JSON.stringify(e)),!0):(s({loading:!1,error:"Aucune session ouverte trouvée pour cet identifiant"}),!1)}catch(e){const t=e instanceof Error?e.message:"Erreur lors de la reprise de session";return s({error:t,loading:!1}),!1}}}),{name:"cash-session-store",partialize:s=>({currentSession:s.currentSession,currentSaleItems:s.currentSaleItems})}),{name:"cash-session-store"}));export{q as A,L as B,$ as C,T as D,Z as E,D as F,U as H,B as L,W as P,K as R,Q as S,ee as T,re as U,ae as W,te as X,G as a,j as b,oe as c,u as d,N as e,F as f,se as g,R as h,P as i,Y as j,J as k,H as l,O as m,X as n,V as o,z as p,ne as u};
//# sourceMappingURL=cash-Cdpp_gQO.js.map
