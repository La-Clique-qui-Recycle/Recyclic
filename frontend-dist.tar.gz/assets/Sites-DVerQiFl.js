import{j as e}from"./admin-D2I4SZO-.js";import{r as h}from"./vendor-cDl5Ih67.js";import{d as a}from"./ui-DXFJp4I_.js";import{b as Q,e as X,g as Y,f as ee,h as re}from"./api-7vu9KqRw.js";import"./api-XIr9E-cT.js";import"./stores-CmSlgjNa.js";const te=a.div`
  background: white;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 6px rgba(0,0,0,0.06);
  max-width: 500px;
  margin: 0 auto;
`,se=a.h3`
  margin: 0 0 20px 0;
  color: #333;
`,O=a.div`
  margin-bottom: 16px;
`,V=a.label`
  display: block;
  margin-bottom: 4px;
  font-weight: 500;
  color: #555;
`,N=a.input`
  width: 100%;
  padding: 8px 12px;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 14px;

  &:focus {
    outline: none;
    border-color: #2e7d32;
    box-shadow: 0 0 0 2px rgba(46, 125, 50, 0.2);
  }
`,ie=a.div`
  display: flex;
  align-items: center;
  gap: 8px;
`,oe=a.input`
  margin: 0;
`,ae=a.div`
  display: flex;
  gap: 12px;
  justify-content: flex-end;
  margin-top: 20px;
`,G=a.button`
  padding: 10px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
  font-weight: 500;

  ${l=>l.variant==="primary"?`
    background: #2e7d32;
    color: white;

    &:hover {
      background: #1b5e20;
    }
  `:`
    background: #f5f5f5;
    color: #666;
    border: 1px solid #ddd;

    &:hover {
      background: #e0e0e0;
    }
  `}

  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
`,T=a.div`
  color: #f44336;
  font-size: 14px;
  margin-top: 8px;
`,ne=a.div`
  .sr-only {
    position: absolute !important;
    width: 1px !important;
    height: 1px !important;
    padding: 0 !important;
    margin: -1px !important;
    overflow: hidden !important;
    clip: rect(0, 0, 0, 0) !important;
    white-space: nowrap !important;
    border: 0 !important;
  }
`;function le({site:l,onSuccess:M,onCancel:o}){const[c,D]=h.useState({name:"",address:"",city:"",postal_code:"",country:"",is_active:!0}),[v,S]=h.useState(!1),[k,g]=h.useState(null),[t,u]=h.useState({}),[j,_]=h.useState({});h.useEffect(()=>{l&&D({name:l.name||"",address:l.address||"",city:l.city||"",postal_code:l.postal_code||"",country:l.country||"",is_active:l.is_active}),u({}),_({}),g(null)},[l]);const w=(m,n)=>{switch(m){case"name":return n.trim()?n.trim().length<2?"Le nom doit contenir au moins 2 caractères":n.trim().length>100?"Le nom ne peut pas dépasser 100 caractères":null:"Le nom du site est obligatoire";case"address":return n&&n.length>200?"L'adresse ne peut pas dépasser 200 caractères":null;case"city":return n&&n.length>100?"La ville ne peut pas dépasser 100 caractères":null;case"postal_code":return n&&!/^[0-9A-Za-z\s-]{2,10}$/.test(n)?"Le code postal doit contenir 2 à 10 caractères alphanumériques":null;case"country":return n&&n.length>100?"Le pays ne peut pas dépasser 100 caractères":null;default:return null}},E=()=>{const m={};return Object.keys(c).forEach(n=>{if(n!=="is_active"){const C=w(n,c[n]);C&&(m[n]=C)}}),u(m),Object.keys(m).length===0},P=async m=>{var C,b,z,s,p,x,L,d,f;m.preventDefault();const n=Object.keys(c).reduce((i,r)=>(i[r]=!0,i),{});if(_(n),!!E()){S(!0),g(null);try{l?await Q(l.id,c):await X(c),M()}catch(i){console.error("Erreur lors de la sauvegarde du site:",i);let r="Erreur lors de la sauvegarde";if(((C=i==null?void 0:i.response)==null?void 0:C.status)===401)r="Session expirée. Veuillez vous reconnecter.";else if(((b=i==null?void 0:i.response)==null?void 0:b.status)===403)r="Vous n'avez pas les permissions nécessaires pour cette action.";else if(((z=i==null?void 0:i.response)==null?void 0:z.status)===409)r="Un site avec ce nom existe déjà.";else if(((s=i==null?void 0:i.response)==null?void 0:s.status)===422){if(r="Données invalides. Veuillez vérifier les champs.",(x=(p=i==null?void 0:i.response)==null?void 0:p.data)!=null&&x.detail&&Array.isArray(i.response.data.detail)){const y={};i.response.data.detail.forEach(A=>{if(A.loc&&A.loc.length>0){const J=A.loc[A.loc.length-1];y[J]=A.msg}}),u(y)}}else((L=i==null?void 0:i.response)==null?void 0:L.status)>=500?r="Erreur serveur. Veuillez réessayer dans quelques instants.":(i==null?void 0:i.code)==="NETWORK_ERROR"||!navigator.onLine?r="Problème de connexion réseau. Veuillez vérifier votre connexion internet.":(f=(d=i==null?void 0:i.response)==null?void 0:d.data)!=null&&f.detail?r=i.response.data.detail:i!=null&&i.message&&(r=i.message);g(r)}finally{S(!1)}}},$=m=>{const{name:n,value:C,type:b,checked:z}=m.target,s=b==="checkbox"?z:C;D(p=>({...p,[n]:s})),t[n]&&u(p=>{const x={...p};return delete x[n],x}),k&&g(null)},B=m=>{const{name:n,value:C}=m.target;if(_(b=>({...b,[n]:!0})),n!=="is_active"){const b=w(n,C);b&&u(z=>({...z,[n]:b}))}};return e.jsxs(e.Fragment,{children:[e.jsx(ne,{}),e.jsxs(te,{role:"dialog","aria-modal":"true","aria-labelledby":"site-form-title","aria-describedby":"site-form-description","data-testid":"site-form-container",children:[e.jsx(se,{id:"site-form-title",children:l?"Modifier le site":"Créer un site"}),e.jsx("div",{id:"site-form-description",className:"sr-only",children:l?`Formulaire de modification du site ${l.name}. Utilisez Tab pour naviguer entre les champs et Entrée pour soumettre.`:"Formulaire de création d'un nouveau site. Le nom est obligatoire. Utilisez Tab pour naviguer entre les champs et Entrée pour soumettre."}),e.jsxs("form",{onSubmit:P,role:"form","aria-labelledby":"site-form-title",noValidate:!0,"data-testid":"site-form",children:[e.jsxs(O,{children:[e.jsx(V,{htmlFor:"name",children:"Nom *"}),e.jsx(N,{id:"name",name:"name",type:"text",value:c.name,onChange:$,onBlur:B,required:!0,"aria-required":"true","aria-describedby":`name-description ${t.name?"name-error":""}`,"aria-invalid":t.name?"true":"false",placeholder:"Entrez le nom du site","data-testid":"site-name-input",style:{borderColor:t.name?"#f44336":void 0,borderWidth:t.name?"2px":void 0}}),e.jsx("div",{id:"name-description",className:"sr-only",children:"Le nom du site est obligatoire et doit être unique"}),t.name&&e.jsx(T,{id:"name-error",role:"alert","aria-live":"polite","data-testid":"name-error",children:t.name})]}),e.jsxs(O,{children:[e.jsx(V,{htmlFor:"address",children:"Adresse"}),e.jsx(N,{id:"address",name:"address",type:"text",value:c.address,onChange:$,onBlur:B,"aria-describedby":`address-description ${t.address?"address-error":""}`,"aria-invalid":t.address?"true":"false",placeholder:"Entrez l'adresse du site","data-testid":"site-address-input",style:{borderColor:t.address?"#f44336":void 0,borderWidth:t.address?"2px":void 0}}),e.jsx("div",{id:"address-description",className:"sr-only",children:"Adresse physique du site (optionnel)"}),t.address&&e.jsx(T,{id:"address-error",role:"alert","aria-live":"polite","data-testid":"address-error",children:t.address})]}),e.jsxs(O,{children:[e.jsx(V,{htmlFor:"city",children:"Ville"}),e.jsx(N,{id:"city",name:"city",type:"text",value:c.city,onChange:$,onBlur:B,"aria-describedby":`city-description ${t.city?"city-error":""}`,"aria-invalid":t.city?"true":"false",placeholder:"Entrez la ville","data-testid":"site-city-input",style:{borderColor:t.city?"#f44336":void 0,borderWidth:t.city?"2px":void 0}}),e.jsx("div",{id:"city-description",className:"sr-only",children:"Ville où se trouve le site (optionnel)"}),t.city&&e.jsx(T,{id:"city-error",role:"alert","aria-live":"polite","data-testid":"city-error",children:t.city})]}),e.jsxs(O,{children:[e.jsx(V,{htmlFor:"postal_code",children:"Code postal"}),e.jsx(N,{id:"postal_code",name:"postal_code",type:"text",value:c.postal_code,onChange:$,onBlur:B,"aria-describedby":`postal-code-description ${t.postal_code?"postal-code-error":""}`,"aria-invalid":t.postal_code?"true":"false",placeholder:"Entrez le code postal","data-testid":"site-postal-code-input",style:{borderColor:t.postal_code?"#f44336":void 0,borderWidth:t.postal_code?"2px":void 0}}),e.jsx("div",{id:"postal-code-description",className:"sr-only",children:"Code postal du site (optionnel)"}),t.postal_code&&e.jsx(T,{id:"postal-code-error",role:"alert","aria-live":"polite","data-testid":"postal-code-error",children:t.postal_code})]}),e.jsxs(O,{children:[e.jsx(V,{htmlFor:"country",children:"Pays"}),e.jsx(N,{id:"country",name:"country",type:"text",value:c.country,onChange:$,onBlur:B,"aria-describedby":`country-description ${t.country?"country-error":""}`,"aria-invalid":t.country?"true":"false",placeholder:"Entrez le pays","data-testid":"site-country-input",style:{borderColor:t.country?"#f44336":void 0,borderWidth:t.country?"2px":void 0}}),e.jsx("div",{id:"country-description",className:"sr-only",children:"Pays où se trouve le site (optionnel)"}),t.country&&e.jsx(T,{id:"country-error",role:"alert","aria-live":"polite","data-testid":"country-error",children:t.country})]}),e.jsxs(O,{children:[e.jsxs(ie,{children:[e.jsx(oe,{id:"is_active",name:"is_active",type:"checkbox",checked:c.is_active,onChange:$,"aria-describedby":"active-description","data-testid":"site-active-checkbox"}),e.jsx(V,{htmlFor:"is_active",children:"Site actif"})]}),e.jsx("div",{id:"active-description",className:"sr-only",children:"Cochez cette case pour activer le site. Les sites inactifs ne seront pas disponibles pour les opérations."})]}),k&&e.jsx(T,{role:"alert","aria-live":"assertive","aria-atomic":"true","data-testid":"form-error-message",children:k}),e.jsxs(ae,{role:"group","aria-label":"Actions du formulaire",children:[e.jsx(G,{type:"button",variant:"secondary",onClick:o,"aria-label":"Annuler et fermer le formulaire","data-testid":"cancel-button",children:"Annuler"}),e.jsx(G,{type:"submit",variant:"primary",disabled:v,"aria-label":v?"Sauvegarde en cours, veuillez patienter":l?`Modifier le site ${l.name}`:"Créer le nouveau site","data-testid":"submit-button",children:v?"Sauvegarde...":l?"Modifier":"Créer"})]})]})]})]})}const de=a.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
`,ce=a.div`
  background: white;
  padding: 24px;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  max-width: 500px;
  width: 90%;
  max-height: 80vh;
  overflow-y: auto;
`,pe=a.h3`
  margin: 0 0 16px 0;
  color: ${l=>l.variant==="warning"?"#ff9800":"#d32f2f"};
  font-size: 18px;
`,W=a.p`
  margin: 0 0 16px 0;
  color: #666;
  line-height: 1.5;
`,ue=a.div`
  background: #fff3e0;
  border: 1px solid #ffcc02;
  border-radius: 4px;
  padding: 16px;
  margin: 16px 0;
`,K=a.div`
  margin-bottom: 12px;

  &:last-child {
    margin-bottom: 0;
  }
`,U=a.h4`
  margin: 0 0 8px 0;
  font-size: 14px;
  font-weight: 600;
  color: #e65100;
`,q=a.div`
  padding: 4px 0;
  font-size: 14px;
  color: #666;
`,xe=a.div`
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 16px;
  background: #f5f5f5;
  border-radius: 4px;
  margin: 16px 0;
`,he=a.div`
  width: 16px;
  height: 16px;
  border: 2px solid #e0e0e0;
  border-top: 2px solid #1976d2;
  border-radius: 50%;
  animation: spin 1s linear infinite;

  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }
`,me=a.div`
  background: #ffebee;
  border: 1px solid #ffcdd2;
  border-radius: 4px;
  padding: 12px;
  margin: 16px 0;
  color: #c62828;
  font-size: 14px;
`,fe=a.div`
  display: flex;
  gap: 12px;
  justify-content: flex-end;
  margin-top: 24px;
`,Z=a.button`
  padding: 10px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
  font-weight: 500;

  ${l=>l.variant==="danger"?`
    background: #d32f2f;
    color: white;

    &:hover:not(:disabled) {
      background: #b71c1c;
    }
  `:`
    background: #f5f5f5;
    color: #666;
    border: 1px solid #ddd;

    &:hover:not(:disabled) {
      background: #e0e0e0;
    }
  `}

  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
`;function ge({isOpen:l,siteName:M,dependencies:o,checkingDependencies:c=!1,onConfirm:D,onCancel:v,loading:S=!1}){if(!l)return null;const k=()=>{var j,_;return c?e.jsxs(xe,{children:[e.jsx(he,{}),e.jsx("span",{children:"Vérification des dépendances en cours..."})]}):o!=null&&o.error?e.jsxs(me,{children:[e.jsx("strong",{children:"Attention :"})," ",o.error]}):o!=null&&o.hasBlockingDependencies?e.jsxs(ue,{children:[e.jsx(W,{style:{margin:"0 0 16px 0",color:"#e65100"},children:e.jsx("strong",{children:"Ce site ne peut pas être supprimé car il est utilisé par :"})}),((j=o.cashRegisters)==null?void 0:j.length)>0&&e.jsxs(K,{children:[e.jsxs(U,{children:["Postes de caisse (",o.cashRegisters.length,")"]}),o.cashRegisters.slice(0,5).map((w,E)=>e.jsxs(q,{children:["• ",w.name||`Poste de caisse ${w.id}`]},E)),o.cashRegisters.length>5&&e.jsxs(q,{children:["• ... et ",o.cashRegisters.length-5," autres postes de caisse"]})]}),((_=o.cashSessions)==null?void 0:_.length)>0&&e.jsxs(K,{children:[e.jsxs(U,{children:["Sessions de caisse (",o.cashSessions.length,")"]}),o.cashSessions.slice(0,5).map((w,E)=>e.jsxs(q,{children:["• Session du ",new Date(w.created_at).toLocaleDateString()]},E)),o.cashSessions.length>5&&e.jsxs(q,{children:["• ... et ",o.cashSessions.length-5," autres sessions"]})]}),e.jsx(W,{style:{margin:"16px 0 0 0",color:"#e65100",fontSize:"14px"},children:"Pour supprimer ce site, vous devez d'abord supprimer ou réassigner tous les éléments qui l'utilisent."})]}):null},g=!c&&(!o||!o.hasBlockingDependencies),t=()=>c?"Vérification en cours...":o!=null&&o.hasBlockingDependencies?"Suppression impossible":"Confirmer la suppression",u=()=>o!=null&&o.hasBlockingDependencies?"warning":"danger";return e.jsx(de,{onClick:v,role:"dialog","aria-modal":"true","aria-labelledby":"delete-modal-title","data-testid":"site-delete-modal",children:e.jsxs(ce,{onClick:j=>j.stopPropagation(),role:"document",children:[e.jsx(pe,{id:"delete-modal-title",variant:u(),children:t()}),e.jsx(W,{children:o!=null&&o.hasBlockingDependencies?e.jsxs(e.Fragment,{children:['Le site "',e.jsx("strong",{children:M}),'" ne peut pas être supprimé.']}):e.jsxs(e.Fragment,{children:['Êtes-vous sûr de vouloir supprimer le site "',e.jsx("strong",{children:M}),'" ?',e.jsx("br",{}),"Cette action est irréversible."]})}),k(),e.jsxs(fe,{children:[e.jsx(Z,{type:"button",onClick:v,disabled:S,"data-testid":"cancel-delete-button",children:o!=null&&o.hasBlockingDependencies?"Fermer":"Annuler"}),g&&e.jsx(Z,{type:"button",variant:"danger",onClick:D,disabled:S||c,"data-testid":"confirm-delete-button",children:S?"Suppression...":"Supprimer"})]})]})})}const be=a.div`
  background: white;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 6px rgba(0,0,0,0.06);
`,ye=a.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 16px;
`,ve=a.h2`
  margin: 0;
`,I=a.button`
  background: #2e7d32;
  color: white;
  border: none;
  padding: 10px 14px;
  border-radius: 6px;
  cursor: pointer;
`,je=a.table`
  width: 100%;
  border-collapse: collapse;
`,R=a.th`
  text-align: left;
  padding: 10px;
  border-bottom: 1px solid #eee;
`,F=a.td`
  padding: 10px;
  border-bottom: 1px solid #f5f5f5;
`,H=a.button`
  padding: 4px 8px;
  margin: 0 2px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 12px;

  ${l=>l.variant==="edit"?`
    background: #2196f3;
    color: white;

    &:hover {
      background: #1976d2;
    }
  `:`
    background: #f44336;
    color: white;

    &:hover {
      background: #d32f2f;
    }
  `}
`,Ce=a.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
`,Se=a.div`
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border: 0;

  &.sr-only {
    position: absolute !important;
    width: 1px !important;
    height: 1px !important;
    padding: 0 !important;
    margin: -1px !important;
    overflow: hidden !important;
    clip: rect(0, 0, 0, 0) !important;
    white-space: nowrap !important;
    border: 0 !important;
  }
`;function $e(){var z;const[l,M]=h.useState([]),[o,c]=h.useState(!0),[D,v]=h.useState(null),[S,k]=h.useState(!1),[g,t]=h.useState(null),[u,j]=h.useState({isOpen:!1,site:null}),[_,w]=h.useState(!1),E=async()=>{var s,p,x,L;try{c(!0),v(null);const d=await Y();M(d)}catch(d){console.error("Erreur lors du chargement des sites:",d);let f="Erreur de chargement des sites";((s=d==null?void 0:d.response)==null?void 0:s.status)===401?f="Session expirée. Veuillez vous reconnecter.":((p=d==null?void 0:d.response)==null?void 0:p.status)===403?f="Vous n'avez pas les permissions nécessaires pour accéder aux sites.":((x=d==null?void 0:d.response)==null?void 0:x.status)===404?f="Service de gestion des sites temporairement indisponible.":((L=d==null?void 0:d.response)==null?void 0:L.status)>=500?f="Erreur serveur. Veuillez réessayer dans quelques instants.":(d==null?void 0:d.code)==="NETWORK_ERROR"||!navigator.onLine?f="Problème de connexion réseau. Vérifiez votre connexion internet.":d!=null&&d.message&&(f=d.message),v(f)}finally{c(!1)}};h.useEffect(()=>{E()},[]),h.useEffect(()=>{const s=p=>{S&&p.key==="Escape"&&n(),u.isOpen&&p.key==="Escape"&&b()};return document.addEventListener("keydown",s),()=>{document.removeEventListener("keydown",s)}},[S,u.isOpen]);const P=()=>{t(null),k(!0)},$=s=>{t(s),k(!0)},B=async s=>{j({isOpen:!0,site:s,dependencies:null,checkingDependencies:!0});try{const p=await ee(s.id);j(x=>({...x,dependencies:p,checkingDependencies:!1}))}catch(p){console.error("Erreur lors de la vérification des dépendances:",p),j(x=>({...x,dependencies:{error:"Impossible de vérifier les dépendances du site",hasBlockingDependencies:!1},checkingDependencies:!1}))}},m=()=>{k(!1),t(null),E()},n=()=>{k(!1),t(null)},C=async()=>{var s,p,x,L,d,f,i;if(u.site)try{w(!0),v(null),await re(u.site.id),j({isOpen:!1,site:null,dependencies:void 0,checkingDependencies:!1}),E()}catch(r){console.error("Erreur lors de la suppression du site:",r);let y="Erreur lors de la suppression du site";((s=r==null?void 0:r.response)==null?void 0:s.status)===401?y="Session expirée. Veuillez vous reconnecter.":((p=r==null?void 0:r.response)==null?void 0:p.status)===403?y="Vous n'avez pas les permissions nécessaires pour supprimer ce site.":((x=r==null?void 0:r.response)==null?void 0:x.status)===404?y="Ce site n'existe plus ou a déjà été supprimé.":((L=r==null?void 0:r.response)==null?void 0:L.status)===409?y="Ce site ne peut pas être supprimé car il est utilisé par d'autres éléments du système.":((d=r==null?void 0:r.response)==null?void 0:d.status)>=500?y="Erreur serveur lors de la suppression. Veuillez réessayer.":(r==null?void 0:r.code)==="NETWORK_ERROR"||!navigator.onLine?y="Problème de connexion réseau. Veuillez vérifier votre connexion internet.":(i=(f=r==null?void 0:r.response)==null?void 0:f.data)!=null&&i.detail?y=r.response.data.detail:r!=null&&r.message&&(y=r.message),v(y)}finally{w(!1)}},b=()=>{j({isOpen:!1,site:null,dependencies:void 0,checkingDependencies:!1})};return e.jsxs(be,{children:[e.jsxs(ye,{children:[e.jsx(ve,{id:"sites-title",children:"Sites"}),e.jsx(I,{onClick:P,"aria-label":"Créer un nouveau site","data-testid":"create-site-button",children:"Créer un site"})]}),o&&e.jsx("div",{role:"status","aria-live":"polite","aria-label":"Chargement des sites en cours","data-testid":"loading-indicator",children:"Chargement..."}),D&&e.jsxs("div",{role:"alert","aria-live":"assertive",style:{color:"#d32f2f",backgroundColor:"#ffebee",border:"1px solid #ffcdd2",borderRadius:"4px",padding:"12px",marginBottom:"16px",display:"flex",alignItems:"center",justifyContent:"space-between"},"data-testid":"error-message",children:[e.jsx("span",{children:D}),e.jsx(I,{onClick:E,style:{marginLeft:"16px",padding:"4px 8px",fontSize:"12px",backgroundColor:"#1976d2",color:"white"},"aria-label":"Réessayer le chargement des sites","data-testid":"retry-button",children:"Réessayer"})]}),!o&&!D&&e.jsxs(je,{role:"table","aria-labelledby":"sites-title","aria-describedby":"sites-description","data-testid":"sites-table",children:[e.jsx("div",{id:"sites-description",className:"sr-only",children:"Table des sites avec leurs informations et actions disponibles"}),e.jsx("thead",{children:e.jsxs("tr",{role:"row",children:[e.jsx(R,{role:"columnheader",scope:"col",children:"Nom"}),e.jsx(R,{role:"columnheader",scope:"col",children:"Adresse"}),e.jsx(R,{role:"columnheader",scope:"col",children:"Ville"}),e.jsx(R,{role:"columnheader",scope:"col",children:"Code postal"}),e.jsx(R,{role:"columnheader",scope:"col",children:"Pays"}),e.jsx(R,{role:"columnheader",scope:"col",children:"Actif"}),e.jsx(R,{role:"columnheader",scope:"col",children:"Actions"})]})}),e.jsx("tbody",{children:l.length===0?e.jsx("tr",{role:"row",children:e.jsx(F,{role:"cell",colSpan:7,style:{textAlign:"center",padding:"40px"},children:e.jsxs("div",{style:{color:"#666",fontSize:"16px",display:"flex",flexDirection:"column",alignItems:"center",gap:"16px"},"data-testid":"empty-state",children:[e.jsx("div",{style:{fontSize:"48px",opacity:.3},children:"🏢"}),e.jsxs("div",{children:[e.jsx("div",{style:{fontWeight:"bold",marginBottom:"8px"},children:"Aucun site configuré"}),e.jsx("div",{style:{fontSize:"14px",marginBottom:"16px"},children:"Commencez par créer votre premier site pour organiser vos opérations."}),e.jsx(I,{onClick:P,style:{backgroundColor:"#2e7d32",color:"white",padding:"8px 16px"},"aria-label":"Créer le premier site","data-testid":"create-first-site-button",children:"Créer un site"})]})]})})}):l.map(s=>e.jsxs("tr",{role:"row",children:[e.jsx(F,{role:"cell",children:s.name}),e.jsx(F,{role:"cell",children:s.address||"-"}),e.jsx(F,{role:"cell",children:s.city||"-"}),e.jsx(F,{role:"cell",children:s.postal_code||"-"}),e.jsx(F,{role:"cell",children:s.country||"-"}),e.jsx(F,{role:"cell",children:e.jsx("span",{"aria-label":s.is_active?"Site actif":"Site inactif","data-testid":`site-status-${s.id}`,children:s.is_active?"Oui":"Non"})}),e.jsxs(F,{role:"cell",children:[e.jsx(H,{variant:"edit",onClick:()=>$(s),"aria-label":`Modifier le site ${s.name}`,"data-testid":`edit-site-${s.id}`,title:`Modifier le site ${s.name}`,children:"Modifier"}),e.jsx(H,{variant:"delete",onClick:()=>B(s),"aria-label":`Supprimer le site ${s.name}`,"data-testid":`delete-site-${s.id}`,title:`Supprimer le site ${s.name}`,children:"Supprimer"})]})]},s.id))})]}),S&&e.jsx(Ce,{onClick:n,role:"dialog","aria-modal":"true","aria-labelledby":g?"edit-site-modal-title":"create-site-modal-title","data-testid":"site-form-modal",children:e.jsxs("div",{onClick:s=>s.stopPropagation(),role:"document","aria-describedby":"site-form-content",children:[e.jsx(Se,{id:g?"edit-site-modal-title":"create-site-modal-title",children:g?`Modifier le site ${g.name}`:"Créer un nouveau site"}),e.jsx(le,{site:g,onSuccess:m,onCancel:n})]})}),e.jsx(ge,{isOpen:u.isOpen,siteName:((z=u.site)==null?void 0:z.name)||"",dependencies:u.dependencies,checkingDependencies:u.checkingDependencies,onConfirm:C,onCancel:b,loading:_})]})}export{$e as default};
//# sourceMappingURL=Sites-DVerQiFl.js.map
