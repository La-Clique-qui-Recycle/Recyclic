import{j as e}from"./admin-D2I4SZO-.js";import{R as a}from"./vendor-cDl5Ih67.js";import{d as n}from"./ui-DXFJp4I_.js";import{u as E}from"./stores-CmSlgjNa.js";import{a as k}from"./api-XIr9E-cT.js";const G=n.div`
  max-width: 720px;
  margin: 0 auto;
`,I=n.div`
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.08);
  padding: 24px;
  margin-bottom: 20px;
`,d=n.div`
  display: grid;
  grid-template-columns: 160px 1fr;
  gap: 12px;
  align-items: center;
  margin-bottom: 12px;
`,o=n.input`
  width: 100%;
  padding: 10px 12px;
  border: 1px solid #ddd;
  border-radius: 6px;
`,M=n.button`
  background: #2e7d32;
  color: white;
  border: none;
  border-radius: 6px;
  padding: 10px 16px;
  cursor: pointer;
`,N=n.div`
  display: grid;
  grid-template-columns: 1fr auto;
  gap: 8px;
`;function V(){const t=E(s=>s.currentUser),R=E(s=>s.setCurrentUser),[x,_]=a.useState((t==null?void 0:t.first_name)||""),[h,B]=a.useState((t==null?void 0:t.last_name)||""),[g,A]=a.useState((t==null?void 0:t.username)||""),[f,L]=a.useState((t==null?void 0:t.email)||""),[c,j]=a.useState(""),[u,w]=a.useState(""),[v,q]=a.useState(!1),[b,z]=a.useState(!1),[T,S]=a.useState(!1),[F,m]=a.useState(!1),[y,l]=a.useState(null),[C,i]=a.useState(null),[P,p]=a.useState(null),W=async()=>{S(!0),l(null),i(null);try{const s=await k.put("/users/me",{first_name:x,last_name:h,username:g,email:f});R(s.data),l("Informations mises à jour")}catch(s){i((s==null?void 0:s.message)||"Erreur lors de la mise à jour")}finally{S(!1)}},D=async()=>{var s;if(m(!0),l(null),i(null),p(null),c!==u){m(!1),p("Les mots de passe ne correspondent pas.");return}try{await k.put("/users/me/password",{new_password:c,confirm_password:u}),l("Mot de passe mis à jour"),j(""),w("")}catch(r){(r==null?void 0:r.message)==="Les mots de passe ne correspondent pas."||(s=r==null?void 0:r.message)!=null&&s.startsWith("Mot de passe trop faible")?p(r.message):i((r==null?void 0:r.message)||"Erreur lors de la mise à jour du mot de passe")}finally{m(!1)}};return e.jsxs(G,{children:[e.jsx("h1",{children:"Mon Profil"}),y&&e.jsx("div",{style:{color:"#2e7d32",marginBottom:12},children:y}),C&&e.jsx("div",{style:{color:"#c62828",marginBottom:12},children:C}),e.jsxs(I,{children:[e.jsx("h2",{children:"Informations personnelles"}),e.jsxs(d,{children:[e.jsx("label",{children:"Prénom"}),e.jsx(o,{value:x,onChange:s=>_(s.target.value)})]}),e.jsxs(d,{children:[e.jsx("label",{children:"Nom"}),e.jsx(o,{value:h,onChange:s=>B(s.target.value)})]}),e.jsxs(d,{children:[e.jsx("label",{children:"Identifiant"}),e.jsx(o,{value:g,onChange:s=>A(s.target.value)})]}),e.jsxs(d,{children:[e.jsx("label",{children:"Email"}),e.jsx(o,{type:"email",value:f,onChange:s=>L(s.target.value)})]}),e.jsx(M,{disabled:T,onClick:W,children:"Enregistrer les modifications"})]}),e.jsxs(I,{children:[e.jsx("h2",{children:"Changer le mot de passe"}),e.jsx("div",{style:{fontSize:13,color:"#666",marginBottom:8},children:"8+ caractères, avec majuscule, minuscule, chiffre et caractère spécial"}),e.jsxs(N,{children:[e.jsx(o,{type:v?"text":"password",placeholder:"Nouveau mot de passe",value:c,onChange:s=>j(s.target.value)}),e.jsx("button",{onClick:()=>q(s=>!s),style:{border:"1px solid #ddd",background:"white",borderRadius:6,padding:"0 10px"},children:v?"Masquer":"Afficher"})]}),e.jsxs(N,{style:{marginTop:8},children:[e.jsx(o,{type:b?"text":"password",placeholder:"Confirmer le nouveau mot de passe",value:u,onChange:s=>w(s.target.value)}),e.jsx("button",{onClick:()=>z(s=>!s),style:{border:"1px solid #ddd",background:"white",borderRadius:6,padding:"0 10px"},children:b?"Masquer":"Afficher"})]}),e.jsxs("div",{style:{marginTop:12,display:"flex",alignItems:"center",gap:12},children:[e.jsx(M,{disabled:F,onClick:D,children:"Mettre à jour le mot de passe"}),P&&e.jsx("span",{style:{color:"#c62828",fontSize:13},children:P})]})]})]})}export{V as default};
//# sourceMappingURL=Profile-BBPoD6_e.js.map
