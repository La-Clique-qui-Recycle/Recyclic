import{j as e}from"./admin-D2I4SZO-.js";import{i as _,r as x}from"./vendor-cDl5Ih67.js";import{d as t}from"./ui-DXFJp4I_.js";import{a as y}from"./api-XIr9E-cT.js";import"./stores-CmSlgjNa.js";const k=t.div`
  max-width: 600px;
  margin: 0 auto;
  padding: 20px;
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
`,w=t.h1`
  color: #2c5530;
  text-align: center;
  margin-bottom: 30px;
`,C=t.form`
  display: flex;
  flex-direction: column;
  gap: 20px;
`,n=t.div`
  display: flex;
  flex-direction: column;
  gap: 5px;
`,o=t.label`
  font-weight: 600;
  color: #333;
`,i=t.input`
  padding: 12px;
  border: 2px solid #ddd;
  border-radius: 4px;
  font-size: 16px;
  
  &:focus {
    outline: none;
    border-color: #2c5530;
  }
`,F=t.button`
  background: #2c5530;
  color: white;
  padding: 15px;
  border: none;
  border-radius: 4px;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  transition: background 0.3s;
  
  &:hover {
    background: #1e3a21;
  }
  
  &:disabled {
    background: #ccc;
    cursor: not-allowed;
  }
`,I=t.div`
  padding: 15px;
  border-radius: 4px;
  margin-bottom: 20px;
  text-align: center;
  
  &.success {
    background: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
  }
  
  &.error {
    background: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
  }
  
  &.info {
    background: #d1ecf1;
    color: #0c5460;
    border: 1px solid #bee5eb;
  }
`,D=t.div`
  display: inline-block;
  width: 20px;
  height: 20px;
  border: 3px solid #f3f3f3;
  border-top: 3px solid #2c5530;
  border-radius: 50%;
  animation: spin 1s linear infinite;
  margin-right: 10px;
  
  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }
`;function z(){const[v]=_(),s=v.get("telegram_id"),[r,g]=x.useState({telegram_id:s??"",username:"",first_name:"",last_name:"",email:"",phone:""}),[h,c]=x.useState(!1),[f,l]=x.useState({type:"",text:""});x.useEffect(()=>{s&&g(d=>({...d,telegram_id:s}))},[s]);const a=d=>{const{name:p,value:u}=d.target;g(m=>({...m,[p]:u}))},j=async d=>{var p,u;if(d.preventDefault(),c(!0),l({type:"",text:""}),!r.telegram_id.trim()||!r.first_name.trim()||!r.last_name.trim()){l({type:"error",text:"Veuillez remplir tous les champs obligatoires (ID Telegram, Prénom, Nom de famille)."}),c(!1);return}if(r.telegram_id.trim().length<5){l({type:"error",text:"L'ID Telegram doit contenir au moins 5 caractères."}),c(!1);return}try{await y.post("/users/registration-requests",r),l({type:"success",text:"Votre demande d'inscription a été envoyée avec succès ! Un administrateur va examiner votre demande et vous recevrez une notification sur Telegram une fois approuvée."}),g({telegram_id:"",username:"",first_name:"",last_name:"",email:"",phone:""})}catch(m){console.error("Erreur lors de l'envoi de la demande:",m);let b="Une erreur est survenue lors de l'envoi de votre demande.";(u=(p=m.response)==null?void 0:p.data)!=null&&u.detail&&(b=m.response.data.detail),l({type:"error",text:b})}finally{c(!1)}};return e.jsxs(k,{children:[e.jsx(w,{children:"📝 Inscription Recyclic"}),f.text&&e.jsx(I,{className:f.type,children:f.text}),e.jsxs(C,{onSubmit:j,children:[e.jsxs(n,{children:[e.jsx(o,{htmlFor:"telegram_id",children:"ID Telegram *"}),e.jsx(i,{type:"text",id:"telegram_id",name:"telegram_id",value:r.telegram_id,onChange:a,required:!0,disabled:!!s,placeholder:"Votre ID Telegram"})]}),e.jsxs(n,{children:[e.jsx(o,{htmlFor:"username",children:"Identifiant"}),e.jsx(i,{type:"text",id:"username",name:"username",value:r.username,onChange:a,placeholder:"@votre_nom_utilisateur"})]}),e.jsxs(n,{children:[e.jsx(o,{htmlFor:"first_name",children:"Prénom *"}),e.jsx(i,{type:"text",id:"first_name",name:"first_name",value:r.first_name,onChange:a,required:!0,placeholder:"Votre prénom"})]}),e.jsxs(n,{children:[e.jsx(o,{htmlFor:"last_name",children:"Nom de famille *"}),e.jsx(i,{type:"text",id:"last_name",name:"last_name",value:r.last_name,onChange:a,required:!0,placeholder:"Votre nom de famille"})]}),e.jsxs(n,{children:[e.jsx(o,{htmlFor:"email",children:"Email"}),e.jsx(i,{type:"email",id:"email",name:"email",value:r.email,onChange:a,placeholder:"votre@email.com"})]}),e.jsxs(n,{children:[e.jsx(o,{htmlFor:"phone",children:"Téléphone"}),e.jsx(i,{type:"tel",id:"phone",name:"phone",value:r.phone,onChange:a,placeholder:"+33 6 12 34 56 78"})]}),e.jsxs(F,{type:"submit",disabled:h,children:[h&&e.jsx(D,{}),h?"Envoi en cours...":"Envoyer la demande d'inscription"]})]})]})}export{z as default};
//# sourceMappingURL=Registration-Cwhhv-9r.js.map
