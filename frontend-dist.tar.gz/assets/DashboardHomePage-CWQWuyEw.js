import{j as e}from"./admin-D2I4SZO-.js";import{u as x}from"./vendor-cDl5Ih67.js";import{d as n}from"./ui-DXFJp4I_.js";import"./api-XIr9E-cT.js";import"./stores-CmSlgjNa.js";const h=n.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 24px;
  margin-top: 24px;

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
    gap: 16px;
  }
`,d=n.div`
  background: white;
  border: 1px solid #e5e7eb;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  transition: box-shadow 0.2s ease;

  &:hover {
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  }
`,t=n.h3`
  font-size: 1.25rem;
  font-weight: 700;
  color: #111827;
  margin: 0 0 8px 0;
`,o=n.p`
  font-size: 0.95rem;
  color: #6b7280;
  margin: 0 0 16px 0;
  line-height: 1.5;
`,l=n.ul`
  list-style: none;
  padding: 0;
  margin: 0;
  display: flex;
  flex-direction: column;
  gap: 8px;
`,i=n.li`
  margin: 0;
`,r=n.button`
  display: block;
  width: 100%;
  text-align: left;
  padding: 12px 16px;
  background: #f9fafb;
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  color: #374151;
  text-decoration: none;
  font-size: 0.95rem;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s ease;

  &:hover {
    background: #f3f4f6;
    border-color: #d1d5db;
    color: #111827;
  }

  &:active {
    background: #e5e7eb;
  }
`,p=n.h1`
  font-size: 2rem;
  font-weight: 700;
  color: #111827;
  margin: 0 0 24px 0;
`,f=()=>{const a=x(),s=c=>{a(c)};return e.jsxs("div",{children:[e.jsx(p,{children:"Tableau de Bord d'Administration"}),e.jsxs(h,{children:[e.jsxs(d,{children:[e.jsx(t,{children:"GESTION DES ACCÈS"}),e.jsx(o,{children:"Gérer les comptes utilisateurs, leurs rôles et les inscriptions en attente."}),e.jsxs(l,{children:[e.jsx(i,{children:e.jsx(r,{onClick:()=>s("/admin/users"),children:"Utilisateurs"})}),e.jsx(i,{children:e.jsx(r,{onClick:()=>s("/admin/pending"),children:"Utilisateurs en attente"})})]})]}),e.jsxs(d,{children:[e.jsx(t,{children:"GESTION DU CATALOGUE & DES SITES"}),e.jsx(o,{children:"Configurer les objets (catégories, prix), les sites et les postes de caisse."}),e.jsxs(l,{children:[e.jsx(i,{children:e.jsx(r,{onClick:()=>s("/admin/categories"),children:"Catégories & Prix"})}),e.jsx(i,{children:e.jsx(r,{onClick:()=>s("/admin/sites"),children:"Sites de collecte"})}),e.jsx(i,{children:e.jsx(r,{onClick:()=>s("/admin/cash-registers"),children:"Postes de caisse"})})]})]}),e.jsxs(d,{children:[e.jsx(t,{children:"RAPPORTS & JOURNAUX"}),e.jsx(o,{children:"Consulter les rapports de ventes, de réception et les journaux d'activité."}),e.jsxs(l,{children:[e.jsx(i,{children:e.jsx(r,{onClick:()=>s("/admin/reports"),children:"Rapports Généraux"})}),e.jsx(i,{children:e.jsx(r,{onClick:()=>s("/admin/reception-reports"),children:"Rapports de Réception"})}),e.jsx(i,{children:e.jsx(r,{onClick:()=>s("/admin/cash-sessions/1"),children:"Détail des Sessions de Caisse"})})]})]}),e.jsxs(d,{children:[e.jsx(t,{children:"TABLEAUX DE BORD & SANTÉ"}),e.jsx(o,{children:"Visualiser l'état des différents modules en temps réel."}),e.jsxs(l,{children:[e.jsx(i,{children:e.jsx(r,{onClick:()=>s("/admin/reception-stats"),children:"Dashboard de Réception"})}),e.jsx(i,{children:e.jsx(r,{onClick:()=>s("/admin/health"),children:"Dashboard de Santé Système"})})]})]}),e.jsxs(d,{children:[e.jsx(t,{children:"PARAMÈTRES GÉNÉRAUX"}),e.jsx(o,{children:"Accéder aux réglages avancés de l'application."}),e.jsx(l,{children:e.jsx(i,{children:e.jsx(r,{onClick:()=>s("/admin/settings"),children:"Paramètres"})})})]})]})]})};export{f as default};
//# sourceMappingURL=DashboardHomePage-CWQWuyEw.js.map
