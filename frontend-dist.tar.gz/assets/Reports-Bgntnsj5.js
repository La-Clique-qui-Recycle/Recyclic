import{j as t}from"./admin-D2I4SZO-.js";import"./vendor-cDl5Ih67.js";import{d as r}from"./ui-DXFJp4I_.js";import{B as e}from"./cash-Cdpp_gQO.js";import"./api-XIr9E-cT.js";import"./stores-CmSlgjNa.js";const o=r.div`
  background: white;
  padding: 2rem;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
`,i=r.h1`
  color: #333;
  margin-bottom: 2rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
`,s=r.div`
  text-align: center;
  padding: 3rem;
  color: #666;
`;function l(){return t.jsxs(o,{children:[t.jsxs(i,{children:[t.jsx(e,{size:24,"data-testid":"barchart-icon"}),"Rapports et Statistiques"]}),t.jsxs(s,{children:[t.jsx(e,{size:48,style:{marginBottom:"1rem",opacity:.5},"data-testid":"barchart-icon"}),t.jsx("h2",{children:"En cours de développement"}),t.jsx("p",{children:"Les rapports seront bientôt disponibles."})]})]})}export{l as default};
//# sourceMappingURL=Reports-Bgntnsj5.js.map
