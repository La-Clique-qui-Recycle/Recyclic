import{j as e}from"./admin-D2I4SZO-.js";import{j as T,u as A,r as c}from"./vendor-cDl5Ih67.js";import{d as s}from"./ui-DXFJp4I_.js";import{p as D}from"./api-7vu9KqRw.js";import{A as p,P as E,l as y,g as R,W as z,i as S,m as F,F as C,p as _}from"./cash-Cdpp_gQO.js";import"./api-XIr9E-cT.js";import"./stores-CmSlgjNa.js";const l=s.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
`,g=s.div`
  display: flex;
  align-items: center;
  gap: 15px;
  margin-bottom: 30px;
  padding: 20px;
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
`,u=s.button`
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 15px;
  background: #f5f5f5;
  color: #333;
  border: 1px solid #ddd;
  border-radius: 6px;
  cursor: pointer;
  font-size: 14px;
  transition: all 0.2s;

  &:hover {
    background: #e0e0e0;
    border-color: #bbb;
  }
`,G=s.h1`
  display: flex;
  align-items: center;
  gap: 10px;
  margin: 0;
  color: #2e7d32;
  font-size: 2rem;
`,M=s.div`
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  padding: 20px;
  margin-bottom: 20px;
`,N=s.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 20px;
  margin-bottom: 20px;
`,a=s.div`
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 15px;
  background: #f8f9fa;
  border-radius: 6px;
  border-left: 4px solid #2e7d32;
`,d=s.span`
  font-weight: 600;
  color: #333;
  min-width: 120px;
`,o=s.span`
  color: #666;
`,B=s.span`
  padding: 6px 12px;
  border-radius: 20px;
  font-size: 0.9rem;
  font-weight: 500;
  background: ${r=>r.status==="closed"?"#e8f5e8":"#fff3e0"};
  color: ${r=>r.status==="closed"?"#2e7d32":"#f57c00"};
  display: flex;
  align-items: center;
  gap: 5px;
`,H=s.div`
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  padding: 20px;
`,P=s.h2`
  display: flex;
  align-items: center;
  gap: 10px;
  margin: 0 0 20px 0;
  color: #2e7d32;
  font-size: 1.5rem;
`,$=s.div`
  display: grid;
  gap: 15px;
`,W=s.div`
  border: 1px solid #e0e0e0;
  border-radius: 6px;
  padding: 15px;
  background: #fafafa;
`,Y=s.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
`,O=s.span`
  font-weight: 600;
  color: #2e7d32;
`,U=s.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
  gap: 10px;
`,f=s.div`
  display: flex;
  align-items: center;
  gap: 8px;
  color: #666;
  font-size: 0.9rem;
`,V=s.span`
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 0.8rem;
  font-weight: 500;
  background: ${r=>{switch(r.destination){case"MAGASIN":return"#e3f2fd";case"RECYCLAGE":return"#e8f5e8";case"DECHETERIE":return"#fff3e0";default:return"#f5f5f5"}}};
  color: ${r=>{switch(r.destination){case"MAGASIN":return"#1976d2";case"RECYCLAGE":return"#2e7d32";case"DECHETERIE":return"#f57c00";default:return"#666"}}};
`,q=s.div`
  text-align: center;
  padding: 40px;
  color: #666;
  font-size: 18px;
`,v=s.div`
  background: #ffebee;
  color: #c62828;
  padding: 15px;
  border-radius: 6px;
  margin-bottom: 20px;
  text-align: center;
`,J=s.div`
  text-align: center;
  padding: 40px;
  color: #666;
  font-style: italic;
`,ie=()=>{const{ticketId:r}=T(),x=A(),[i,w]=c.useState(null),[L,h]=c.useState(!0),[m,j]=c.useState(null);c.useEffect(()=>{(async()=>{if(r){h(!0),j(null);try{const n=await D(r);w(n)}catch(n){console.error("Erreur lors du chargement du ticket:",n),j("Impossible de charger les détails du ticket")}finally{h(!1)}}})()},[r]);const b=t=>new Date(t).toLocaleDateString("fr-FR",{day:"2-digit",month:"2-digit",year:"numeric",hour:"2-digit",minute:"2-digit"}),k=t=>`${parseFloat(t).toFixed(2)} kg`,I=t=>{switch(t){case"MAGASIN":return"Magasin";case"RECYCLAGE":return"Recyclage";case"DECHETERIE":return"Déchetterie";default:return t}};return L?e.jsx(l,{children:e.jsx(q,{children:"Chargement des détails du ticket..."})}):m?e.jsxs(l,{children:[e.jsx(g,{children:e.jsxs(u,{onClick:()=>x("/reception"),children:[e.jsx(p,{size:20}),"Retour"]})}),e.jsx(v,{children:m})]}):i?e.jsxs(l,{children:[e.jsxs(g,{children:[e.jsxs(u,{onClick:()=>x("/reception"),children:[e.jsx(p,{size:20}),"Retour"]}),e.jsxs(G,{children:[e.jsx(E,{size:32}),"Détails du Ticket #",i.id.slice(-8)]})]}),e.jsx(M,{children:e.jsxs(N,{children:[e.jsxs(a,{children:[e.jsx(y,{size:20}),e.jsx(d,{children:"Créé le :"}),e.jsx(o,{children:b(i.created_at)})]}),e.jsxs(a,{children:[e.jsx(R,{size:20}),e.jsx(d,{children:"Bénévole :"}),e.jsx(o,{children:i.benevole_username})]}),e.jsxs(a,{children:[e.jsx(E,{size:20}),e.jsx(d,{children:"Articles :"}),e.jsxs(o,{children:[i.lignes.length," article",i.lignes.length>1?"s":""]})]}),e.jsxs(a,{children:[e.jsx(z,{size:20}),e.jsx(d,{children:"Poids total :"}),e.jsx(o,{children:k(i.lignes.reduce((t,n)=>t+parseFloat(n.poids_kg),0))})]}),e.jsxs(a,{children:[e.jsx(d,{children:"Statut :"}),e.jsx(B,{status:i.status,children:i.status==="closed"?e.jsxs(e.Fragment,{children:[e.jsx(S,{size:16}),"Fermé"]}):e.jsxs(e.Fragment,{children:[e.jsx(F,{size:16}),"Ouvert"]})})]}),i.closed_at&&e.jsxs(a,{children:[e.jsx(y,{size:20}),e.jsx(d,{children:"Fermé le :"}),e.jsx(o,{children:b(i.closed_at)})]})]})}),e.jsxs(H,{children:[e.jsxs(P,{children:[e.jsx(C,{size:24}),"Articles du Ticket"]}),i.lignes.length===0?e.jsx(J,{children:"Aucun article dans ce ticket"}):e.jsx($,{children:i.lignes.map((t,n)=>e.jsxs(W,{children:[e.jsxs(Y,{children:[e.jsxs(O,{children:["Article #",n+1]}),e.jsx(V,{destination:t.destination,children:I(t.destination)})]}),e.jsxs(U,{children:[e.jsxs(f,{children:[e.jsx(z,{size:16}),"Poids : ",k(t.poids_kg)]}),e.jsxs(f,{children:[e.jsx(_,{size:16}),"Catégorie : ",t.category_label||t.category_id]}),t.notes&&e.jsxs(f,{style:{gridColumn:"1 / -1"},children:[e.jsx(C,{size:16}),"Notes : ",t.notes]})]})]},t.id))})]})]}):e.jsxs(l,{children:[e.jsx(g,{children:e.jsxs(u,{onClick:()=>x("/reception"),children:[e.jsx(p,{size:20}),"Retour"]})}),e.jsx(v,{children:"Ticket introuvable"})]})};export{ie as default};
//# sourceMappingURL=TicketDetail-CNSJZHNO.js.map
