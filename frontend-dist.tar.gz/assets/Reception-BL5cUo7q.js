import{j as e}from"./admin-D2I4SZO-.js";import{u as I,r as a}from"./vendor-cDl5Ih67.js";import{d as s}from"./ui-DXFJp4I_.js";import{u as L}from"./index-uXXVmU2V.js";import{u as P}from"./stores-CmSlgjNa.js";import{o as _}from"./api-7vu9KqRw.js";import{a as k,X as $,n as B,l as M,g as N,P as U,W as F,E as A}from"./cash-Cdpp_gQO.js";import"./api-XIr9E-cT.js";const p=s.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
`,D=s.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 30px;
  padding: 20px;
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
`,V=s.h1`
  display: flex;
  align-items: center;
  gap: 10px;
  margin: 0;
  color: #2e7d32;
  font-size: 2rem;
`,W=s.div`
  display: flex;
  align-items: center;
  gap: 15px;
`,H=s.span`
  font-weight: 500;
  color: #333;
`,O=s.button`
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 20px;
  background: #f44336;
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-size: 16px;
  transition: background-color 0.2s;

  &:hover {
    background: #d32f2f;
  }

  &:disabled {
    background: #ccc;
    cursor: not-allowed;
  }
`,x=s.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 200px;
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  padding: 20px;
  margin-bottom: 20px;
`,Y=s.button`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
  padding: 20px;
  background: #4caf50;
  color: white;
  border: none;
  border-radius: 12px;
  cursor: pointer;
  font-size: 18px;
  font-weight: 500;
  transition: all 0.2s;
  min-width: 300px;

  &:hover {
    background: #45a049;
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
  }

  &:disabled {
    background: #ccc;
    cursor: not-allowed;
    transform: none;
    box-shadow: none;
  }
`,X=s.div`
  font-size: 32px;
`,q=s.div`
  text-align: center;
  color: #666;
  font-size: 18px;
`,u=s.div`
  background: #ffebee;
  color: #c62828;
  padding: 15px;
  border-radius: 6px;
  margin-bottom: 20px;
  text-align: center;
`,G=s.div`
  margin-top: 30px;
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  padding: 20px;
`,J=s.h2`
  display: flex;
  align-items: center;
  gap: 10px;
  margin: 0 0 20px 0;
  color: #2e7d32;
  font-size: 1.5rem;
`,K=s.div`
  display: grid;
  gap: 15px;
`,Q=s.div`
  border: 1px solid #e0e0e0;
  border-radius: 6px;
  padding: 15px;
  cursor: pointer;
  transition: all 0.2s;
  background: #fafafa;

  &:hover {
    border-color: #2e7d32;
    background: #f1f8e9;
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
  }
`,Z=s.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
`,ee=s.span`
  font-weight: 600;
  color: #2e7d32;
  font-size: 1.1rem;
`,te=s.span`
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 0.8rem;
  font-weight: 500;
  background: ${o=>o.status==="closed"?"#e8f5e8":"#fff3e0"};
  color: ${o=>o.status==="closed"?"#2e7d32":"#f57c00"};
`,se=s.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 10px;
  margin-bottom: 10px;
`,l=s.div`
  display: flex;
  align-items: center;
  gap: 8px;
  color: #666;
  font-size: 0.9rem;
`,re=s.div`
  display: flex;
  justify-content: flex-end;
  gap: 10px;
`,oe=s.button`
  display: flex;
  align-items: center;
  gap: 5px;
  padding: 8px 12px;
  background: #2e7d32;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 0.9rem;
  transition: background-color 0.2s;

  &:hover {
    background: #1b5e20;
  }
`,ne=s.div`
  text-align: center;
  padding: 20px;
  color: #666;
`,ie=s.div`
  text-align: center;
  padding: 40px;
  color: #666;
  font-style: italic;
`,fe=()=>{const o=I(),{poste:c,isLoading:i,error:n,openPoste:g,closePoste:w,createTicket:y}=L(),r=P(t=>t.currentUser),[f,v]=a.useState([]),[T,m]=a.useState(!1),[h,b]=a.useState(null),z=async()=>{m(!0),b(null);try{const t=await _(1,5);v(t.tickets||[])}catch(t){console.error("Erreur lors du chargement des tickets:",t),b("Impossible de charger les tickets récents")}finally{m(!1)}};a.useEffect(()=>{!c&&!i&&!n&&g().catch(t=>{console.error("Erreur lors de l'ouverture du poste:",t)})},[c,i,n,g]),a.useEffect(()=>{z()},[]);const C=async()=>{try{const t=await y();o(`/reception/ticket/${t}`)}catch(t){console.error("Erreur lors de la création du ticket:",t)}},R=async()=>{try{await w(),o("/")}catch(t){console.error("Erreur lors de la fermeture du poste:",t)}},j=(t,d)=>{o(d==="closed"?`/reception/ticket/${t}/view`:`/reception/ticket/${t}`)},E=t=>new Date(t).toLocaleDateString("fr-FR",{day:"2-digit",month:"2-digit",year:"numeric",hour:"2-digit",minute:"2-digit"}),S=t=>`${parseFloat(t).toFixed(2)} kg`;return i&&!c?e.jsx(p,{children:e.jsx(x,{children:e.jsx(q,{children:"Ouverture du poste de réception..."})})}):n&&!c?e.jsx(p,{children:e.jsx(x,{children:e.jsxs(u,{children:[n,e.jsx("br",{}),e.jsx("button",{onClick:()=>window.location.reload(),style:{marginTop:"10px",padding:"8px 16px",backgroundColor:"#1976d2",color:"white",border:"none",borderRadius:"4px",cursor:"pointer"},children:"Réessayer"})]})})}):e.jsxs(p,{children:[e.jsxs(D,{children:[e.jsxs(V,{children:[e.jsx(k,{size:32}),"Module de Réception"]}),e.jsxs(W,{children:[e.jsxs(H,{children:["Bonjour, ",(r==null?void 0:r.first_name)||(r==null?void 0:r.last_name)||(r==null?void 0:r.username)||"Utilisateur"]}),e.jsxs(O,{onClick:R,disabled:i,children:[e.jsx($,{size:20}),"Terminer ma session"]})]})]}),n&&e.jsx(u,{children:n}),e.jsx(x,{children:e.jsxs(Y,{onClick:C,disabled:i,children:[e.jsx(X,{children:e.jsx(B,{size:48})}),"Créer un nouveau ticket de dépôt"]})}),e.jsxs(G,{children:[e.jsxs(J,{children:[e.jsx(k,{size:24}),"Tickets Récents"]}),T?e.jsx(ne,{children:"Chargement des tickets récents..."}):h?e.jsx(u,{children:h}):f.length===0?e.jsx(ie,{children:"Aucun ticket de réception trouvé"}):e.jsx(K,{children:f.map(t=>e.jsxs(Q,{onClick:()=>j(t.id,t.status),children:[e.jsxs(Z,{children:[e.jsxs(ee,{children:["Ticket #",t.id.slice(-8)]}),e.jsx(te,{status:t.status,children:t.status==="closed"?"Fermé":"Ouvert"})]}),e.jsxs(se,{children:[e.jsxs(l,{children:[e.jsx(M,{size:16}),E(t.created_at)]}),e.jsxs(l,{children:[e.jsx(N,{size:16}),t.benevole_username]}),e.jsxs(l,{children:[e.jsx(U,{size:16}),t.total_lignes," article",t.total_lignes>1?"s":""]}),e.jsxs(l,{children:[e.jsx(F,{size:16}),S(t.total_poids)]})]}),e.jsx(re,{children:e.jsxs(oe,{onClick:d=>{d.stopPropagation(),j(t.id,t.status)},children:[e.jsx(A,{size:16}),t.status==="closed"?"Voir les détails":"Modifier"]})})]},t.id))})]})]})};export{fe as default};
//# sourceMappingURL=Reception-BL5cUo7q.js.map
