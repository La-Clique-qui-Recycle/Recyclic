import{j as e}from"./admin-D2I4SZO-.js";import{u as D,r as i}from"./vendor-cDl5Ih67.js";import{d as r}from"./ui-DXFJp4I_.js";import{u as G,b as F,A as R,h as N,i as H}from"./cash-Cdpp_gQO.js";import"./api-XIr9E-cT.js";import"./stores-CmSlgjNa.js";const w=r.div`
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
`,z=r.div`
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 2rem;
`,P=r.button`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  background: #f5f5f5;
  border: 1px solid #ddd;
  border-radius: 8px;
  padding: 0.75rem 1rem;
  cursor: pointer;
  transition: all 0.2s;

  &:hover {
    background: #e0e0e0;
  }
`,A=r.h1`
  color: #2e7d32;
  margin: 0;
  display: flex;
  align-items: center;
  gap: 0.5rem;
`,p=r.div`
  background: white;
  border-radius: 12px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  padding: 2rem;
  margin-bottom: 2rem;
`,V=r.h2`
  color: #333;
  margin: 0 0 1.5rem 0;
  font-size: 1.25rem;
`,U=r.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1.5rem;
  margin-bottom: 2rem;
`,l=r.div`
  background: #f8f9fa;
  padding: 1.5rem;
  border-radius: 8px;
  border-left: 4px solid #2e7d32;
`,c=r.div`
  font-size: 0.875rem;
  color: #666;
  margin-bottom: 0.5rem;
`,m=r.div`
  font-size: 1.5rem;
  font-weight: bold;
  color: #333;
`,J=r.form`
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
`,T=r.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
`,q=r.label`
  font-weight: 500;
  color: #333;
`,K=r.input`
  padding: 0.75rem;
  border: 2px solid #ddd;
  border-radius: 8px;
  font-size: 1rem;
  transition: border-color 0.2s;

  &:focus {
    outline: none;
    border-color: #2e7d32;
  }

  &:invalid {
    border-color: #d32f2f;
  }
`,O=r.textarea`
  padding: 0.75rem;
  border: 2px solid #ddd;
  border-radius: 8px;
  font-size: 1rem;
  min-height: 100px;
  resize: vertical;
  transition: border-color 0.2s;

  &:focus {
    outline: none;
    border-color: #2e7d32;
  }

  &:invalid {
    border-color: #d32f2f;
  }
`,Q=r.div`
  padding: 1rem;
  border-radius: 8px;
  background: ${s=>s.hasVariance?"#fff3e0":"#e8f5e8"};
  border: 1px solid ${s=>s.hasVariance?"#ff9800":"#4caf50"};
  display: flex;
  align-items: center;
  gap: 0.75rem;
  margin: 1rem 0;
`,W=r.div`
  color: ${s=>s.hasVariance?"#f57c00":"#2e7d32"};
`,X=r.div`
  font-weight: 500;
  color: #333;
`,Y=r.div`
  font-size: 1.25rem;
  font-weight: bold;
  color: ${s=>s.hasVariance?"#f57c00":"#2e7d32"};
  margin-left: auto;
`,Z=r.div`
  display: flex;
  gap: 1rem;
  justify-content: flex-end;
  margin-top: 2rem;
`,E=r.button`
  padding: 0.75rem 2rem;
  border-radius: 8px;
  font-size: 1rem;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s;
  border: none;

  ${s=>s.variant==="primary"?`
    background: #2e7d32;
    color: white;
    
    &:hover:not(:disabled) {
      background: #1b5e20;
    }
  `:`
    background: #f5f5f5;
    color: #333;
    border: 1px solid #ddd;
    
    &:hover:not(:disabled) {
      background: #e0e0e0;
    }
  `}

  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
`,ee=r.div`
  background: #ffebee;
  color: #d32f2f;
  padding: 1rem;
  border-radius: 8px;
  border: 1px solid #ffcdd2;
  margin-bottom: 1rem;
`,_=r.div`
  display: inline-block;
  width: 20px;
  height: 20px;
  border: 2px solid #ffffff;
  border-radius: 50%;
  border-top-color: transparent;
  animation: spin 1s ease-in-out infinite;

  @keyframes spin {
    to { transform: rotate(360deg); }
  }
`;function de(){var S,C;const s=D(),{currentSession:n,closeSession:I,refreshSession:f,loading:re,error:h}=G(),[a,L]=i.useState(""),[u,M]=i.useState(""),[g,b]=i.useState(!1),[d,j]=i.useState(!0),v=n?(n.initial_amount||0)+(n.total_sales||0):0,y=parseFloat(a)||0,x=y-v,t=Math.abs(x)>.01;i.useEffect(()=>{(async()=>{j(!0),await f(),j(!1)})()},[f]),i.useEffect(()=>{!d&&(!n||n.status!=="open")&&s("/cash-register/session/open")},[n,s,d]);const $=async o=>{if(o.preventDefault(),!!n){if(t&&!u.trim()){alert("Un commentaire est obligatoire en cas d'écart entre le montant théorique et le montant physique");return}b(!0);try{await I(n.id,{actual_amount:y,variance_comment:u.trim()||void 0})&&s("/admin")}catch(k){console.error("Erreur lors de la fermeture de session:",k)}finally{b(!1)}}},B=()=>{s("/cash-register/sale")};return d||!n||n.status!=="open"?e.jsxs(w,{children:[e.jsx(z,{children:e.jsxs(A,{children:[e.jsx(F,{size:24}),"Fermeture de Caisse"]})}),d&&e.jsx(p,{children:e.jsxs("div",{style:{textAlign:"center",padding:"2rem"},children:[e.jsx(_,{}),e.jsx("p",{style:{marginTop:"1rem"},children:"Chargement des données de la session..."})]})})]}):e.jsxs(w,{children:[e.jsxs(z,{children:[e.jsxs(P,{onClick:()=>s("/cash-register/sale"),children:[e.jsx(R,{size:20}),"Retour à la vente"]}),e.jsxs(A,{children:[e.jsx(F,{size:24}),"Fermeture de Caisse"]})]}),h&&e.jsx(ee,{children:h}),e.jsxs(p,{children:[e.jsx(V,{children:"Résumé de la Session"}),e.jsxs(U,{children:[e.jsxs(l,{children:[e.jsx(c,{children:"Fond de Caisse Initial"}),e.jsxs(m,{children:[(S=n.initial_amount)==null?void 0:S.toFixed(2)," €"]})]}),e.jsxs(l,{children:[e.jsx(c,{children:"Total des Ventes"}),e.jsxs(m,{children:[((C=n.total_sales)==null?void 0:C.toFixed(2))||"0.00"," €"]})]}),e.jsxs(l,{children:[e.jsx(c,{children:"Montant Théorique"}),e.jsxs(m,{children:[v.toFixed(2)," €"]})]}),e.jsxs(l,{children:[e.jsx(c,{children:"Articles Vendus"}),e.jsx(m,{children:n.total_items||0})]})]})]}),e.jsxs(p,{children:[e.jsx(V,{children:"Contrôle des Montants"}),e.jsxs(J,{onSubmit:$,children:[e.jsxs(T,{children:[e.jsx(q,{htmlFor:"actual-amount",children:"Montant Physique Compté *"}),e.jsx(K,{id:"actual-amount",type:"number",step:"0.01",min:"0",value:a,onChange:o=>L(o.target.value),placeholder:"0.00",required:!0})]}),a&&e.jsxs(Q,{hasVariance:t,children:[e.jsx(W,{hasVariance:t,children:t?e.jsx(N,{size:24}):e.jsx(H,{size:24})}),e.jsx(X,{children:t?"Écart détecté":"Aucun écart"}),e.jsxs(Y,{hasVariance:t,children:[x>0?"+":"",x.toFixed(2)," €"]})]}),t&&e.jsxs(T,{children:[e.jsx(q,{htmlFor:"variance-comment",children:"Commentaire sur l'écart *"}),e.jsx(O,{id:"variance-comment",value:u,onChange:o=>M(o.target.value),placeholder:"Expliquez la raison de l'écart...",required:!0})]}),e.jsxs(Z,{children:[e.jsx(E,{type:"button",onClick:B,children:"Annuler"}),e.jsx(E,{type:"submit",variant:"primary",disabled:g||!a,children:g?e.jsxs(e.Fragment,{children:[e.jsx(_,{}),"Fermeture en cours..."]}):"Fermer la Session"})]})]})]})]})}export{de as default};
//# sourceMappingURL=CloseSession-BBZsML8u.js.map
