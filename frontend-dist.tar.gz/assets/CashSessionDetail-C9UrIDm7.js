import{j as e}from"./admin-D2I4SZO-.js";import{j as D,u as T,r as m}from"./vendor-cDl5Ih67.js";import{d as n}from"./ui-DXFJp4I_.js";import{a as L}from"./api-XIr9E-cT.js";import{A as y,g as A,l as B,m as N,D as _,P as I}from"./cash-Cdpp_gQO.js";import"./stores-CmSlgjNa.js";const g=n.div`
  padding: 24px;
  max-width: 1200px;
  margin: 0 auto;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
`,S=n.div`
  display: flex;
  align-items: center;
  gap: 16px;
  margin-bottom: 24px;
`,h=n.button`
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 16px;
  background: #f3f4f6;
  border: 1px solid #d1d5db;
  border-radius: 6px;
  cursor: pointer;
  font-size: 0.9rem;
  color: #374151;
  transition: all 0.2s ease;

  &:hover {
    background: #e5e7eb;
    border-color: #9ca3af;
  }
`,k=n.h1`
  margin: 0;
  font-size: 1.8rem;
  color: #1f2937;
`,F=n.div`
  padding: 60px 0;
  text-align: center;
  color: #4b5563;
  font-size: 1.1rem;
`,w=n.div`
  padding: 24px;
  background: #fef2f2;
  color: #b91c1c;
  border: 1px solid #fecaca;
  border-radius: 10px;
  margin-bottom: 24px;
  display: flex;
  flex-direction: column;
  gap: 12px;
`,M=n.div`
  background: white;
  border-radius: 10px;
  padding: 24px;
  box-shadow: 0 2px 4px rgba(15, 23, 42, 0.06);
  border: 1px solid #e5e7eb;
  margin-bottom: 24px;
`,O=n.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 20px;
  margin-bottom: 24px;
`,a=n.div`
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 16px;
  background: #f9fafb;
  border-radius: 8px;
  border: 1px solid #e5e7eb;
`,d=n.div`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 40px;
  height: 40px;
  background: #dbeafe;
  border-radius: 8px;
  color: #1d4ed8;
`,c=n.div`
  flex: 1;
`,t=n.div`
  font-size: 0.85rem;
  color: #6b7280;
  margin-bottom: 4px;
`,l=n.div`
  font-size: 1.1rem;
  font-weight: 600;
  color: #1f2937;
`,P=n.span`
  display: inline-flex;
  align-items: center;
  padding: 6px 12px;
  border-radius: 9999px;
  font-size: 0.8rem;
  font-weight: 600;
  background: ${r=>r.variant==="open"?"#dcfce7":"#fee2e2"};
  color: ${r=>r.variant==="open"?"#166534":"#991b1b"};
`,$=n.div`
  background: white;
  border-radius: 10px;
  padding: 24px;
  box-shadow: 0 2px 4px rgba(15, 23, 42, 0.06);
  border: 1px solid #e5e7eb;
`,q=n.h2`
  margin: 0 0 20px 0;
  font-size: 1.3rem;
  color: #1f2937;
  display: flex;
  align-items: center;
  gap: 12px;
`,U=n.table`
  width: 100%;
  border-collapse: collapse;
`,f=n.th`
  text-align: left;
  padding: 12px;
  background: #f9fafb;
  font-size: 0.85rem;
  text-transform: uppercase;
  letter-spacing: 0.02em;
  color: #4b5563;
  border-bottom: 1px solid #e5e7eb;
`,j=n.td`
  padding: 12px;
  border-bottom: 1px solid #f3f4f6;
  font-size: 0.95rem;
  color: #1f2937;
`,H=n.div`
  padding: 32px;
  text-align: center;
  color: #6b7280;
  font-size: 0.95rem;
`,o=r=>r.toLocaleString("fr-FR",{style:"currency",currency:"EUR"}),z=r=>{if(!r)return"N/A";const u=new Date(r);return isNaN(u.getTime())?"N/A":u.toLocaleString("fr-FR")},X=()=>{const{id:r}=D(),u=T(),[s,E]=m.useState(null),[R,b]=m.useState(!0),[C,v]=m.useState(null);m.useEffect(()=>{if(!r){v("ID de session manquant"),b(!1);return}(async()=>{try{b(!0),v(null);const p=await L.get(`/cash-sessions/${r}`);E(p.data)}catch(p){console.error("Erreur lors du chargement de la session:",p),v(p instanceof Error?p.message:"Erreur inconnue")}finally{b(!1)}})()},[r]);const x=()=>{u("/admin/dashboard")};return R?e.jsx(g,{children:e.jsx(F,{children:"Chargement des détails de la session..."})}):C?e.jsxs(g,{children:[e.jsxs(S,{children:[e.jsxs(h,{onClick:x,children:[e.jsx(y,{size:16}),"Retour"]}),e.jsx(k,{children:"Erreur"})]}),e.jsxs(w,{children:[e.jsx("div",{children:C}),e.jsx(h,{onClick:x,children:"Retour au dashboard"})]})]}):s?e.jsxs(g,{children:[e.jsxs(S,{children:[e.jsxs(h,{onClick:x,children:[e.jsx(y,{size:16}),"Retour"]}),e.jsx(k,{children:"Détail de la Session de Caisse"})]}),e.jsxs(M,{children:[e.jsxs(O,{children:[e.jsxs(a,{children:[e.jsx(d,{children:e.jsx(A,{size:20})}),e.jsxs(c,{children:[e.jsx(t,{children:"Opérateur"}),e.jsx(l,{children:s.operator_name||"Inconnu"})]})]}),e.jsxs(a,{children:[e.jsx(d,{children:e.jsx(B,{size:20})}),e.jsxs(c,{children:[e.jsx(t,{children:"Ouverture"}),e.jsx(l,{children:z(s.opened_at)})]})]}),s.closed_at&&e.jsxs(a,{children:[e.jsx(d,{children:e.jsx(N,{size:20})}),e.jsxs(c,{children:[e.jsx(t,{children:"Fermeture"}),e.jsx(l,{children:z(s.closed_at)})]})]}),e.jsxs(a,{children:[e.jsx(d,{children:e.jsx(_,{size:20})}),e.jsxs(c,{children:[e.jsx(t,{children:"Montant initial"}),e.jsx(l,{children:o(s.initial_amount)})]})]}),e.jsxs(a,{children:[e.jsx(d,{children:e.jsx(_,{size:20})}),e.jsxs(c,{children:[e.jsx(t,{children:"Total des ventes"}),e.jsx(l,{children:o(s.total_sales)})]})]}),e.jsxs(a,{children:[e.jsx(d,{children:e.jsx(I,{size:20})}),e.jsxs(c,{children:[e.jsx(t,{children:"Articles vendus"}),e.jsx(l,{children:s.total_items})]})]})]}),e.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"12px",marginBottom:"16px"},children:[e.jsx(t,{children:"Statut:"}),e.jsx(P,{variant:s.status==="open"?"open":"closed",children:s.status==="open"?"Ouverte":"Fermée"})]}),s.variance!==void 0&&e.jsxs("div",{style:{padding:"16px",background:s.variance===0?"#f0fdf4":"#fef2f2",border:`1px solid ${s.variance===0?"#bbf7d0":"#fecaca"}`,borderRadius:"8px",marginTop:"16px"},children:[e.jsx(t,{children:"Contrôle de caisse"}),e.jsxs("div",{style:{marginTop:"8px"},children:[e.jsxs("div",{children:["Montant théorique: ",o(s.closing_amount||0)]}),e.jsxs("div",{children:["Montant physique: ",o(s.actual_amount||0)]}),e.jsxs("div",{style:{fontWeight:"600",color:s.variance===0?"#166534":"#991b1b"},children:["Écart: ",o(s.variance)]}),s.variance_comment&&e.jsxs("div",{style:{marginTop:"8px",fontStyle:"italic"},children:["Commentaire: ",s.variance_comment]})]})]})]}),e.jsxs($,{children:[e.jsxs(q,{children:[e.jsx(I,{size:20}),"Journal des Ventes (",s.sales.length," vente",s.sales.length>1?"s":"",")"]}),s.sales.length===0?e.jsx(H,{children:"Aucune vente enregistrée pour cette session."}):e.jsxs(U,{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx(f,{children:"Heure"}),e.jsx(f,{children:"Montant"}),e.jsx(f,{children:"Don"}),e.jsx(f,{children:"Paiement"}),e.jsx(f,{children:"Opérateur"})]})}),e.jsx("tbody",{children:s.sales.map(i=>e.jsxs("tr",{children:[e.jsx(j,{children:z(i.created_at)}),e.jsx(j,{children:o(i.total_amount)}),e.jsx(j,{children:i.donation?o(i.donation):"-"}),e.jsx(j,{children:i.payment_method||"Non spécifié"}),e.jsx(j,{children:i.operator_id||"-"})]},i.id))})]})]})]}):e.jsxs(g,{children:[e.jsxs(S,{children:[e.jsxs(h,{onClick:x,children:[e.jsx(y,{size:16}),"Retour"]}),e.jsx(k,{children:"Session non trouvée"})]}),e.jsxs(w,{children:[e.jsx("div",{children:"La session demandée n'a pas été trouvée."}),e.jsx(h,{onClick:x,children:"Retour au dashboard"})]})]})};export{X as default};
//# sourceMappingURL=CashSessionDetail-C9UrIDm7.js.map
