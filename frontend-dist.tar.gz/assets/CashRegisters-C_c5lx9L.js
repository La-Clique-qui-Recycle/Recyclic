import{j as e}from"./admin-D2I4SZO-.js";import{r as s}from"./vendor-cDl5Ih67.js";import{d as t}from"./ui-DXFJp4I_.js";import{g as B,u as L,c as T,a as $,d as N}from"./api-7vu9KqRw.js";import"./api-XIr9E-cT.js";import"./stores-CmSlgjNa.js";const P=t.div`
  background: white;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 6px rgba(0,0,0,0.06);
  max-width: 500px;
  margin: 0 auto;
`,G=t.h3`
  margin: 0 0 20px 0;
  color: #333;
`,m=t.div`
  margin-bottom: 16px;
`,j=t.label`
  display: block;
  margin-bottom: 4px;
  font-weight: 500;
  color: #555;
`,M=t.input`
  width: 100%;
  padding: 8px 12px;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 14px;
  
  &:focus {
    outline: none;
    border-color: #2e7d32;
    box-shadow: 0 0 0 2px rgba(46, 125, 50, 0.2);
  }
`,I=t.select`
  width: 100%;
  padding: 8px 12px;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 14px;
  background: white;
  
  &:focus {
    outline: none;
    border-color: #2e7d32;
    box-shadow: 0 0 0 2px rgba(46, 125, 50, 0.2);
  }
`,q=t.div`
  display: flex;
  align-items: center;
  gap: 8px;
`,U=t.input`
  margin: 0;
`,H=t.div`
  display: flex;
  gap: 12px;
  justify-content: flex-end;
  margin-top: 20px;
`,_=t.button`
  padding: 10px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
  font-weight: 500;
  
  ${n=>n.variant==="primary"?`
    background: #2e7d32;
    color: white;
    
    &:hover {
      background: #1b5e20;
    }
  `:`
    background: #f5f5f5;
    color: #666;
    border: 1px solid #ddd;
    
    &:hover {
      background: #e0e0e0;
    }
  `}
  
  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
`,J=t.div`
  color: #d32f2f;
  font-size: 12px;
  margin-top: 4px;
`;function K({register:n,onSuccess:b,onCancel:u}){const[r,l]=s.useState({name:"",location:"",site_id:"",is_active:!0}),[c,y]=s.useState([]),[a,g]=s.useState(!1),[p,x]=s.useState(null);s.useEffect(()=>{n&&l(n)},[n]),s.useEffect(()=>{(async()=>{try{const i=await B();y(i)}catch(i){console.error("Erreur lors du chargement des sites:",i)}})()},[]);const f=async d=>{d.preventDefault(),g(!0),x(null);try{n!=null&&n.id?await L(n.id,r):await T(r),b()}catch(i){x((i==null?void 0:i.message)||"Une erreur est survenue")}finally{g(!1)}},h=d=>{const{name:i,value:k,type:w}=d.target;l(S=>({...S,[i]:w==="checkbox"?d.target.checked:k}))};return e.jsxs(P,{children:[e.jsx(G,{children:n!=null&&n.id?"Modifier le poste de caisse":"Créer un poste de caisse"}),e.jsxs("form",{onSubmit:f,children:[e.jsxs(m,{children:[e.jsx(j,{htmlFor:"name",children:"Nom *"}),e.jsx(M,{id:"name",name:"name",type:"text",value:r.name,onChange:h,required:!0,disabled:a})]}),e.jsxs(m,{children:[e.jsx(j,{htmlFor:"location",children:"Localisation"}),e.jsx(M,{id:"location",name:"location",type:"text",value:r.location,onChange:h,disabled:a,placeholder:"Ex: Entrée principale, Atelier..."})]}),e.jsxs(m,{children:[e.jsx(j,{htmlFor:"site_id",children:"Site"}),e.jsxs(I,{id:"site_id",name:"site_id",value:r.site_id,onChange:h,disabled:a,children:[e.jsx("option",{value:"",children:"Sélectionner un site"}),c.map(d=>e.jsx("option",{value:d.id,children:d.name},d.id))]})]}),e.jsx(m,{children:e.jsxs(q,{children:[e.jsx(U,{id:"is_active",name:"is_active",type:"checkbox",checked:r.is_active,onChange:h,disabled:a}),e.jsx(j,{htmlFor:"is_active",children:"Poste actif"})]})}),p&&e.jsx(J,{children:p}),e.jsxs(H,{children:[e.jsx(_,{type:"button",onClick:u,disabled:a,children:"Annuler"}),e.jsx(_,{type:"submit",variant:"primary",disabled:a,children:a?"Enregistrement...":n!=null&&n.id?"Modifier":"Créer"})]})]})]})}const Q=t.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
`,V=t.div`
  background: white;
  padding: 24px;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  max-width: 400px;
  width: 90%;
`,W=t.h3`
  margin: 0 0 16px 0;
  color: #d32f2f;
  font-size: 18px;
`,X=t.p`
  margin: 0 0 24px 0;
  color: #666;
  line-height: 1.5;
`,Y=t.div`
  display: flex;
  gap: 12px;
  justify-content: flex-end;
`,z=t.button`
  padding: 10px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
  font-weight: 500;
  
  ${n=>n.variant==="danger"?`
    background: #d32f2f;
    color: white;
    
    &:hover {
      background: #b71c1c;
    }
  `:`
    background: #f5f5f5;
    color: #666;
    border: 1px solid #ddd;
    
    &:hover {
      background: #e0e0e0;
    }
  `}
  
  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
`;function Z({isOpen:n,itemName:b,onConfirm:u,onCancel:r,loading:l=!1}){return n?e.jsx(Q,{onClick:r,children:e.jsxs(V,{onClick:c=>c.stopPropagation(),children:[e.jsx(W,{children:"Confirmer la suppression"}),e.jsxs(X,{children:['Êtes-vous sûr de vouloir supprimer le poste de caisse "',b,'" ? Cette action est irréversible.']}),e.jsxs(Y,{children:[e.jsx(z,{type:"button",onClick:r,disabled:l,children:"Annuler"}),e.jsx(z,{type:"button",variant:"danger",onClick:u,disabled:l,children:l?"Suppression...":"Supprimer"})]})]})}):null}const ee=t.div`
  background: white;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 6px rgba(0,0,0,0.06);
`,te=t.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 16px;
`,ne=t.h2`
  margin: 0;
`,oe=t.button`
  background: #2e7d32;
  color: white;
  border: none;
  padding: 10px 14px;
  border-radius: 6px;
  cursor: pointer;
`,se=t.table`
  width: 100%;
  border-collapse: collapse;
`,v=t.th`
  text-align: left;
  padding: 10px;
  border-bottom: 1px solid #eee;
`,C=t.td`
  padding: 10px;
  border-bottom: 1px solid #f5f5f5;
`,D=t.button`
  padding: 4px 8px;
  margin: 0 2px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 12px;
  
  ${n=>n.variant==="edit"?`
    background: #2196f3;
    color: white;
    
    &:hover {
      background: #1976d2;
    }
  `:`
    background: #f44336;
    color: white;
    
    &:hover {
      background: #d32f2f;
    }
  `}
`,ie=t.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
`;function xe(){var F;const[n,b]=s.useState([]),[u,r]=s.useState(!0),[l,c]=s.useState(null),[y,a]=s.useState(!1),[g,p]=s.useState(null),[x,f]=s.useState({isOpen:!1,register:null}),[h,d]=s.useState(!1),i=async()=>{try{r(!0),c(null);const o=await $();b(o)}catch(o){c((o==null?void 0:o.message)||"Erreur de chargement")}finally{r(!1)}};s.useEffect(()=>{i()},[]);const k=()=>{p(null),a(!0)},w=o=>{p(o),a(!0)},S=o=>{f({isOpen:!0,register:o})},O=()=>{a(!1),p(null),i()},E=()=>{a(!1),p(null)},R=async()=>{if(x.register)try{d(!0),await N(x.register.id),f({isOpen:!1,register:null}),i()}catch(o){c((o==null?void 0:o.message)||"Erreur lors de la suppression")}finally{d(!1)}},A=()=>{f({isOpen:!1,register:null})};return e.jsxs(ee,{children:[e.jsxs(te,{children:[e.jsx(ne,{children:"Postes de caisse"}),e.jsx(oe,{onClick:k,children:"Créer un poste de caisse"})]}),u&&e.jsx("div",{children:"Chargement..."}),l&&e.jsx("div",{style:{color:"red"},children:l}),!u&&!l&&e.jsxs(se,{children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx(v,{children:"Nom"}),e.jsx(v,{children:"Localisation"}),e.jsx(v,{children:"Actif"}),e.jsx(v,{children:"Actions"})]})}),e.jsx("tbody",{children:n.map(o=>e.jsxs("tr",{children:[e.jsx(C,{children:o.name}),e.jsx(C,{children:o.location||"-"}),e.jsx(C,{children:o.is_active?"Oui":"Non"}),e.jsxs(C,{children:[e.jsx(D,{variant:"edit",onClick:()=>w(o),children:"Modifier"}),e.jsx(D,{variant:"delete",onClick:()=>S(o),children:"Supprimer"})]})]},o.id))})]}),y&&e.jsx(ie,{onClick:E,children:e.jsx("div",{onClick:o=>o.stopPropagation(),children:e.jsx(K,{register:g,onSuccess:O,onCancel:E})})}),e.jsx(Z,{isOpen:x.isOpen,itemName:((F=x.register)==null?void 0:F.name)||"",onConfirm:R,onCancel:A,loading:h})]})}export{xe as default};
//# sourceMappingURL=CashRegisters-C_c5lx9L.js.map
