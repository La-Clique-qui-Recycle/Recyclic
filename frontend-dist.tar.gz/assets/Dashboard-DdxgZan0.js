import{j as e}from"./admin-D2I4SZO-.js";import"./vendor-cDl5Ih67.js";import{d as s}from"./ui-DXFJp4I_.js";import{P as n,D as o,U as c,B as l}from"./cash-Cdpp_gQO.js";import"./api-XIr9E-cT.js";import"./stores-CmSlgjNa.js";const x=s.div`
  display: grid;
  gap: 2rem;
`,h=s.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1.5rem;
  margin-bottom: 2rem;
`,t=s.div`
  background: white;
  padding: 1.5rem;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  display: flex;
  align-items: center;
  gap: 1rem;
`,i=s.div`
  width: 48px;
  height: 48px;
  border-radius: 8px;
  background-color: #e8f5e8;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #2e7d32;
`,r=s.div`
  flex: 1;
`,a=s.div`
  font-size: 2rem;
  font-weight: bold;
  color: #333;
`,d=s.div`
  color: #666;
  font-size: 0.9rem;
`,p=s.div`
  background: white;
  padding: 2rem;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
`,m=s.h1`
  color: #333;
  margin-bottom: 1rem;
`,j=s.p`
  color: #666;
  line-height: 1.6;
`;function z(){return e.jsxs(x,{children:[e.jsxs(p,{children:[e.jsx(m,{children:"Bienvenue sur Recyclic"}),e.jsx(j,{children:"Plateforme de gestion de recyclage intelligente. Gérez vos dépôts, suivez vos ventes et analysez vos performances."})]}),e.jsxs(h,{children:[e.jsxs(t,{children:[e.jsx(i,{children:e.jsx(n,{size:24,"data-testid":"package-icon"})}),e.jsxs(r,{children:[e.jsx(a,{"data-testid":"stat-depots",children:"0"}),e.jsx(d,{children:"Dépôts aujourd'hui"})]})]}),e.jsxs(t,{children:[e.jsx(i,{children:e.jsx(o,{size:24,"data-testid":"dollarsign-icon"})}),e.jsxs(r,{children:[e.jsx(a,{"data-testid":"stat-ca",children:"0€"}),e.jsx(d,{children:"Chiffre d'affaires"})]})]}),e.jsxs(t,{children:[e.jsx(i,{children:e.jsx(c,{size:24,"data-testid":"users-icon"})}),e.jsxs(r,{children:[e.jsx(a,{"data-testid":"stat-users",children:"0"}),e.jsx(d,{children:"Utilisateurs actifs"})]})]}),e.jsxs(t,{children:[e.jsx(i,{children:e.jsx(l,{size:24,"data-testid":"barchart-icon"})}),e.jsxs(r,{children:[e.jsx(a,{"data-testid":"stat-recycled",children:"0"}),e.jsx(d,{children:"Appareils recyclés"})]})]})]})]})}export{z as default};
//# sourceMappingURL=Dashboard-DdxgZan0.js.map
