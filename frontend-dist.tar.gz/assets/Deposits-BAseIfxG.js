import{j as e}from"./admin-D2I4SZO-.js";import"./vendor-cDl5Ih67.js";import{d as o}from"./ui-DXFJp4I_.js";import{P as s}from"./cash-Cdpp_gQO.js";import"./api-XIr9E-cT.js";import"./stores-CmSlgjNa.js";const t=o.div`
  background: white;
  padding: 2rem;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
`,i=o.h1`
  color: #333;
  margin-bottom: 2rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
`,r=o.div`
  text-align: center;
  padding: 3rem;
  color: #666;
`;function l(){return e.jsxs(t,{children:[e.jsxs(i,{children:[e.jsx(s,{size:24}),"Gestion des Dépôts"]}),e.jsxs(r,{children:[e.jsx(s,{size:48,style:{marginBottom:"1rem",opacity:.5}}),e.jsx("h2",{children:"En cours de développement"}),e.jsx("p",{children:"La gestion des dépôts sera bientôt disponible."})]})]})}export{l as default};
//# sourceMappingURL=Deposits-BAseIfxG.js.map
