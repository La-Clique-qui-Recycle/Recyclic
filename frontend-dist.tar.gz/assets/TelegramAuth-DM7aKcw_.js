import{j as e}from"./admin-D2I4SZO-.js";import{u as I,i as A,r as i}from"./vendor-cDl5Ih67.js";import{d as t}from"./ui-DXFJp4I_.js";import{n as D}from"./api-7vu9KqRw.js";import"./api-XIr9E-cT.js";import"./stores-CmSlgjNa.js";const g=t.div`
  max-width: 600px;
  margin: 0 auto;
  padding: 20px;
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
`,h=t.h1`
  color: #2c5530;
  text-align: center;
  margin-bottom: 30px;
`,M=t.div`
  text-align: center;
  font-size: 18px;
  color: #333;
  margin-bottom: 30px;
`,P=t.div`
  display: flex;
  gap: 20px;
  justify-content: center;
  margin-bottom: 30px;
`,p=t.button`
  background: #2c5530;
  color: white;
  padding: 15px 30px;
  border: none;
  border-radius: 4px;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  transition: background 0.3s;
  min-width: 150px;
  
  &:hover {
    background: #1e3a21;
  }
`,R=t(p)`
  background: #6c757d;
  
  &:hover {
    background: #545b62;
  }
`,V=t.form`
  display: flex;
  flex-direction: column;
  gap: 20px;
  margin-top: 30px;
`,b=t.div`
  display: flex;
  flex-direction: column;
  gap: 5px;
`,f=t.label`
  font-weight: 600;
  color: #333;
`,j=t.input`
  padding: 12px;
  border: 2px solid #ddd;
  border-radius: 4px;
  font-size: 16px;
  
  &:focus {
    outline: none;
    border-color: #2c5530;
  }
`,q=t.div`
  padding: 15px;
  border-radius: 4px;
  margin-bottom: 20px;
  text-align: center;
  
  &.error {
    background: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
  }
  
  &.success {
    background: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
  }
`,B=t.div`
  display: inline-block;
  width: 20px;
  height: 20px;
  border: 3px solid #f3f3f3;
  border-top: 3px solid #2c5530;
  border-radius: 50%;
  animation: spin 1s linear infinite;
  margin-right: 10px;
  
  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }
`,E=t.div`
  text-align: center;
  padding: 30px;
  background: #d4edda;
  color: #155724;
  border: 1px solid #c3e6cb;
  border-radius: 8px;
  font-size: 18px;
  font-weight: 600;
`;function H(){const y=I(),[u]=A(),[w,v]=i.useState(!1),[d,k]=i.useState({username:"",password:""}),[l,o]=i.useState({type:"",text:""}),[a,x]=i.useState(!1),[S,L]=i.useState(!1),C=()=>{const s=u.toString(),n=s?`/inscription?${s}`:"/inscription";y(n)},T=()=>{v(!0)},m=s=>{const{name:n,value:c}=s.target;k(r=>({...r,[n]:c}))},z=async s=>{var n,c;s.preventDefault(),x(!0),o({type:"",text:""});try{const r=u.get("telegram_id");if(!r){o({type:"error",text:"Paramètre telegram_id manquant dans l'URL."});return}const F={username:d.username,password:d.password,telegram_id:r};await D(F),L(!0),o({type:"",text:""})}catch(r){console.error("Erreur lors de la liaison du compte:",r),((n=r.response)==null?void 0:n.status)===401?o({type:"error",text:"Nom d'utilisateur ou mot de passe incorrect."}):((c=r.response)==null?void 0:c.status)===409?o({type:"error",text:"Ce compte Telegram est déjà lié à un autre utilisateur."}):o({type:"error",text:"Une erreur est survenue lors de la liaison du compte. Veuillez réessayer."})}finally{x(!1)}};return S?e.jsxs(g,{children:[e.jsx(h,{children:"🔗 Liaison de Compte Telegram"}),e.jsx(E,{children:"✅ Votre compte a été lié avec succès !"})]}):e.jsxs(g,{children:[e.jsx(h,{children:"🔗 Liaison de Compte Telegram"}),e.jsx(M,{children:"Avez-vous déjà un compte Recyclic ?"}),e.jsxs(P,{children:[e.jsx(p,{onClick:C,children:"S'inscrire"}),e.jsx(R,{onClick:T,children:"Se connecter"})]}),l.text&&e.jsx(q,{className:l.type,children:l.text}),w&&e.jsxs(V,{onSubmit:z,children:[e.jsxs(b,{children:[e.jsx(f,{htmlFor:"username",children:"Identifiant"}),e.jsx(j,{type:"text",id:"username",name:"username",value:d.username,onChange:m,placeholder:"Votre identifiant",required:!0,disabled:a})]}),e.jsxs(b,{children:[e.jsx(f,{htmlFor:"password",children:"Mot de passe"}),e.jsx(j,{type:"password",id:"password",name:"password",value:d.password,onChange:m,placeholder:"Votre mot de passe",required:!0,disabled:a})]}),e.jsxs(p,{type:"submit",disabled:a,children:[a&&e.jsx(B,{}),a?"Liaison en cours...":"Lier le compte"]})]})]})}export{H as default};
//# sourceMappingURL=TelegramAuth-DM7aKcw_.js.map
