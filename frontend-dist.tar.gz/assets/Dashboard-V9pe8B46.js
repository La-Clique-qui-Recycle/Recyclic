import{j as i}from"./admin-D2I4SZO-.js";import{d as e}from"./ui-DXFJp4I_.js";import{u as m}from"./vendor-cDl5Ih67.js";import"./api-XIr9E-cT.js";import"./stores-CmSlgjNa.js";const p=e.div`
  width: 100%;
  min-height: 100vh;
  background: #f5f5f5;
  padding: ${n=>n.$isKioskMode?"0":n.$isAdminMode?"16px":"24px"};
  margin: 0;
  box-sizing: border-box;
  
  @media (max-width: 768px) {
    padding: ${n=>n.$isKioskMode?"0":n.$isAdminMode?"12px":"16px"};
  }
`,h=e.div`
  width: 100%;
  max-width: none;
  margin: 0 auto;
`,g=e.h1`
  margin: 0 0 24px 0;
  font-size: 1.8rem;
  font-weight: 600;
  color: #1f2937;
  line-height: 1.2;
  
  @media (max-width: 768px) {
    font-size: 1.5rem;
    margin-bottom: 20px;
  }
`;e.h2`
  margin: 0 0 16px 0;
  font-size: 1.3rem;
  font-weight: 600;
  color: #374151;
  line-height: 1.3;
  
  @media (max-width: 768px) {
    font-size: 1.1rem;
    margin-bottom: 12px;
  }
`;e.h3`
  margin: 0 0 12px 0;
  font-size: 1.1rem;
  font-weight: 500;
  color: #4b5563;
  line-height: 1.4;
  
  @media (max-width: 768px) {
    font-size: 1rem;
    margin-bottom: 8px;
  }
`;e.div`
  margin-bottom: 32px;
  
  &:last-child {
    margin-bottom: 0;
  }
  
  @media (max-width: 768px) {
    margin-bottom: 24px;
  }
`;e.div`
  background: white;
  border-radius: 8px;
  padding: 24px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  border: 1px solid #e5e7eb;
  margin-bottom: 24px;
  
  &:last-child {
    margin-bottom: 0;
  }
  
  @media (max-width: 768px) {
    padding: 16px;
    margin-bottom: 16px;
  }
`;e.div`
  display: grid;
  grid-template-columns: ${n=>n.columns?`repeat(${n.columns}, 1fr)`:"repeat(auto-fit, minmax(250px, 1fr))"};
  gap: ${n=>n.gap||"24px"};
  margin-bottom: 24px;
  
  @media (max-width: 768px) {
    grid-template-columns: 1fr;
    gap: 16px;
    margin-bottom: 16px;
  }
`;e.div`
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  margin-bottom: 24px;
  
  @media (max-width: 768px) {
    gap: 8px;
    margin-bottom: 16px;
  }
`;e.div`
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
  margin-bottom: 24px;
  align-items: end;
  
  @media (max-width: 768px) {
    gap: 12px;
    margin-bottom: 16px;
  }
`;const b=({children:n,className:r,isKioskMode:l=!1,isAdminMode:c=!1})=>i.jsx(p,{className:r,$isKioskMode:l,$isAdminMode:c,children:i.jsx(h,{children:n})}),f=e.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 24px;
  margin-top: 24px;

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  gap: 16px;
  }
`,d=e.div`
  background: white;
  border: 1px solid #e5e7eb;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  transition: box-shadow 0.2s ease;

  &:hover {
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  }
`,o=e.h3`
  font-size: 1.25rem;
  font-weight: 700;
  color: #111827;
  margin: 0 0 8px 0;
`,a=e.p`
  font-size: 0.95rem;
  color: #6b7280;
  margin: 0 0 16px 0;
  line-height: 1.5;
`,x=e.ul`
  list-style: none;
  padding: 0;
  margin: 0;
  display: flex;
  flex-direction: column;
  gap: 8px;
`,s=e.li`
  margin: 0;
`,t=e.button`
  display: block;
  width: 100%;
  text-align: left;
  padding: 12px 16px;
  background: #f9fafb;
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  color: #374151;
  text-decoration: none;
  font-size: 0.95rem;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s ease;

  &:hover {
    background: #f3f4f6;
    border-color: #d1d5db;
    color: #111827;
  }

  &:active {
    background: #e5e7eb;
  }
`,A=()=>{const n=m(),r=l=>{n(l)};return i.jsxs(b,{isAdminMode:!0,children:[i.jsx(g,{children:"Tableau de Bord d'Administration"}),i.jsxs(f,{children:[i.jsxs(d,{children:[i.jsx(o,{children:"GESTION DES ACCÈS"}),i.jsx(a,{children:"Gérer les comptes utilisateurs, leurs rôles et les inscriptions en attente."}),i.jsxs(x,{children:[i.jsx(s,{children:i.jsx(t,{onClick:()=>r("/admin/users"),children:"Utilisateurs"})}),i.jsx(s,{children:i.jsx(t,{onClick:()=>r("/admin/pending"),children:"Utilisateurs en attente"})})]})]}),i.jsxs(d,{children:[i.jsx(o,{children:"GESTION DU CATALOGUE & DES SITES"}),i.jsx(a,{children:"Configurer les objets (catégories, prix), les sites et les postes de caisse."}),i.jsxs(x,{children:[i.jsx(s,{children:i.jsx(t,{onClick:()=>r("/admin/categories"),children:"Catégories & Prix"})}),i.jsx(s,{children:i.jsx(t,{onClick:()=>r("/admin/sites"),children:"Sites de collecte"})}),i.jsx(s,{children:i.jsx(t,{onClick:()=>r("/admin/cash-registers"),children:"Postes de caisse"})})]})]}),i.jsxs(d,{children:[i.jsx(o,{children:"RAPPORTS & JOURNAUX"}),i.jsx(a,{children:"Consulter les rapports de ventes, de réception et les journaux d'activité."}),i.jsxs(x,{children:[i.jsx(s,{children:i.jsx(t,{onClick:()=>r("/admin/reports"),children:"Rapports Généraux"})}),i.jsx(s,{children:i.jsx(t,{onClick:()=>r("/admin/reception-reports"),children:"Rapports de Réception"})}),i.jsx(s,{children:i.jsx(t,{onClick:()=>r("/admin/cash-sessions/1"),children:"Détail des Sessions de Caisse"})})]})]}),i.jsxs(d,{children:[i.jsx(o,{children:"TABLEAUX DE BORD & SANTÉ"}),i.jsx(a,{children:"Visualiser l'état des différents modules en temps réel."}),i.jsxs(x,{children:[i.jsx(s,{children:i.jsx(t,{onClick:()=>r("/admin/reception-stats"),children:"Dashboard de Réception"})}),i.jsx(s,{children:i.jsx(t,{onClick:()=>r("/admin/health"),children:"Dashboard de Santé Système"})})]})]}),i.jsxs(d,{children:[i.jsx(o,{children:"PARAMÈTRES GÉNÉRAUX"}),i.jsx(a,{children:"Accéder aux réglages avancés de l'application."}),i.jsx(x,{children:i.jsx(s,{children:i.jsx(t,{onClick:()=>r("/admin/settings"),children:"Paramètres"})})})]})]})]})};export{A as default};
//# sourceMappingURL=Dashboard-V9pe8B46.js.map
